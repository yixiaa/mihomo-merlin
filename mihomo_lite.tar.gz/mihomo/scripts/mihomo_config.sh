#!/bin/sh
# Mihomo for Asuswrt-Merlin (Koolcenter 软件中心, HND/aarch64)
# 入口：
#   Web API : mihomo_config.sh <id> <action>
#   命令行  : mihomo_config.sh <action>
#   init.d  : S99mihomo.sh start / N99mihomo.sh start_nat
# action: start stop restart update_sub update_geo update_core check_core
#         check_plugin update_plugin dump_custom dump_config watchdog start_nat

source /koolshare/scripts/base.sh
eval $(dbus export mihomo_)

KSHOME=/koolshare
MDIR=$KSHOME/mihomo                  # 持久目录（JFFS）：配置/订阅/规则/面板
RUN=/var/run/mihomo                  # 运行目录（内存）：解压后的内核/日志/pid
BIN=$KSHOME/bin/mihomo               # 插件自带的内核（UPX 压缩，可直接运行）
CORE_GZ=$KSHOME/bin/mihomo.gz        # 在线更新下载的内核（gzip，开机解压到内存运行）
RUN_BIN=$RUN/mihomo
CFG=$MDIR/config.yaml
CUSTOM_CFG=$MDIR/custom.yaml
PIDFILE=$RUN/mihomo.pid
CORE_LOG=$RUN/mihomo.log
LOG=/tmp/upload/mihomo_log.txt
LOCK=/var/lock/mihomo.lock
TAB=$(printf '\t')

REDIR_PORT=7892
TPROXY_PORT=7893
MIXED_PORT=7890
DL_PORT=7895                         # 插件自己下载用：直接走主策略组，不受分流规则影响（比如 GitHub 被分到直连）
DNS_PORT=23453
ROUTING_MARK=255
FWMARK=0x07
RT_TABLE=310
LAN_IF=br0

# 不经过代理的保留地址（注意：198.18.0.0/16 是 fake-ip 段，不能放进来）
FAKE_NET=198.18.0.0/16
RESERVED_NETS="0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.0.0.0/24 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4"

# ---------- 默认值 ----------
[ -z "$mihomo_enable" ] && mihomo_enable=0
[ -z "$mihomo_cfg_mode" ] && mihomo_cfg_mode=sub        # sub | provider | custom
[ -z "$mihomo_dns_mode" ] && mihomo_dns_mode=fake-ip    # fake-ip | redir-host
[ -z "$mihomo_adblock" ] && mihomo_adblock=0          # 0=关闭 1=开启广告屏蔽
[ -z "$mihomo_udp" ] && mihomo_udp=0
[ -z "$mihomo_router_proxy" ] && mihomo_router_proxy=0
[ -z "$mihomo_ui_port" ] && mihomo_ui_port=9090
[ -z "$mihomo_sub_ua" ] && mihomo_sub_ua="clash.meta"
[ -z "$mihomo_sub_interval" ] && mihomo_sub_interval=0  # 小时，0=不自动更新
[ -z "$mihomo_log_level" ] && mihomo_log_level=warning
[ -z "$mihomo_acl_mode" ] && mihomo_acl_mode=all        # all=全部设备 only=只代理指定设备
[ -z "$mihomo_ipv6_block" ] && mihomo_ipv6_block=1      # 1=拒绝局域网 IPv6 DNS，防止绕过
[ -z "$mihomo_boot_delay" ] && mihomo_boot_delay=0      # 开机后额外延迟（秒）
[ -z "$mihomo_auto_update" ] && mihomo_auto_update=1    # 1=每 5 分钟检查并自动更新插件（需填发布地址）
[ -z "$mihomo_github_proxy" ] && mihomo_github_proxy=1  # 1=GitHub 强制走第一个策略组（不管机场规则把它分到哪）
[ -z "$mihomo_geo_auto" ] && mihomo_geo_auto=1          # 1=每周自动更新规则库（GeoSite/GeoIP）
[ -z "$mihomo_store_fakeip" ] && mihomo_store_fakeip=1  # 1=重启后保留 fake-ip 映射（存在内存，定时备份）
[ -z "$mihomo_tun" ] && mihomo_tun=0                    # 1=TUN 模式（实验）
[ -z "$mihomo_core_channel" ] && mihomo_core_channel=stable  # stable=正式版 alpha=测试版
[ -z "$mihomo_webrtc" ] && mihomo_webrtc=proxy          # WebRTC 防泄漏：proxy=STUN 交给 Mihomo 按规则走 block=直接拦截 off=不处理
ADG_URL_DEF="https://magicrule.pages.dev/data/_shared/artifacts/AdGuardSDNSFilterDirect_classical_76ddea0f45cf0c9d.yaml"
ADG_FILE=$MDIR/ruleset/ad_adguard.mrs
STUN_PORTS="3478,3479,5349,19302:19309"   # STUN/TURN 常用端口（浏览器 WebRTC 用它探测真实公网 IP）
TUN_DEV=Meta
TUN_BYPASS_PREF=8999                 # 比内核 auto-route 的规则（9000 起）优先：绕过设备直接查主路由表
TUN_FLAG=$RUN/tun_on                 # 存在 = 当前是 TUN 模式在跑

# ---------- 工具函数 ----------
echo_log() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG"
	logger -t mihomo "$*" 2>/dev/null
}

b64d() {
	[ -z "$1" ] && return 0
	if command -v base64 >/dev/null 2>&1 && echo "$1" | base64 -d >/dev/null 2>&1; then
		echo "$1" | base64 -d 2>/dev/null
	elif command -v base64_decode >/dev/null 2>&1; then
		echo "$1" | base64_decode 2>/dev/null
	else
		echo "$1" | openssl base64 -d -A 2>/dev/null
	fi
}

b64e() {
	if command -v base64 >/dev/null 2>&1; then
		printf '%s' "$1" | base64 | tr -d '\n'
	elif command -v base64_encode >/dev/null 2>&1; then
		printf '%s' "$1" | base64_encode | tr -d '\n'
	else
		printf '%s' "$1" | openssl base64 -A
	fi
}

yaml_q() {
	# 输出 YAML 双引号字符串
	printf '"%s"' "$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g')"
}

json_esc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r'; }

lan_ip() { nvram get lan_ipaddr; }

ip_list() { echo "$1" | tr ',;\n\r' '    '; }

is_running() {
	# 进程在且不是僵尸进程
	local p; [ -f "$PIDFILE" ] && p=$(cat "$PIDFILE") && kill -0 "$p" 2>/dev/null && ! grep -q '^State:[[:space:]]*Z' /proc/$p/status 2>/dev/null
}

get_pid() {
	if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then cat "$PIDFILE"; return; fi
	pidof mihomo | awk '{print $1}'
}

api() {
	# $1=方法 $2=路径 [$3=数据]
	curl -s -m 20 -X "$1" -H "Authorization: Bearer $mihomo_secret" -H "Content-Type: application/json" \
		${3:+-d "$3"} "http://127.0.0.1:$mihomo_ui_port$2" 2>/dev/null
}

# ---------- 内核 ----------
prepare_core() {
	mkdir -p "$RUN"
	# 在线更新过的内核以 gzip 形式存在 JFFS，运行时解压到内存（省 JFFS 空间）
	if [ -f "$CORE_GZ" ]; then
		if [ ! -x "$RUN_BIN" ] || [ "$CORE_GZ" -nt "$RUN_BIN" ]; then
			if gunzip -c "$CORE_GZ" > "$RUN_BIN.tmp" 2>/dev/null && chmod 755 "$RUN_BIN.tmp" && "$RUN_BIN.tmp" -v >/dev/null 2>&1; then
				mv -f "$RUN_BIN.tmp" "$RUN_BIN"
			else
				rm -f "$RUN_BIN.tmp"
				echo_log "警告：在线更新的内核无法使用，改用插件自带内核"
			fi
		fi
		[ -x "$RUN_BIN" ] && BIN=$RUN_BIN
	fi
	[ -f "$BIN" ] || { echo_log "错误：找不到内核文件 $BIN"; return 1; }
	chmod 755 "$BIN" 2>/dev/null
	local v
	v=$($BIN -v 2>/dev/null | head -n1)
	[ -z "$v" ] && { echo_log "错误：内核无法运行，请确认机型为 aarch64"; return 1; }
	dbus set mihomo_core_version="$(echo "$v" | awk '{print $3}')"
	return 0
}

# ---------- 数据存放位置（JFFS / U 盘） ----------
# 选了 U 盘时，大文件放在 <U盘>/mihomo_data，JFFS 里只留软链接；改回 JFFS 时再搬回来
DATA_ITEMS="GeoSite.dat Country.mmdb GeoIP.dat ASN.mmdb ruleset providers core"
case "$mihomo_data_dir" in /tmp/mnt/?*|/mnt/?*) ;; *) mihomo_data_dir="" ;; esac
data_dir() { echo "${mihomo_data_dir%/}/mihomo_data"; }
item_src() { [ "$1" = core ] && echo "$CORE_GZ" || echo "$MDIR/$1"; }
item_tgt() { [ "$1" = core ] && echo "$(data_dir)/mihomo.gz" || echo "$(data_dir)/$1"; }
real_path() { if [ -L "$1" ]; then readlink "$1"; else echo "$1"; fi; }
usb_ready() { [ -n "$mihomo_data_dir" ] && grep -q " ${mihomo_data_dir%/} " /proc/mounts 2>/dev/null && [ -w "$mihomo_data_dir" ]; }
usb_wait() {
	# 开机时 U 盘挂载比较晚，最多等 2 分钟
	local i=0
	booting || i=120
	while ! usb_ready && [ $i -lt 120 ]; do sleep 3; i=$((i+3)); done
	usb_ready
}
kb_of() { [ -e "$1" ] && du -sk "$1" 2>/dev/null | awk '{print $1}' || echo 0; }
kb_free() { df -kP "$1" 2>/dev/null | awk 'NR==2{print $4}'; }

apply_storage() {
	local it src tgt old d need free n=0
	mkdir -p "$MDIR"
	if [ -n "$mihomo_data_dir" ]; then
		if ! usb_wait; then
			echo_log "警告：U 盘 $mihomo_data_dir 没有挂载（或只读），规则库等文件暂时读不到"
			return 1
		fi
		d=$(data_dir); mkdir -p "$d" || { echo_log "错误：无法在 U 盘创建 $d"; return 1; }
		for it in $DATA_ITEMS; do
			src=$(item_src $it); tgt=$(item_tgt $it)
			if [ -L "$src" ]; then
				old=$(readlink "$src")
				[ "$old" = "$tgt" ] && { [ -e "$tgt" ] || case $it in ruleset|providers) mkdir -p "$tgt" ;; esac; continue; }
				rm -f "$src"
				[ -e "$old" ] && [ ! -e "$tgt" ] && cp -rf "$old" "$tgt" 2>/dev/null
			fi
			if [ -e "$src" ]; then
				rm -rf "$tgt.tmp"
				if cp -rf "$src" "$tgt.tmp" 2>/dev/null; then
					rm -rf "$tgt"; mv -f "$tgt.tmp" "$tgt" && rm -rf "$src" && n=$((n+1))
				else
					rm -rf "$tgt.tmp"; echo_log "警告：$it 复制到 U 盘失败，先留在 JFFS"; continue
				fi
			fi
			case $it in ruleset|providers) mkdir -p "$tgt" ;; esac
			[ -e "$tgt" ] && [ ! -e "$src" ] && ln -s "$tgt" "$src"
		done
		[ $n -gt 0 ] && echo_log "已把 $n 项数据搬到 U 盘 $d，JFFS 剩余 $(( $(kb_free "$MDIR") / 1024 )) MB"
	else
		for it in $DATA_ITEMS; do
			src=$(item_src $it)
			[ -L "$src" ] || continue
			old=$(readlink "$src")
			if [ ! -e "$old" ]; then
				[ -d "$(dirname "$old")" ] && rm -f "$src"   # U 盘在、文件不在：直接去掉链接
				continue
			fi
			need=$(( $(kb_of "$old") + 512 )); free=$(kb_free "$MDIR")
			if [ -n "$free" ] && [ "$free" -lt "$need" ]; then
				echo_log "警告：JFFS 空间不够（$it 需要约 ${need}KB），继续放在 U 盘"; continue
			fi
			rm -rf "$src.tmp"
			if cp -rf "$old" "$src.tmp" 2>/dev/null; then
				rm -f "$src"; mv -f "$src.tmp" "$src"; n=$((n+1))
			else
				rm -rf "$src.tmp"; echo_log "警告：$it 搬回 JFFS 失败，继续使用 U 盘"
			fi
		done
		[ $n -gt 0 ] && echo_log "已把 $n 项数据搬回 JFFS（U 盘上的副本保留，可手动删除）"
	fi
	return 0
}

dump_storage() {
	# 给设置页显示：JFFS 剩余、可用 U 盘
	local f=/tmp/upload/mihomo_storage.txt m it used=0
	mkdir -p /tmp/upload
	for it in $DATA_ITEMS; do [ -L "$(item_src $it)" ] || used=$((used + $(kb_of "$(item_src $it)"))); done
	{
		echo "jffs $(df -kP /jffs | awk 'NR==2{print $4" "$2}') $used"
		awk '$2 ~ "^/tmp/mnt/[^\\\\]+$" && $4 ~ /^rw/ {print $2" "$3}' /proc/mounts | sort -u | while read -r m t; do
			echo "usb $m $(df -kP "$m" | awk 'NR==2{print $4" "$2}') $t"
		done
	} > "$f"
}

# ---------- 下载 ----------
fetch_to() {
	# $1=地址 $2=输出文件 $3=UA $4=超时秒 [$5=保存响应头的文件]
	# 直连 / 走 Mihomo 代理（mixed 端口）两种方式按顺序尝试：
	#  - GitHub、jsdelivr 等境外文件站：Mihomo 在运行时先走代理（国内直连常常只有几 KB/s）；
	#  - 其它（如机场订阅）：先直连，失败再走代理。
	# 任一方式下载速度连续 20 秒低于 20KB/s 就放弃、换下一种，不会一直卡着等超时。
	local url="$1" out="$2" ua="$3" t="${4:-90}" hdr="${5:-/dev/null}" order="direct proxy" m
	local slow="--speed-limit 20480 --speed-time 20"
	if is_running; then
		case "$url" in
		*github.com*|*githubusercontent.com*|*gh-proxy.com*|*jsdelivr.net*|*ghfast.top*|*.pages.dev*) order="proxy direct" ;;
		esac
	else
		order="direct"
	fi
	for m in $order; do
		rm -f "$out"
		if [ "$m" = "direct" ]; then
			curl -fsSL --connect-timeout 10 -m "$t" $slow -A "$ua" -D "$hdr" -o "$out" "$url" 2>/dev/null && return 0
		else
			curl -fsSL --connect-timeout 10 -m "$t" $slow -x "http://127.0.0.1:$(grep -q '^  - name: mh-dl$' "$CFG" 2>/dev/null && echo $DL_PORT || echo $MIXED_PORT)" -A "$ua" -D "$hdr" -o "$out" "$url" 2>/dev/null && return 0
		fi
		[ -n "$QUIET" ] || [ "$m" = "${order##* }" ] || echo_log "$([ "$m" = direct ] && echo 直连 || echo 代理)下载失败或太慢，换另一种方式重试..."
	done
	rm -f "$out"
	# 最后兜底：没有 curl 时用 wget 直连
	command -v curl >/dev/null 2>&1 || { wget -q -T 30 -U "$ua" -O "$out" "$url" 2>/dev/null && return 0; }
	rm -f "$out"
	return 1
}

fetch_gh() {
	# GitHub 文件：原地址失败再试 gh-proxy 加速
	fetch_to "$1" "$2" "Mozilla/5.0" "${3:-120}" && return 0
	[ -n "$QUIET" ] || echo_log "改用 gh-proxy 加速地址重试..."
	fetch_to "https://gh-proxy.com/$1" "$2" "Mozilla/5.0" "${3:-120}"
}

# ---------- 热重载 ----------
reload_core() {
	# 通过内核接口换用新配置：已有连接不断开，fake-ip 地址映射也保留；失败返回 1
	is_running || return 1
	local code
	code=$(curl -s -o /dev/null -w '%{http_code}' -m 30 -X PUT \
		-H "Authorization: Bearer $mihomo_secret" -H "Content-Type: application/json" \
		-d "{\"path\":\"$CFG\"}" "http://127.0.0.1:$mihomo_ui_port/configs?force=true" 2>/dev/null)
	[ "$code" = "204" ] || [ "$code" = "200" ] || return 1
	sleep 2
	ports_ok
}

# ---------- 多订阅 ----------
# mihomo_subs        : base64( 每行「名称<TAB>地址」 )
# mihomo_sub_active  : 当前订阅 id（地址 md5 前 8 位）
# mihomo_subinfo_<id>: 流量/到期，如 upload=1;download=2;total=3;expire=4 或 left=120 GB;expire_date=2026-12-01
# mihomo_subtime_<id>: 上次更新时间
subs_lines() { b64d "$mihomo_subs" | sed 's/\r$//' | grep -v '^[[:space:]]*$'; }
sub_id() { printf '%s' "$1" | md5sum | cut -c1-8; }

migrate_subs() {
	# 旧版只有一个 mihomo_sub_url，自动转成「默认订阅」
	[ -n "$mihomo_subs" ] && return 0
	local url id
	url=$(b64d "$mihomo_sub_url")
	[ -z "$url" ] && return 0
	id=$(sub_id "$url")
	mihomo_subs=$(b64e "$(printf '默认订阅\t%s' "$url")")
	dbus set mihomo_subs="$mihomo_subs"
	mihomo_sub_active=$id; dbus set mihomo_sub_active="$id"
	[ -f "$MDIR/sub.yaml" ] && mv -f "$MDIR/sub.yaml" "$MDIR/sub_$id.yaml"
	[ -n "$mihomo_sub_time" ] && dbus set mihomo_subtime_$id="$mihomo_sub_time"
	echo_log "已把旧版订阅迁移为「默认订阅」"
}

resolve_active() {
	# 设置 ACT_ID / ACT_NAME / ACT_URL；当前订阅不存在时用第一个
	ACT_ID=""; ACT_NAME=""; ACT_URL=""
	local f=/tmp/mihomo_subs.$$ name url id fid="" fname="" furl=""
	subs_lines > "$f"
	while IFS="$TAB" read -r name url; do
		[ -z "$url" ] && continue
		id=$(sub_id "$url")
		[ -z "$fid" ] && { fid=$id; fname=$name; furl=$url; }
		if [ "$id" = "$mihomo_sub_active" ]; then ACT_ID=$id; ACT_NAME=$name; ACT_URL=$url; break; fi
	done < "$f"
	rm -f "$f"
	if [ -z "$ACT_ID" ] && [ -n "$fid" ]; then ACT_ID=$fid; ACT_NAME=$fname; ACT_URL=$furl; fi
	[ -n "$ACT_ID" ] && [ "$ACT_ID" != "$mihomo_sub_active" ] && { mihomo_sub_active=$ACT_ID; dbus set mihomo_sub_active="$ACT_ID"; }
	# 兼容：mihomo_sub_url 始终等于当前订阅
	if [ -n "$ACT_URL" ]; then local u; u=$(b64e "$ACT_URL"); [ "$u" = "$mihomo_sub_url" ] || { mihomo_sub_url=$u; dbus set mihomo_sub_url="$u"; }; fi
	return 0
}

find_sub() {
	# $1=id → 设置 F_NAME / F_URL
	F_NAME=""; F_URL=""
	local f=/tmp/mihomo_subs.$$ name url
	subs_lines > "$f"
	while IFS="$TAB" read -r name url; do
		[ -n "$url" ] && [ "$(sub_id "$url")" = "$1" ] && { F_NAME=$name; F_URL=$url; break; }
	done < "$f"
	rm -f "$f"
	[ -n "$F_URL" ]
}

save_subinfo() {
	# $1=id $2=响应头文件 $3=订阅文件
	local id="$1" ui left exp
	ui=$(grep -i '^subscription-userinfo:' "$2" 2>/dev/null | tail -n1 | cut -d: -f2- | tr -d ' \r')
	if [ -n "$ui" ]; then
		dbus set mihomo_subinfo_$id="$ui"; return 0
	fi
	# 兜底：机场常把流量/到期写成假节点名，如「剩余流量：120.5 GB」「套餐到期：2026-12-01」
	left=$(grep -oE '(剩余流量|流量剩余)(:|：) *[0-9.]+ *[KMGTP]?i?B' "$3" 2>/dev/null | head -n1 | sed -E 's/^.*(:|：) *//')
	exp=$(grep -oE '(套餐到期|到期时间|过期时间)(:|：) *[0-9]{4}-[0-9]{2}-[0-9]{2}' "$3" 2>/dev/null | head -n1 | sed -E 's/^.*(:|：) *//')
	if [ -n "$left$exp" ]; then dbus set mihomo_subinfo_$id="left=$left;expire_date=$exp"; else dbus remove mihomo_subinfo_$id; fi
}

provider_info_sync() {
	# 「节点订阅」模式由内核自己下载订阅，流量信息从内核接口读
	is_running || return 0
	local f=/tmp/mihomo_subs.$$ name url id j si up dn tot ex
	subs_lines > "$f"
	while IFS="$TAB" read -r name url; do
		[ -z "$url" ] && continue
		id=$(sub_id "$url")
		j=$(api GET "/providers/proxies/sub_$id")
		si=$(echo "$j" | grep -o '"subscriptionInfo":{[^}]*}')
		[ -z "$si" ] && continue
		up=$(echo "$si" | grep -o '"Upload":[0-9]*' | cut -d: -f2)
		dn=$(echo "$si" | grep -o '"Download":[0-9]*' | cut -d: -f2)
		tot=$(echo "$si" | grep -o '"Total":[0-9]*' | cut -d: -f2)
		ex=$(echo "$si" | grep -o '"Expire":[0-9]*' | cut -d: -f2)
		[ -n "$up$dn$tot" ] && dbus set mihomo_subinfo_$id="upload=${up:-0};download=${dn:-0};total=${tot:-0};expire=${ex:-0}"
	done < "$f"
	rm -f "$f"
}

write_subinfo_json() {
	# 给控制面板读：ui/subinfo.json（不含订阅地址）
	[ -d "$MDIR/ui" ] || return 0
	local f=/tmp/mihomo_subs.$$ out="$MDIR/ui/subinfo.json.tmp" first=1 name url id act
	subs_lines > "$f"
	{
		local st="" dm=""; is_running && st=$(date -r "$PIDFILE" +%s 2>/dev/null)
		[ -f "$CFG" ] && dm=$(awk '/^dns:/{f=1;next} f&&/^[^ \t#]/{exit} f&&/^[ \t]+enhanced-mode:/{gsub(/["\047]/,"",$2);print $2;exit}' "$CFG")
		printf '{"mode":"%s","started":"%s","dns":"%s","tun":%s,"subs":[' "$mihomo_cfg_mode" "$st" "${dm:-normal}" "$([ -f "$TUN_FLAG" ] && echo true || echo false)"
		while IFS="$TAB" read -r name url; do
			[ -z "$url" ] && continue
			id=$(sub_id "$url")
			[ $first = 1 ] || printf ','
			first=0
			act=false; [ "$id" = "$ACT_ID" ] && act=true
			printf '{"id":"%s","name":"%s","active":%s,"info":"%s","time":"%s"}' \
				"$id" "$(json_esc "$name")" "$act" "$(json_esc "$(dbus get mihomo_subinfo_$id)")" "$(dbus get mihomo_subtime_$id)"
		done < "$f"
		printf ']}'
	} > "$out" 2>/dev/null && mv -f "$out" "$MDIR/ui/subinfo.json"
	rm -f "$f" "$out"
}

count_nodes() {
	# 只数 proxies: 段里的节点
	awk '/^proxies:/{f=1;next} f&&/^[^ \t#-]/{f=0} f&&/^[ \t]*-[ \t]*(\{[ \t]*)?name:/{n++} f&&/^[ \t]*-[ \t]*$/{n++} END{print n+0}' "$1" 2>/dev/null
}

download_sub() {
	# $1=id $2=名称 $3=地址
	local id="$1" name="$2" url="$3" tmp hdr
	[ -z "$url" ] && { echo_log "错误：还没有添加订阅"; return 1; }
	tmp=/tmp/mihomo_sub.$$; hdr=/tmp/mihomo_hdr.$$
	echo_log "下载订阅「$name」（UA: $mihomo_sub_ua）..."
	fetch_to "$url" "$tmp" "$mihomo_sub_ua" 90 "$hdr" || { rm -f "$tmp" "$hdr"; tg_notify sub "⚠️ 订阅「$(html_esc "$name")」下载失败"; echo_log "错误：订阅下载失败，请检查地址或网络"; return 1; }
	# 去掉 BOM 与 CR
	sed -i '1s/^\xEF\xBB\xBF//; s/\r$//' "$tmp"
	if ! grep -qE '^(proxies|proxy-providers):' "$tmp"; then
		echo_log "错误：订阅内容不是 Clash/Mihomo YAML 格式（可能是 base64 节点列表）"
		echo_log "提示：这类订阅请把「配置模式」改为「节点订阅 + 内置规则」"
		rm -f "$tmp" "$hdr"; return 1
	fi
	# 防止机场返回「流量用完 / 已过期」之类的残缺配置把好订阅覆盖掉
	local newn oldn=0
	newn=$(count_nodes "$tmp")
	[ -f "$MDIR/sub_$id.yaml" ] && oldn=$(count_nodes "$MDIR/sub_$id.yaml")
	if [ "$mihomo_sub_force" != "1" ]; then
		if [ "$newn" -eq 0 ] && ! grep -q '^proxy-providers:' "$tmp"; then
			echo_log "错误：新订阅里一个节点都没有（可能已过期或流量用完），已保留旧订阅"
			echo "SUB_GUARD $id" >> "$LOG"; rm -f "$tmp" "$hdr"
			tg_notify sub "⚠️ 订阅「$(html_esc "$name")」新内容没有节点（可能过期或流量用完），已保留旧订阅"; return 1
		fi
		if [ "$oldn" -ge 5 ] && [ $((newn * 10)) -lt $((oldn * 3)) ]; then
			echo_log "警告：新订阅只有 $newn 个节点（原来 $oldn 个），像是机场返回了异常内容，已保留旧订阅"
			echo "SUB_GUARD $id" >> "$LOG"; rm -f "$tmp" "$hdr"
			tg_notify sub "⚠️ 订阅「$(html_esc "$name")」节点从 $oldn 个骤减到 $newn 个，已保留旧订阅。确认没问题可到插件订阅页强制更新"; return 1
		fi
	else
		echo_log "强制更新：跳过节点数量检查（新 $newn 个，原 $oldn 个）"
	fi
	mkdir -p "$MDIR"
	[ -f "$MDIR/sub_$id.yaml" ] && cp -f "$MDIR/sub_$id.yaml" "$MDIR/sub_$id.yaml.bak"
	mv -f "$tmp" "$MDIR/sub_$id.yaml"
	save_subinfo "$id" "$hdr" "$MDIR/sub_$id.yaml"
	rm -f "$hdr"
	dbus set mihomo_subtime_$id="$(date '+%Y-%m-%d %H:%M')"
	[ "$id" = "$ACT_ID" ] && dbus set mihomo_sub_time="$(date '+%Y-%m-%d %H:%M')"
	echo_log "订阅「$name」下载完成：$(grep -cE '^\s*- *\{?\s*name:' "$MDIR/sub_$id.yaml") 个条目"
	return 0
}

# ---------- 配置生成 ----------
gen_header() {
	local dns_listen="0.0.0.0:$DNS_PORT"
	# 系统有 IPv6 协议栈时用双栈监听（IPv4 照常可用）
	[ -f /proc/net/if_inet6 ] && dns_listen="'[::]:$DNS_PORT'"
	cat <<EOF
# ======== 由 Mihomo 插件生成，请勿直接修改 ========
mixed-port: $MIXED_PORT
redir-port: $REDIR_PORT
tproxy-port: $TPROXY_PORT
allow-lan: true
bind-address: "*"
mode: rule
log-level: $mihomo_log_level
ipv6: false
unified-delay: true
tcp-concurrent: true
find-process-mode: off
routing-mark: $ROUTING_MARK
external-controller: 0.0.0.0:$mihomo_ui_port
secret: $(yaml_q "$mihomo_secret")
external-ui: ui
geodata-mode: false
geodata-loader: memconservative
geo-auto-update: false
geox-url:
  geoip: "https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geoip.dat"
  geosite: "https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geosite.dat"
  mmdb: "https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/country-lite.mmdb"
  asn: "https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/GeoLite2-ASN.mmdb"
profile:
  store-selected: true
  store-fake-ip: $([ "$mihomo_store_fakeip" = "1" ] && echo true || echo false)
sniffer:
  enable: true
  force-dns-mapping: true
  parse-pure-ip: true
  override-destination: true
  sniff:
    HTTP:
      ports: [80, 8080-8880]
    TLS:
      ports: [443, 8443]
    QUIC:
      ports: [443, 8443]
  skip-domain:
    - "Mijia Cloud"
    - "+.push.apple.com"
dns:
  enable: true
  listen: $dns_listen
  ipv6: false
  enhanced-mode: $mihomo_dns_mode
  fake-ip-range: 198.18.0.1/16
$(fakeip_filter_yaml)
  respect-rules: true
  default-nameserver:
    - 223.5.5.5
    - 119.29.29.29
  proxy-server-nameserver:
    - https://doh.pub/dns-query
    - https://dns.alidns.com/dns-query
  direct-nameserver:
    - https://doh.pub/dns-query
    - https://dns.alidns.com/dns-query
  nameserver:
    - https://1.1.1.1/dns-query
    - https://8.8.8.8/dns-query
  nameserver-policy:
    "+.lan,+.local,+.localdomain,+.home.arpa,router.asus.com,+.asusrouter.com": "127.0.0.1:53"
    "geosite:cn,private": [https://doh.pub/dns-query, https://dns.alidns.com/dns-query]
EOF
	[ "$USE_TUN" = "1" ] && tun_yaml
	echo "# ======== 以上为插件接管部分 ========"
}
# 不走 fake-ip 的域名：这些需要真实 IP（局域网、对时、联机/语音打洞、系统联网检测）
FAKEIP_SKIP="*.lan *.local *.localdomain *.home.arpa +.asusrouter.com router.asus.com +.msftconnecttest.com +.msftncsi.com time.*.com ntp.*.com +.pool.ntp.org +.stun.*.* +.stun.*.*.* stun.*.* +.srv.nintendo.net +.stun.playstation.net xbox.*.microsoft.com +.xboxlive.com localhost.ptlogin2.qq.com"
fakeip_filter_yaml() {
	local d r
	set -f
	if [ "$FAKEIP_LEGACY" = "1" ]; then
		# 老内核不认识规则写法：用旧的域名列表
		echo "  fake-ip-filter:"
		for d in $FAKEIP_SKIP; do echo "    - \"$d\""; done
		set +f; return
	fi
	# 规则写法（新内核）：从上往下匹配，最后 MATCH 走 fake-ip
	echo "  fake-ip-filter-mode: rule"
	echo "  fake-ip-filter:"
	echo "    - GEOSITE,private,real-ip"
	for d in $FAKEIP_SKIP; do
		case "$d" in
		*'*'*)
			# 带通配符的写成正则：* = 一段，+. = 自身及所有子域名
			r=$(printf '%s' "$d" | sed -e 's/\./\\./g' -e 's/\*/[^.]+/g' -e 's/^+\\\./(.+\\.)?/')
			echo "    - 'DOMAIN-REGEX,^$r\$,real-ip'" ;;
		+.*) echo "    - DOMAIN-SUFFIX,${d#+.},real-ip" ;;
		*) echo "    - DOMAIN,$d,real-ip" ;;
		esac
	done
	echo "    - MATCH,fake-ip"
	set +f
}
tun_yaml() {
	local n
	cat <<EOF
tun:
  enable: true
  device: $TUN_DEV
  stack: system
  auto-route: true
  auto-detect-interface: true
  include-interface:
    - $LAN_IF
  dns-hijack:
    - any:53
  route-exclude-address:
EOF
	for n in $RESERVED_NETS; do echo "    - $n"; done
}

# 订阅 YAML 中需由插件接管的顶层字段
DROP_KEYS="|port|socks-port|mixed-port|redir-port|tproxy-port|allow-lan|bind-address|mode|log-level|ipv6|unified-delay|tcp-concurrent|find-process-mode|routing-mark|interface-name|external-controller|external-controller-tls|external-controller-unix|external-controller-pipe|external-controller-cors|external-doh-server|external-ui|external-ui-name|external-ui-url|secret|geodata-mode|geodata-loader|geo-auto-update|geo-update-interval|geox-url|profile|sniffer|dns|tun|iptables|ebpf|auto-redirect|listeners|tunnels|"

strip_keys() {
	# 删除顶层字段及其子块（包括列顶格写法 "- xxx"）；$2 可指定要删的字段表（默认 DROP_KEYS）
	awk -v drop="${2:-$DROP_KEYS}" '
	/^[A-Za-z0-9_"\047][^:]*:/ {
		k=$0; sub(/:.*/, "", k); gsub(/["\047 ]/, "", k)
		skip = (index(drop, "|" k "|") > 0)
	}
	!skip { print }
	' "$1"
}

user_rules() {
	# 自定义规则（每行一条，如 DOMAIN-SUFFIX,example.com,DIRECT）
	b64d "$mihomo_rules" | sed 's/\r$//; s/^[ \t]*-[ \t]*//; s/^[ \t]*//; s/[ \t]*$//' | grep -v '^#' | grep -v '^$'
}

dev_rules() {
	# 设备专用策略：每行「IP 策略组」→ SRC-IP-CIDR,IP/32,策略组
	b64d "$mihomo_dev_rules" | sed 's/\r$//' | grep -v '^[ \t]*#' | while IFS= read -r l; do
		ip=$(echo "$l" | sed 's/^[ \t]*\([0-9.\/]*\).*/\1/')
		grp=$(echo "$l" | sed 's/^[ \t]*[0-9.\/]*[ \t,]*//; s/[ \t]*$//')
		[ -z "$ip" ] || [ -z "$grp" ] && continue
		case "$ip" in */*) ;; *) ip="$ip/32" ;; esac
		echo "SRC-IP-CIDR,$ip,$grp"
	done
}

# ---------- 去广告放行名单 ----------
# 名单里的域名（含子域名）跳过所有去广告规则，之后照常按订阅规则走（该走节点的照样走节点）。
# 做法：每条去广告规则改写成 AND,((原规则),(NOT,((RULE-SET,ad_allow)))),REJECT
ad_allow_list() {
	b64d "$mihomo_ad_allow" | tr ',; \t' '\n\n\n\n' | sed 's/\r$//; s#^[a-zA-Z]*://##; s#[/:?].*##; s/^\*\.//; s/^+\.//; s/^\.//' \
		| tr 'A-Z' 'a-z' | grep -E '^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$' | sort -u
}
ad_allow_on() { [ -n "$(ad_allow_list | head -1)" ]; }
ad_wrap() {
	# $1=all：每行都是去广告规则；$1=ov：只改写插件自带的去广告规则集那几行
	if [ "$AD_ALLOW" != "1" ]; then cat; return; fi
	if [ "$1" = ov ]; then
		sed -E 's/^(RULE-SET,ad_(adguard|awavenue|217heidai)),REJECT$/AND,((\1),(NOT,((RULE-SET,ad_allow)))),REJECT/'
	else
		sed 's/^\(.*\),REJECT$/AND,((\1),(NOT,((RULE-SET,ad_allow)))),REJECT/'
	fi
}
adblock_rules() {
	# 广告屏蔽规则：只在 mihomo_adblock=1 时输出。
	# 原理是网络层域名拦截，只能拦第三方广告/追踪域名：
	#  - GEOSITE,category-ads-all：内核自带 GeoSite 库里的广告分类，覆盖面最广；
	#  - 下面是常见广告域名兜底，即使 GeoSite 库版本里没有该分类也能拦住大头。
	# 放行办法：自定义规则里在前面写一条 DIRECT（自定义规则排在广告规则前面）。
	[ "$mihomo_adblock" = "1" ] || return 0
	cat <<'EOF'
GEOSITE,category-ads-all,REJECT
DOMAIN-SUFFIX,doubleclick.net,REJECT
DOMAIN-SUFFIX,googlesyndication.com,REJECT
DOMAIN-SUFFIX,googleadservices.com,REJECT
DOMAIN-SUFFIX,googleads.g.doubleclick.net,REJECT
DOMAIN-SUFFIX,ads.google.com,REJECT
DOMAIN-SUFFIX,adservice.google.com,REJECT
DOMAIN-SUFFIX,pagead2.googlesyndication.com,REJECT
DOMAIN-SUFFIX,ad.doubleclick.net,REJECT
DOMAIN-SUFFIX,static.doubleclick.net,REJECT
DOMAIN-SUFFIX,tpc.googlesyndication.com,REJECT
DOMAIN-SUFFIX,google-analytics.com,REJECT
DOMAIN-SUFFIX,analytics.google.com,REJECT
DOMAIN-SUFFIX,amazon-adsystem.com,REJECT
DOMAIN-SUFFIX,ads.yahoo.com,REJECT
DOMAIN-SUFFIX,ads.bing.com,REJECT
DOMAIN-SUFFIX,adnxs.com,REJECT
DOMAIN-SUFFIX,adsrvr.org,REJECT
DOMAIN-SUFFIX,criteo.com,REJECT
DOMAIN-SUFFIX,outbrain.com,REJECT
DOMAIN-SUFFIX,taboola.com,REJECT
DOMAIN-SUFFIX,moatads.com,REJECT
DOMAIN-SUFFIX,scorecardresearch.com,REJECT
DOMAIN-SUFFIX,cpro.baidu.com,REJECT
DOMAIN-SUFFIX,pos.baidu.com,REJECT
DOMAIN-SUFFIX,union.baidu.com,REJECT
DOMAIN-SUFFIX,hm.baidu.com,REJECT
DOMAIN-SUFFIX,mobads.baidu.com,REJECT
DOMAIN-SUFFIX,e.baidu.com,REJECT
DOMAIN-SUFFIX,ad.sogou.com,REJECT
DOMAIN-SUFFIX,union.sogou.com,REJECT
DOMAIN-SUFFIX,tanx.alicdn.com,REJECT
DOMAIN-SUFFIX,atanx.alicdn.com,REJECT
DOMAIN-SUFFIX,mmstat.com,REJECT
DOMAIN-SUFFIX,ad.qq.com,REJECT
DOMAIN-SUFFIX,pgdt.gtimg.com,REJECT
DOMAIN-SUFFIX,union.360.cn,REJECT
DOMAIN-SUFFIX,ad.360.cn,REJECT
EOF
}

# ---------- 覆写（混入） ----------
adrules_overlay() {
	# 内置去广告规则集（勾选后作为覆写的一部分合并进配置）
	local a=",$mihomo_adrules," any=0 allow=0 d
	case "$a" in *,awavenue,*|*,heidai,*|*,heidai_lite,*|*,adguard,*) any=1 ;; esac
	{ [ $any = 1 ] || [ "$mihomo_adblock" = "1" ]; } && ad_allow_on && allow=1
	[ $any = 1 ] || [ $allow = 1 ] || return 0
	echo "rule-providers:"
	if [ $allow = 1 ]; then
		printf '  ad_allow:\n    type: inline\n    behavior: domain\n    payload:\n'
		ad_allow_list | while read -r d; do echo "      - '+.$d'"; done
	fi
	[ $any = 1 ] || return 0
	case "$a" in *,awavenue,*) cat <<'EOF'
  ad_awavenue:
    type: http
    behavior: domain
    format: yaml
    url: "https://testingcf.jsdelivr.net/gh/TG-Twilight/AWAvenue-Ads-Rule@main/Filters/AWAvenue-Ads-Rule-Clash.yaml"
    path: ./ruleset/ad_awavenue.yaml
    interval: 86400
EOF
	;; esac
	case "$a" in
	*,heidai,*) cat <<'EOF'
  ad_217heidai:
    type: http
    behavior: domain
    format: mrs
    url: "https://gh-proxy.com/https://github.com/217heidai/adblockfilters/releases/download/rule/adblockmihomo.mrs"
    path: ./ruleset/ad_217heidai.mrs
    interval: 86400
EOF
	;;
	*,heidai_lite,*) cat <<'EOF'
  ad_217heidai:
    type: http
    behavior: domain
    format: mrs
    url: "https://gh-proxy.com/https://github.com/217heidai/adblockfilters/releases/download/rule/adblockmihomolite.mrs"
    path: ./ruleset/ad_217heidai_lite.mrs
    interval: 86400
EOF
	;; esac
	case "$a" in *,adguard,*) cat <<'EOF'
  ad_adguard:
    type: file
    behavior: domain
    format: mrs
    path: ./ruleset/ad_adguard.mrs
EOF
	;; esac
	echo "rules:"
	case "$a" in *,adguard,*) echo "  - RULE-SET,ad_adguard,REJECT" ;; esac
	case "$a" in *,awavenue,*) echo "  - RULE-SET,ad_awavenue,REJECT" ;; esac
	case "$a" in *,heidai,*|*,heidai_lite,*) echo "  - RULE-SET,ad_217heidai,REJECT" ;; esac
}

# ---------- AdGuard DNS 过滤（大而全）----------
# 原文件是 18 万多条「DOMAIN,xxx」逐条规则（classical），直接给内核用又慢又占内存；
# 这里下载后转成纯域名列表，再用内核自带的 convert-ruleset 压成 .mrs（体积小、加载快、匹配快）
adg_on() { case ",$mihomo_adrules," in *,adguard,*) return 0 ;; esac; return 1; }
adg_stale() { [ ! -s "$ADG_FILE" ] || [ -n "$(find "$ADG_FILE" -mmin +1380 2>/dev/null)" ]; }
update_adguard() {
	local url="${mihomo_adg_url:-$ADG_URL_DEF}" t=/tmp/mihomo_adg n need free old
	mkdir /tmp/mihomo_adg.lock 2>/dev/null || { echo_log "AdGuard 规则正在更新中，跳过"; return 0; }
	echo_log "下载 AdGuard DNS 过滤规则..."
	if ! fetch_to "$url" "$t.src" "clash.meta" 300; then
		rm -rf "$t".* /tmp/mihomo_adg.lock
		echo_log "错误：AdGuard 规则下载失败，继续使用旧规则$([ -s "$ADG_FILE" ] || echo '（目前还没有，暂不生效）')"
		return 1
	fi
	sed -n -e "s/^[[:space:]]*\(-[[:space:]]*\)\{0,1\}['\"]\{0,1\}DOMAIN,\([^'\",[:space:]]*\).*/\2/p" \
		-e "s/^[[:space:]]*\(-[[:space:]]*\)\{0,1\}['\"]\{0,1\}DOMAIN-SUFFIX,\([^'\",[:space:]]*\).*/+.\2/p" "$t.src" > "$t.txt"
	rm -f "$t.src"
	n=$(wc -l < "$t.txt" | tr -d ' ')
	if [ "${n:-0}" -lt 1000 ]; then
		rm -rf "$t".* /tmp/mihomo_adg.lock
		echo_log "错误：AdGuard 规则内容异常（只有 ${n:-0} 条域名），未替换旧规则"
		return 1
	fi
	prepare_core >/dev/null 2>&1
	if ! "$BIN" convert-ruleset domain text "$t.txt" "$t.mrs" >/dev/null 2>&1 || [ ! -s "$t.mrs" ]; then
		rm -rf "$t".* /tmp/mihomo_adg.lock
		echo_log "错误：内核无法转换 AdGuard 规则（内核太旧？请更新内核）"
		return 1
	fi
	rm -f "$t.txt"
	mkdir -p "$MDIR/ruleset"
	need=$(du -k "$t.mrs" | awk '{print $1}')
	old=0; [ -f "$ADG_FILE" ] && old=$(du -k "$ADG_FILE" | awk '{print $1}')
	free=$(df -kP "$MDIR/ruleset/" 2>/dev/null | awk 'NR==2{print $4}')
	if [ -n "$free" ] && [ $((free + old)) -lt $((need + 64)) ]; then
		rm -rf "$t".* /tmp/mihomo_adg.lock
		echo_log "错误：存储空间不足（需要 ${need}KB），AdGuard 规则未保存。可在「存储」里改用 U 盘"
		return 1
	fi
	cp -f "$t.mrs" "$ADG_FILE.tmp" && mv -f "$ADG_FILE.tmp" "$ADG_FILE"
	rm -rf "$t".* /tmp/mihomo_adg.lock
	echo_log "AdGuard DNS 过滤规则已更新：$n 个域名（${need}KB）"
	if is_running; then
		api PUT /providers/rules/ad_adguard >/dev/null && echo_log "AdGuard 规则已生效（无需重启）"
	fi
	return 0
}
# ---------- 找出被拦截的域名 ----------
# 订阅内核的实时日志（info 级别会记录每条 REJECT 命中），记录一段时间，汇总成「域名 / 哪条规则拦的 / 次数」
TRACE_OUT=/tmp/upload/mihomo_adtrace.txt
ad_trace() {
	local secs=${mihomo_trace_secs:-60} raw=/tmp/mihomo_trace.raw pid i n
	case "$secs" in ''|*[!0-9]*) secs=60 ;; esac
	[ "$secs" -gt 300 ] && secs=300; [ "$secs" -lt 10 ] && secs=10
	if ! is_running; then echo_log "错误：Mihomo 没有运行，无法记录"; return 1; fi
	echo_log "开始记录被拦截的域名，共 $secs 秒。"
	echo_log "现在去手机 / 电脑上打开有问题的网页，播放视频、刷新几次……"
	rm -f "$raw"
	curl -sN -m "$secs" -H "Authorization: Bearer $mihomo_secret" "http://127.0.0.1:$mihomo_ui_port/logs?level=info" > "$raw" 2>/dev/null &
	pid=$!
	i=0
	while [ $i -lt "$secs" ] && kill -0 $pid 2>/dev/null; do
		sleep 5; i=$((i + 5))
		[ $((i % 15)) = 0 ] && [ $i -lt "$secs" ] && { n=$(grep -c 'using REJECT' "$raw" 2>/dev/null); echo_log "已记录 ${i} 秒，拦截 ${n:-0} 次..."; }
	done
	wait $pid 2>/dev/null
	# 插件内置的广告域名，用来区分「内置」和「订阅自带」的 REJECT
	( mihomo_adblock=1; adblock_rules ) | sed -n 's/^DOMAIN-SUFFIX,\(.*\),REJECT$/\1/p' > "$raw.bi"
	sed -n 's/.*--\\u003e \([^ ]*\):[0-9]* match \(.*\) using REJECT.*/\1|\2/p; s/.*--> \([^ ]*\):[0-9]* match \(.*\) using REJECT.*/\1|\2/p' "$raw" | awk -F'|' -v bf="$raw.bi" '
	BEGIN { while ((getline l < bf) > 0) bi["DomainSuffix(" l ")"]=1 }
	{
		r=$2
		if (r ~ /ad_adguard/) s="AdGuard";
		else if (r ~ /ad_awavenue/) s="秋风";
		else if (r ~ /ad_217heidai/) s="217heidai";
		else if (r ~ /category-ads/) s="内置（GeoSite 广告分类）";
		else if (r ~ /ad_allow/ || (r in bi)) s="内置广告域名";
		else s="订阅自带规则";
		c[$1 "|" s]++
	}
	END { for (k in c) print c[k] "|" k }' | sort -t'|' -k1,1rn | head -n 60 | awk -F'|' '{print $2 "|" $3 "|" $1}' > "$TRACE_OUT.tmp"
	rm -f "$raw.bi"
	mv -f "$TRACE_OUT.tmp" "$TRACE_OUT"
	rm -f "$raw"
	n=$(wc -l < "$TRACE_OUT" | tr -d ' ')
	if [ "$n" = 0 ]; then
		echo_log "记录结束：这段时间没有域名被拦截。如果网页还是有问题，可能不是去广告导致的"
	else
		echo_log "记录结束：共 $n 个域名被拦截（次数多的在前）："
		awk -F'|' '{printf "  %s  ←%s ×%s\n", $1, $2, $3}' "$TRACE_OUT" >> "$LOG"
		echo_log "到「去广告」卡片里可以一键把需要的域名加入放行名单"
		grep -q '订阅自带规则' "$TRACE_OUT" && echo_log "提示：「订阅自带规则」拦的不受放行名单控制，需要在「自定义规则」里写一条放行"
	fi
	return 0
}
adg_bg() {
	# 后台更新，不拖慢启动
	adg_on && adg_stale || return 0
	( exec 9>&-; update_adguard ) </dev/null >/dev/null 2>&1 &
}

overlay_text() {
	adrules_overlay
	[ "$1" = "noUser" ] || b64d "$mihomo_overlay" | sed 's/\r$//'
}

ov_insert() {
	# 把 $3（子块文件）合并到 $1（配置文件）的顶层字段 $2 下面，缩进自动对齐；字段不存在则追加
	awk -v key="$2" -v cf="$3" '
	function ind(s) { match(s, /^ */); return RLENGTH }
	function emit(bi,   j, l, d, k) {
		d = bi - oi
		for (j = 1; j <= n; j++) {
			l = c[j]
			if (d > 0) { for (k = 0; k < d; k++) l = " " l }
			else if (d < 0) { for (k = 0; k < -d && substr(l, 1, 1) == " "; k++) l = substr(l, 2) }
			print l
		}
	}
	BEGIN {
		n = 0; oi = -1
		while ((getline l < cf) > 0) {
			c[++n] = l
			if (l ~ /[^ \t]/ && l !~ /^[ \t]*#/) { i = ind(l); if (oi < 0 || i < oi) oi = i }
		}
		if (oi < 0) oi = 0
		state = 0; nb = 0
	}
	state == 1 {
		if ($0 ~ /^[ \t]*$/ || $0 ~ /^[ \t]*#/) { buf[++nb] = $0; next }
		if ($0 ~ /^[^ \t-]/ || $0 ~ /^-[^ ]/) bi = 2; else bi = ind($0)
		emit(bi); for (j = 1; j <= nb; j++) print buf[j]; nb = 0; state = 2
	}
	state == 0 && /^[A-Za-z0-9_"\047][^:]*:/ {
		k = $0; sub(/:.*/, "", k); gsub(/["\047 ]/, "", k)
		if (k == key) {
			v = $0; sub(/^[^:]*:[ \t]*/, "", v)
			if (v == "" || v ~ /^#/) { print; state = 1; next }
			next   # 行内写法（如 proxies: []）丢掉，最后整块追加
		}
	}
	{ print }
	END {
		if (state == 1) { emit(2); for (j = 1; j <= nb; j++) print buf[j] }
		else if (state == 0) { print key ":"; emit(oi) }
	}
	' "$1"
}

apply_overlay() {
	# $1=配置正文文件（原地修改）；覆写里的 rules 写到 $OV_RULES
	# 合并方式：rule-providers / proxy-providers / sub-rules / hosts 按条目合并，
	#           proxies / proxy-groups 插到最前面，rules 插到订阅规则前面，其它字段整体替换
	local body="$1" d=/tmp/mihomo_ov.$$ k kind
	: > "$OV_RULES"
	rm -rf "$d"; mkdir -p "$d"
	overlay_text "$2" > "$d/all"
	[ -s "$d/all" ] || { rm -rf "$d"; return 0; }
	awk -v d="$d" '
	/^[ \t]*#/ { next }
	/^[A-Za-z0-9_"\047][^:]*:/ {
		k = $0; sub(/:.*/, "", k); gsub(/["\047 ]/, "", k)
		v = $0; sub(/^[^:]*:[ \t]*/, "", v); sub(/[ \t]+#.*$/, "", v)
		if (!(k in seen)) { seen[k] = 1; print k >> (d "/keys") }
		if (v != "") print v > (d "/" k ".inline")
		cur = k; next
	}
	cur != "" && /[^ \t]/ { print >> (d "/" cur ".child") }
	' "$d/all"
	[ -f "$d/keys" ] || { rm -rf "$d"; return 0; }
	while read -r k; do
		case "$DROP_KEYS" in *"|$k|"*) echo_log "覆写：字段 $k 由插件管理，已忽略"; continue ;; esac
		case "$k" in
		rules)
			[ -f "$d/$k.child" ] && sed -n 's/^[ \t]*-[ \t]*//p' "$d/$k.child" | sed 's/[ \t]*$//' >> "$OV_RULES"
			;;
		rule-providers|proxy-providers|sub-rules|hosts|proxies|proxy-groups)
			[ -f "$d/$k.child" ] || continue
			ov_insert "$body" "$k" "$d/$k.child" > "$body.t" && mv -f "$body.t" "$body"
			;;
		*)
			strip_keys "$body" "|$k|" > "$body.t" && mv -f "$body.t" "$body"
			if [ -f "$d/$k.inline" ]; then echo "$k: $(cat "$d/$k.inline")" >> "$body"
			else echo "$k:" >> "$body"; [ -f "$d/$k.child" ] && cat "$d/$k.child" >> "$body"; fi
			;;
		esac
	done < "$d/keys"
	rm -rf "$d"
}

github_rules() {
	# GitHub 强制走第一个策略组：很多机场规则把 GitHub 分进「微软服务」等组，那个组选了直连时国内基本打不开
	[ "$mihomo_github_proxy" = "1" ] || return 0
	local g d q n
	g=$(first_group "$1"); q=${g%%$TAB*}; n=${g#?$TAB}
	[ -n "$n" ] || return 0
	case "$n" in *,*) return 0 ;; esac
	for d in github.com githubusercontent.com githubassets.com github.io githubapp.com github.dev ghcr.io; do
		if [ "$q" = d ]; then echo "\"DOMAIN-SUFFIX,$d,$n\""; else echo "DOMAIN-SUFFIX,$d,$n"; fi
	done
}

webrtc_rules() {
	# WebRTC 走代理：发往国外的 STUN 一律走第一个策略组，就算机场规则把它分到直连也不会暴露真实 IP；国内的照常直连
	[ "$mihomo_webrtc" = "proxy" ] && [ "$WEBRTC_RULE" != "0" ] || return 0
	local g q n r
	g=$(first_group "$1"); q=${g%%$TAB*}; n=${g#?$TAB}
	[ -n "$n" ] || return 0
	case "$n" in *,*|*\)*|*\(*|*\'*) return 0 ;; esac
	r="AND,((NETWORK,UDP),(DST-PORT,3478-3479/5349/19302-19309),(NOT,((GEOIP,CN)))),$n"
	if [ "$q" = d ]; then echo "\"$r\""; else echo "'$r'"; fi
}
# STUN 识别方式：常用端口 + 协议特征（STUN 报文第 4~7 字节固定是 0x2112A442）。
# 很多测试网站把 STUN 放在 443 等随便什么端口上，只认端口拦不住；内核没有 u32/string 模块时只能按端口
stun_try() {
	local t=$1; shift
	$t -t mangle -N MH_TRY 2>/dev/null || $t -t mangle -F MH_TRY 2>/dev/null
	$t -t mangle -A MH_TRY -p udp "$@" -j RETURN 2>/dev/null; local rc=$?
	$t -t mangle -F MH_TRY 2>/dev/null; $t -t mangle -X MH_TRY 2>/dev/null
	return $rc
}
stun_matchers() {
	local t=iptables u="0>>22&0x3C@12=0x2112A442" o=32
	[ "$1" = 6 ] && { t=ip6tables; u="52=0x2112A442"; o=52; }
	echo "-m multiport --dports $STUN_PORTS"
	modprobe xt_u32 2>/dev/null; modprobe xt_string 2>/dev/null
	if stun_try $t -m u32 --u32 "$u"; then echo "-m u32 --u32 $u"
	elif stun_try $t -m string --algo bm --hex-string "|2112a442|" --from $o --to $((o + 4)); then echo "-m string --algo bm --hex-string |2112a442| --from $o --to $((o + 4))"
	fi
}
stun_desc() { case "$1" in *u32*|*string*) echo "按端口和协议特征识别" ;; *) echo "仅按常用端口识别，路由器内核缺少 u32/string 模块" ;; esac; }
rtc_flush() {
	local t c r
	for t in iptables ip6tables; do
		command -v $t >/dev/null 2>&1 || continue
		c=MIHOMO_RTC; [ $t = ip6tables ] && c=MIHOMO_RTC6
		$t -S FORWARD 2>/dev/null | grep -- "-j $c\$" | sed 's/^-A FORWARD //' | while IFS= read -r r; do eval "$t -D FORWARD $r" 2>/dev/null; done
		$t -F $c 2>/dev/null; $t -X $c 2>/dev/null
	done
	# 2.2.0 的旧写法
	while iptables -D FORWARD -i $LAN_IF -p udp -m multiport --dports $STUN_PORTS -j MIHOMO_RTC 2>/dev/null; do :; done
	while ip6tables -D FORWARD -i $LAN_IF -p udp -m multiport --dports $STUN_PORTS -j REJECT 2>/dev/null; do :; done
}
insert_rules() {
	# 规则顺序：自定义规则（可放行）→ 内置广告规则 → GitHub 走代理 → 覆写规则（含去广告规则集）→ 设备专用策略 → 订阅/内置规则
	local rf=/tmp/mihomo_rules.$$
	user_rules > "$rf"
	AD_ALLOW=0
	{ [ "$mihomo_adblock" = "1" ] || [ -n "$mihomo_adrules" ]; } && ad_allow_on && AD_ALLOW=1
	adblock_rules | ad_wrap all >> "$rf"
	github_rules "$1" >> "$rf"
	webrtc_rules "$1" >> "$rf"
	[ -s "$OV_RULES" ] && ad_wrap ov < "$OV_RULES" >> "$rf"
	dev_rules >> "$rf"
	if [ ! -s "$rf" ]; then cat "$1"; rm -f "$rf"; return; fi
	awk -v rf="$rf" '
	BEGIN { n=0; while ((getline l < rf) > 0) r[++n]=l }
	inr && !done && /^[ \t]*-/ {
		ind=$0; sub(/-.*/, "", ind)
		for (i=1;i<=n;i++) print ind "- " r[i]
		done=1
	}
	inr && !done && /^[A-Za-z0-9_"\047][^:]*:/ {
		for (i=1;i<=n;i++) print "  - " r[i]
		done=1
	}
	{ print }
	/^rules:[ \t]*$/ { inr=1 }
	END {
		if (!inr) { print "rules:"; for (i=1;i<=n;i++) print "  - " r[i] }
		else if (!done) { for (i=1;i<=n;i++) print "  - " r[i] }
	}
	' "$1"
	rm -f "$rf"
}

gen_provider_body() {
	local f=/tmp/mihomo_subs.$$ name url id uses=""
	subs_lines > "$f"
	echo "proxy-providers:"
	while IFS="$TAB" read -r name url; do
		[ -z "$url" ] && continue
		id=$(sub_id "$url")
		[ "$mihomo_sub_merge" = "1" ] || [ "$id" = "$ACT_ID" ] || continue
		cat <<EOF
  sub_$id:
    type: http
    url: $(yaml_q "$url")
    path: ./providers/$id.yaml
    interval: 86400
    header:
      User-Agent:
        - $(yaml_q "$mihomo_sub_ua")
    health-check:
      enable: true
      url: https://www.gstatic.com/generate_204
      interval: 600
      lazy: true
EOF
		uses="$uses${uses:+, }sub_$id"
	done < "$f"
	rm -f "$f"
	[ -z "$uses" ] && return 1
	cat <<EOF

proxy-groups:
  - name: 节点选择
    type: select
    proxies: [自动选择, 故障转移, DIRECT]
    use: [$uses]
  - name: 自动选择
    type: url-test
    use: [$uses]
    url: https://www.gstatic.com/generate_204
    interval: 600
    tolerance: 50
    lazy: true
  - name: 故障转移
    type: fallback
    use: [$uses]
    url: https://www.gstatic.com/generate_204
    interval: 600
    lazy: true
  - name: 国内网站
    type: select
    proxies: [DIRECT, 节点选择]
  - name: 漏网之鱼
    type: select
    proxies: [节点选择, DIRECT]

rules:
  - GEOSITE,private,DIRECT
  - GEOIP,private,DIRECT,no-resolve
  - GEOSITE,cn,国内网站
  - GEOSITE,geolocation-!cn,节点选择
  - GEOIP,CN,国内网站
  - MATCH,漏网之鱼
EOF
}

build_config() {
	# $1=输出文件 $2=noUser（不带用户覆写）
	local body=/tmp/mihomo_body.$$
	OV_RULES=/tmp/mihomo_ovrules.$$
	case "$mihomo_cfg_mode" in
	sub)
		[ -s "$MDIR/sub_$ACT_ID.yaml" ] || download_sub "$ACT_ID" "$ACT_NAME" "$ACT_URL" || return 1
		strip_keys "$MDIR/sub_$ACT_ID.yaml" > "$body"
		;;
	provider)
		gen_provider_body > "$body" || { rm -f "$body"; echo_log "错误：还没有添加订阅"; return 1; }
		;;
	custom)
		[ -s "$CUSTOM_CFG" ] || { echo_log "错误：自定义配置为空"; return 1; }
		sed 's/\r$//' "$CUSTOM_CFG" > "$body.raw"
		strip_keys "$body.raw" > "$body"; rm -f "$body.raw"
		;;
	*)
		echo_log "错误：未知配置模式 $mihomo_cfg_mode"; return 1 ;;
	esac
	apply_overlay "$body" "$2"
	{ gen_header; echo; insert_rules "$body"; } > "$1"
	rm -f "$body" "$OV_RULES"
	return 0
}

first_group() {
	# 配置里第一个策略组（通常是机场的「节点选择」）
	awk '/^proxy-groups:/{f=1;next} f&&/^[^ \t#-]/{exit}
	f&&/^[ \t]*-[ \t]*\{?[ \t]*name:/{s=$0;fl=(s~/^[ \t]*-[ \t]*\{/);sub(/^[ \t]*-[ \t]*\{?[ \t]*name:[ \t]*/,"",s)
		q="p"
		if(s~/^"/){q="d";sub(/^"/,"",s);t="";while(length(s)>0){c=substr(s,1,1);if(c=="\\"){t=t substr(s,1,2);s=substr(s,3);continue}if(c=="\"")break;t=t c;s=substr(s,2)}s=t}
		else if(s~/^\047/){q="s";sub(/^\047/,"",s);sub(/\047.*$/,"",s)}
		else{if(fl)sub(/[ \t]*[,}].*$/,"",s);sub(/[ \t]+#.*$/,"",s);sub(/[ \t]+$/,"",s)}
		print q "\t" s;exit}' "$1"
}
# 把策略组名写成 YAML 里能原样还原的字符串：原来是双引号写法就保留里面的转义
group_yaml() { case "$1" in d"$TAB"*) printf '"%s"' "${1#d$TAB}" ;; *) yaml_q "${1#?$TAB}" ;; esac; }

add_dl_listener() {
	# 本机 127.0.0.1:7895 入站直接交给第一个策略组，插件更新/下载 GitHub 时不受分流规则影响
	local g
	g=$(first_group "$1"); [ -n "${g#?$TAB}" ] || return 1
	cp -f "$1" "$1.nol"
	printf '\nlisteners:\n  - name: mh-dl\n    type: mixed\n    port: %s\n    listen: 127.0.0.1\n    proxy: %s\n' "$DL_PORT" "$(group_yaml "$g")" >> "$1"
	if test_config "$1"; then rm -f "$1.nol"; return 0; fi
	mv -f "$1.nol" "$1"; return 1
}

test_config() {
	$BIN -t -d "$MDIR" -f "$1" > /tmp/mihomo_test.log 2>&1
}

gen_config() {
	local tmp=$MDIR/config.yaml.new
	mkdir -p "$MDIR"
	migrate_subs
	resolve_active
	build_config "$tmp" || return 1
	[ "$mihomo_adblock" = "1" ] && echo_log "广告屏蔽已启用：GEOSITE category-ads-all + 常见广告域名，策略 REJECT"
	[ -n "$mihomo_adrules" ] && echo_log "去广告规则集：$mihomo_adrules"
	[ "$mihomo_github_proxy" = "1" ] && grep -q '^ *- "\{0,1\}DOMAIN-SUFFIX,github.com,' "$tmp" && echo_log "GitHub 强制走「$(grep -m1 '^ *- "\{0,1\}DOMAIN-SUFFIX,github.com,' "$tmp" | cut -d, -f3- | sed 's/"$//')」"
	echo_log "校验配置文件..."
	if ! test_config "$tmp"; then
		echo_log "错误：配置校验失败："
		grep -iE 'error|fatal|fail' /tmp/mihomo_test.log | tail -n 5 | tee -a "$LOG"
		if [ "$FAKEIP_LEGACY" != "1" ] && grep -q 'fake-ip-filter-mode: rule' "$tmp"; then
			FAKEIP_LEGACY=1
			if build_config "$tmp" && test_config "$tmp"; then
				echo_log "提示：当前内核不支持 fake-ip 规则写法，已改用旧写法（更新内核后自动启用）"
			fi
		fi
		if ! test_config "$tmp" && [ "$USE_TUN" = "1" ]; then
			USE_TUN=0
			if build_config "$tmp" && test_config "$tmp"; then
				echo_log "警告：TUN 配置校验不通过，本次改用普通透明代理模式"
			fi
		fi
		if test_config "$tmp"; then :
		elif grep -q 'DST-PORT,3478-3479' "$tmp"; then
			WEBRTC_RULE=0
			if build_config "$tmp" && test_config "$tmp"; then
				echo_log "提示：WebRTC 强制走代理的规则和当前内核/订阅不兼容，已跳过（STUN 仍交给 Mihomo 按订阅规则走）"
			fi
		fi
		if test_config "$tmp"; then :
		elif [ "$mihomo_github_proxy" = "1" ] && grep -q 'DOMAIN-SUFFIX,github.com,' "$tmp"; then
			echo_log "尝试去掉「GitHub 走代理」规则后重新生成..."
			mihomo_github_proxy=0
			if build_config "$tmp" && test_config "$tmp"; then
				echo_log "警告：「GitHub 走代理」和这个订阅不兼容，本次已跳过，插件照常启动"
			fi
		fi
		if test_config "$tmp"; then :
		elif [ -n "$mihomo_overlay" ]; then
			echo_log "尝试去掉「覆写」内容后重新生成..."
			if build_config "$tmp" noUser && test_config "$tmp"; then
				echo_log "警告：覆写内容有误已被忽略，请到「覆写」页检查"
			else
				rm -f "$tmp"; return 1
			fi
		else
			rm -f "$tmp"; return 1
		fi
	fi
	add_dl_listener "$tmp"
	mv -f "$tmp" "$CFG"
	write_subinfo_json
	echo_log "配置生成完成"
	return 0
}

save_custom() {
	# Web 提交的自定义配置（base64）落盘后从 dbus 删除，避免 dbus 过大
	if [ -n "$mihomo_custom_b64" ]; then
		mkdir -p "$MDIR"
		b64d "$mihomo_custom_b64" > "$CUSTOM_CFG"
		dbus remove mihomo_custom_b64
		unset mihomo_custom_b64
		echo_log "自定义配置已保存（$(wc -c < "$CUSTOM_CFG") 字节）"
	fi
}

# ---------- 防火墙 ----------
ports_ok() {
	# 透明代理端口和 DNS 端口都在监听才算就绪
	netstat -ltn 2>/dev/null | grep -q ":$REDIR_PORT " || return 1
	netstat -lun 2>/dev/null | grep -q ":$DNS_PORT " || return 1
	return 0
}

rules_ok() {
	if [ -f "$TUN_FLAG" ]; then
		tun_up && iptables -t nat -C PREROUTING -i $LAN_IF -p udp --dport 53 -j MIHOMO_DNS 2>/dev/null
		return
	fi
	iptables -t nat -C PREROUTING -i $LAN_IF -p tcp -j MIHOMO 2>/dev/null && \
	iptables -t nat -C PREROUTING -i $LAN_IF -p udp --dport 53 -j MIHOMO_DNS 2>/dev/null
}

flush_rules() {
	local t c p
	# nat
	while iptables -t nat -D PREROUTING -i $LAN_IF -p tcp -j MIHOMO 2>/dev/null; do :; done
	while iptables -t nat -D PREROUTING -i $LAN_IF -p udp --dport 53 -j REDIRECT --to-ports $DNS_PORT 2>/dev/null; do :; done
	while iptables -t nat -D PREROUTING -i $LAN_IF -p tcp --dport 53 -j REDIRECT --to-ports $DNS_PORT 2>/dev/null; do :; done
	while iptables -t nat -D PREROUTING -i $LAN_IF -p udp --dport 53 -j MIHOMO_DNS 2>/dev/null; do :; done
	while iptables -t nat -D PREROUTING -i $LAN_IF -p tcp --dport 53 -j MIHOMO_DNS 2>/dev/null; do :; done
	while iptables -t nat -D OUTPUT -p tcp -j MIHOMO_OUT 2>/dev/null; do :; done
	# filter：UDP 未代理时拒绝发往 fake-ip 段的 UDP
	while iptables -D FORWARD -i $LAN_IF -p udp -d $FAKE_NET -j REJECT --reject-with icmp-port-unreachable 2>/dev/null; do :; done
	rtc_flush
	iptables -t mangle -F MH_TRY 2>/dev/null; iptables -t mangle -X MH_TRY 2>/dev/null
	# mangle
	while iptables -t mangle -D PREROUTING -i $LAN_IF -p udp -j MIHOMO_UDP 2>/dev/null; do :; done
	for t in nat:MIHOMO nat:MIHOMO_DNS nat:MIHOMO_OUT mangle:MIHOMO_UDP; do
		c=${t#*:}; t=${t%%:*}
		iptables -t $t -F $c 2>/dev/null
		iptables -t $t -X $c 2>/dev/null
	done
	while ip rule del fwmark $FWMARK table $RT_TABLE 2>/dev/null; do :; done
	while ip rule del pref $TUN_BYPASS_PREF 2>/dev/null; do :; done
	ip route flush table $RT_TABLE 2>/dev/null
	# IPv6 DNS
	if command -v ip6tables >/dev/null 2>&1; then
		for p in udp tcp; do
			while ip6tables -D INPUT -i $LAN_IF -p $p --dport 53 -j REJECT 2>/dev/null; do :; done
			while ip6tables -D FORWARD -i $LAN_IF -p $p --dport 53 -j REJECT 2>/dev/null; do :; done
		done
	fi
}

add_returns() {
	# $1=table $2=chain
	local n ip
	iptables -t $1 -A $2 -m mark --mark $ROUTING_MARK -j RETURN
	for n in $RESERVED_NETS; do
		iptables -t $1 -A $2 -d $n -j RETURN
	done
	# 本机 WAN 地址
	ip=$(nvram get wan0_ipaddr)
	[ -n "$ip" ] && [ "$ip" != "0.0.0.0" ] && iptables -t $1 -A $2 -d $ip -j RETURN
	# 绕过代理的设备
	for ip in $(ip_list "$mihomo_bypass_ip"); do
		iptables -t $1 -A $2 -s $ip -j RETURN 2>/dev/null || echo_log "忽略无效的绕过地址：$ip"
	done
}

acl_targets() {
	# 「只代理指定设备」时输出这些设备；全部设备模式输出空
	[ "$mihomo_acl_mode" = "only" ] && ip_list "$mihomo_proxy_ip"
}

apply_rules() {
	local ip udp_ok=0 p only=0
	[ "$mihomo_acl_mode" = "only" ] && only=1
	[ $only = 1 ] && [ -z "$(acl_targets | tr -d ' ')" ] && echo_log "警告：选了「只代理指定设备」但名单为空，没有设备会走代理"
	flush_rules
	local tun=0
	[ -f "$TUN_FLAG" ] && tun=1 && only=0
	if [ $tun = 1 ]; then
		# TUN 模式：局域网流量由内核的 TUN 网卡接管（auto-route），这里只处理 DNS、路由器自身和绕过设备
		for ip in $(ip_list "$mihomo_bypass_ip"); do
			ip rule add from $ip lookup main pref $TUN_BYPASS_PREF 2>/dev/null || echo_log "忽略无效的绕过地址：$ip"
		done
	else
	# --- TCP 透明代理 (REDIRECT) ---
	iptables -t nat -N MIHOMO
	# 发往 fake-ip 段的连接无论来自哪台设备都必须交给 Mihomo（否则这些虚拟地址出不去）
	iptables -t nat -A MIHOMO -p tcp -d $FAKE_NET -j REDIRECT --to-ports $REDIR_PORT
	add_returns nat MIHOMO
	if [ $only = 1 ]; then
		for ip in $(acl_targets); do iptables -t nat -A MIHOMO -p tcp -s $ip -j REDIRECT --to-ports $REDIR_PORT 2>/dev/null || echo_log "忽略无效的代理设备地址：$ip"; done
	else
		iptables -t nat -A MIHOMO -p tcp -j REDIRECT --to-ports $REDIR_PORT
	fi
	iptables -t nat -I PREROUTING -i $LAN_IF -p tcp -j MIHOMO
	fi

	# --- DNS 劫持：交给 Mihomo；「不走代理的设备」和（只代理指定设备时）名单外的设备不劫持，
	#     仍由路由器自己的 DNS 解析出真实 IP（否则 fake-ip 模式下它们拿到虚拟地址会断网）---
	iptables -t nat -N MIHOMO_DNS
	for ip in $(ip_list "$mihomo_bypass_ip"); do
		iptables -t nat -A MIHOMO_DNS -s $ip -j RETURN 2>/dev/null
	done
	if [ $only = 1 ]; then
		for ip in $(acl_targets); do iptables -t nat -A MIHOMO_DNS -s $ip -j REDIRECT --to-ports $DNS_PORT 2>/dev/null; done
	else
		iptables -t nat -A MIHOMO_DNS -j REDIRECT --to-ports $DNS_PORT
	fi
	iptables -t nat -I PREROUTING -i $LAN_IF -p udp --dport 53 -j MIHOMO_DNS
	iptables -t nat -I PREROUTING -i $LAN_IF -p tcp --dport 53 -j MIHOMO_DNS

	# --- 路由器自身流量 ---
	iptables -t nat -N MIHOMO_OUT
	if [ "$mihomo_router_proxy" = "1" ]; then
		add_returns nat MIHOMO_OUT
		iptables -t nat -A MIHOMO_OUT -p tcp -j REDIRECT --to-ports $REDIR_PORT
	else
		iptables -t nat -A MIHOMO_OUT -m mark --mark $ROUTING_MARK -j RETURN
		iptables -t nat -A MIHOMO_OUT -p tcp -d $FAKE_NET -j REDIRECT --to-ports $REDIR_PORT
	fi
	iptables -t nat -A OUTPUT -p tcp -j MIHOMO_OUT

	# --- UDP 透明代理 (TPROXY) ---
	[ $tun = 1 ] && udp_ok=1     # TUN 模式 UDP 本来就交给内核
	# UDP 代理关着、但开了 WebRTC 防泄漏（走代理）：只把 STUN 流量交给 Mihomo
	local stun_only=0 m
	[ "$mihomo_udp" != "1" ] && [ "$mihomo_webrtc" = "proxy" ] && [ $tun = 0 ] && stun_only=1
	[ "$mihomo_webrtc" != "off" ] && STUN4=$(stun_matchers 4)
	if { [ "$mihomo_udp" = "1" ] || [ $stun_only = 1 ]; } && [ $tun = 0 ]; then
		modprobe xt_TPROXY 2>/dev/null
		modprobe xt_socket 2>/dev/null
		iptables -t mangle -N MIHOMO_UDP
		iptables -t mangle -A MIHOMO_UDP -p udp --dport 53 -j RETURN
		local um=""
		[ $stun_only = 1 ] && um="-m multiport --dports $STUN_PORTS"
		if iptables -t mangle -A MIHOMO_UDP -p udp $um -d $FAKE_NET -j TPROXY --on-port $TPROXY_PORT --tproxy-mark $FWMARK 2>/dev/null; then
			add_returns mangle MIHOMO_UDP
			if [ $stun_only = 1 ]; then
				# 端口 + STUN 协议特征（不管网站用哪个端口都能认出来）
				echo "$STUN4" | while IFS= read -r m; do
					[ -n "$m" ] || continue
					if [ $only = 1 ]; then
						for ip in $(acl_targets); do iptables -t mangle -A MIHOMO_UDP -p udp $m -s $ip -j TPROXY --on-port $TPROXY_PORT --tproxy-mark $FWMARK 2>/dev/null; done
					else
						iptables -t mangle -A MIHOMO_UDP -p udp $m -j TPROXY --on-port $TPROXY_PORT --tproxy-mark $FWMARK
					fi
				done
			elif [ $only = 1 ]; then
				for ip in $(acl_targets); do iptables -t mangle -A MIHOMO_UDP -p udp -s $ip -j TPROXY --on-port $TPROXY_PORT --tproxy-mark $FWMARK 2>/dev/null; done
			else
				iptables -t mangle -A MIHOMO_UDP -p udp -j TPROXY --on-port $TPROXY_PORT --tproxy-mark $FWMARK
			fi
			ip rule add fwmark $FWMARK table $RT_TABLE pref 789
			ip route add local 0.0.0.0/0 dev lo table $RT_TABLE
			iptables -t mangle -I PREROUTING -i $LAN_IF -p udp -j MIHOMO_UDP
			if [ $stun_only = 1 ]; then
				echo_log "WebRTC 防泄漏：STUN 流量交给 Mihomo（$(stun_desc "$STUN4")；UDP 代理未开启，其它 UDP 仍直连）"
			else
				udp_ok=1
				echo_log "UDP 透明代理 (TPROXY) 已启用"
			fi
		else
			iptables -t mangle -F MIHOMO_UDP; iptables -t mangle -X MIHOMO_UDP
			echo_log "警告：内核不支持 TPROXY，UDP 透明代理未启用"
			# 交不出去就退而求其次：直接拦截，至少不泄漏真实 IP
			[ $stun_only = 1 ] && mihomo_webrtc=block
		fi
	fi

	# --- WebRTC 防泄漏 ---
	# 拦截模式：局域网发出的 STUN 直接拒绝，网页拿不到真实公网 IP（绕过的设备不受影响）
	if [ "$mihomo_webrtc" = "block" ]; then
		iptables -N MIHOMO_RTC 2>/dev/null
		for ip in $(ip_list "$mihomo_bypass_ip"); do iptables -A MIHOMO_RTC -s $ip -j RETURN 2>/dev/null; done
		iptables -A MIHOMO_RTC -j REJECT --reject-with icmp-port-unreachable
		echo "$STUN4" | while IFS= read -r m; do
			[ -n "$m" ] && iptables -I FORWARD -i $LAN_IF -p udp $m -j MIHOMO_RTC
		done
		echo_log "WebRTC 防泄漏：已拦截 STUN 探测（$(stun_desc "$STUN4")）"
	fi
	# IPv6 不经过 Mihomo：开了防泄漏就拒绝 IPv6 的 STUN，免得网页通过 IPv6 拿到真实地址
	if [ "$mihomo_webrtc" != "off" ] && [ -f /proc/net/if_inet6 ] && command -v ip6tables >/dev/null 2>&1; then
		if ip6tables -N MIHOMO_RTC6 2>/dev/null || ip6tables -F MIHOMO_RTC6 2>/dev/null; then
			ip6tables -A MIHOMO_RTC6 -j REJECT 2>/dev/null
			stun_matchers 6 | while IFS= read -r m; do
				[ -n "$m" ] && ip6tables -I FORWARD -i $LAN_IF -p udp $m -j MIHOMO_RTC6 2>/dev/null
			done
		fi
	fi
	# UDP 没有交给 Mihomo 时，发往 fake-ip 段的 UDP 出去了也没人接，QUIC 要等超时才退回 TCP、
	# 游戏/语音会直接连不上。这里让它立刻被拒绝，程序马上改用 TCP。
	if [ "$udp_ok" != "1" ] && [ "$mihomo_dns_mode" = "fake-ip" ]; then
		iptables -I FORWARD -i $LAN_IF -p udp -d $FAKE_NET -j REJECT --reject-with icmp-port-unreachable 2>/dev/null
	fi

	# --- IPv6 DNS 防泄漏：拒绝局域网发出的 IPv6 DNS，设备会马上改用会被上面规则处理的 IPv4 DNS ---
	if [ "$mihomo_ipv6_block" = "1" ] && [ -f /proc/net/if_inet6 ] && command -v ip6tables >/dev/null 2>&1; then
		for p in udp tcp; do
			ip6tables -I INPUT -i $LAN_IF -p $p --dport 53 -j REJECT 2>/dev/null
			ip6tables -I FORWARD -i $LAN_IF -p $p --dport 53 -j REJECT 2>/dev/null
		done
	fi
	echo_log "防火墙规则已加载"
}

# ---------- 定时任务 ----------
set_cron() {
	cru d mihomo_sub 2>/dev/null
	cru d mihomo_watch 2>/dev/null
	cru d mihomo_restart 2>/dev/null
	cru d mihomo_geo 2>/dev/null
	if [ "$mihomo_enable" = "1" ]; then
		# 每周三凌晨更新规则库（分钟按机器错开，避免所有人同时下载）
		[ "$mihomo_geo_auto" = "1" ] && cru a mihomo_geo "$(nvram get et0macaddr 2>/dev/null | awk '{gsub(/[^0-9]/,"");print (substr($0,1,4)+0)%50+5}' | grep . || echo 23) 4 * * 3 /koolshare/scripts/mihomo_config.sh update_geo"
		cru a mihomo_watch "* * * * * /koolshare/scripts/mihomo_config.sh watchdog"
		if [ "$mihomo_cfg_mode" = "sub" ] && [ "$mihomo_sub_interval" -gt 0 ] 2>/dev/null; then
			cru a mihomo_sub "17 */$mihomo_sub_interval * * * /koolshare/scripts/mihomo_config.sh update_sub"
		fi
		case "$mihomo_restart_hour" in
		[0-9]|1[0-9]|2[0-3]) cru a mihomo_restart "35 $mihomo_restart_hour * * * /koolshare/scripts/mihomo_config.sh restart" ;;
		esac
	fi
}

# ---------- 启停 ----------
wait_ready() {
	local i=0
	while [ $i -lt 30 ]; do
		is_running || return 1
		ports_ok && return 0
		i=$((i+1)); sleep 1
	done
	return 1
}

stop_mihomo() {
	flush_rules
	cru d mihomo_sub 2>/dev/null
	cru d mihomo_watch 2>/dev/null
	cru d mihomo_restart 2>/dev/null
	cru d mihomo_geo 2>/dev/null
	local pid
	pid=$(get_pid)
	if [ -n "$pid" ]; then
		echo_log "停止 Mihomo (PID $pid)..."
		kill "$pid" 2>/dev/null
		local i=0
		while kill -0 "$pid" 2>/dev/null && [ $i -lt 10 ]; do sleep 1; i=$((i+1)); done
		kill -9 "$pid" 2>/dev/null
	fi
	killall mihomo 2>/dev/null
	rm -f "$PIDFILE" "$TUN_FLAG"
	cache_save
}

# ---------- fake-ip / 节点选择记录（cache.db）----------
# 内核会频繁写这个文件，放 JFFS 会磨损闪存：运行时放内存，启动时恢复、每小时和停止时备份回 JFFS
CACHE_RAM=$RUN/cache.db
CACHE_SAVE=$MDIR/cache.db.save
cache_restore() {
	mkdir -p "$RUN"
	if [ -f "$MDIR/cache.db" ] && [ ! -L "$MDIR/cache.db" ]; then
		mv -f "$MDIR/cache.db" "$CACHE_SAVE"      # 老版本留下的：转成备份
	fi
	[ ! -s "$CACHE_RAM" ] && [ -s "$CACHE_SAVE" ] && cp -f "$CACHE_SAVE" "$CACHE_RAM"
	[ "$(readlink "$MDIR/cache.db" 2>/dev/null)" = "$CACHE_RAM" ] || { rm -f "$MDIR/cache.db"; ln -s "$CACHE_RAM" "$MDIR/cache.db"; }
}
cache_save() {
	[ -s "$CACHE_RAM" ] || return 0
	command -v cmp >/dev/null 2>&1 && [ -f "$CACHE_SAVE" ] && cmp -s "$CACHE_RAM" "$CACHE_SAVE" && return 0
	cp -f "$CACHE_RAM" "$CACHE_SAVE.tmp" 2>/dev/null && mv -f "$CACHE_SAVE.tmp" "$CACHE_SAVE" || rm -f "$CACHE_SAVE.tmp"
}
# ---------- TUN 模式（实验）----------
tun_dev_ok() {
	[ -c /dev/net/tun ] && return 0
	modprobe tun 2>/dev/null
	[ -c /dev/net/tun ] && return 0
	[ -d /dev/net ] || mkdir -p /dev/net
	mknod /dev/net/tun c 10 200 2>/dev/null
	[ -c /dev/net/tun ]
}
tun_decide() {
	# 结果放 USE_TUN；不满足条件就退回普通模式
	USE_TUN=0
	[ "$mihomo_tun" = "1" ] || return 0
	if [ "$mihomo_acl_mode" = "only" ]; then
		echo_log "提示：TUN 模式暂不支持「只代理指定设备」，本次用普通透明代理模式"; return 0
	fi
	if ! tun_dev_ok; then
		echo_log "警告：系统没有 TUN 设备（/dev/net/tun），本次用普通透明代理模式"
		tg_notify fail "⚠️ 路由器不支持 TUN，已自动改用普通透明代理模式"
		return 0
	fi
	USE_TUN=1
}
tun_up() { ip link show "$TUN_DEV" >/dev/null 2>&1; }
start_mihomo() {
	if [ "$mihomo_enable" != "1" ]; then
		echo_log "插件未启用"
		return 0
	fi
	apply_storage
	prepare_core || return 1
	save_custom
	cache_restore
	tun_decide
	gen_config || { tg_notify fail "❌ 配置校验失败，Mihomo 没有启动（局域网直连）。原因见插件「日志」页"; return 1; }
	echo_log "启动 Mihomo $(dbus get mihomo_core_version)..."
	ulimit -n 65535 2>/dev/null
	# 日志超过 1MB 时截断
	[ -f "$CORE_LOG" ] && [ "$(wc -c < "$CORE_LOG")" -gt 1048576 ] && : > "$CORE_LOG"
	nohup "$BIN" -d "$MDIR" -f "$CFG" >> "$CORE_LOG" 2>&1 9>&- </dev/null &
	echo $! > "$PIDFILE"
	if wait_ready && [ "$USE_TUN" = "1" ]; then
		local i=0
		while ! tun_up && [ $i -lt 10 ]; do sleep 1; i=$((i+1)); done
		if ! tun_up; then
			echo_log "警告：TUN 网卡没有建立，改用普通透明代理模式重新启动，最近日志："
			tail -n 5 "$CORE_LOG" | tee -a "$LOG"
			stop_mihomo
			tg_notify fail "⚠️ TUN 模式启动失败，已自动改用普通透明代理模式"
			mihomo_tun=0; USE_TUN=0
			start_mihomo; return $?
		fi
	fi
	if ! is_running || ! ports_ok; then
		echo_log "错误：Mihomo 启动失败，最近日志："
		tail -n 8 "$CORE_LOG" | tee -a "$LOG"
		stop_mihomo
		if [ "$USE_TUN" = "1" ]; then
			echo_log "改用普通透明代理模式再试一次..."
			tg_notify fail "⚠️ TUN 模式启动失败，已自动改用普通透明代理模式"
			mihomo_tun=0; USE_TUN=0
			start_mihomo; return $?
		fi
		tg_notify fail "❌ Mihomo 启动失败，局域网已恢复直连
<pre>$(html_esc "$(tail -n 3 "$CORE_LOG" | cut -c1-200)")</pre>"
		return 1
	fi
	rm -f "$TUN_FLAG"; [ "$USE_TUN" = "1" ] && : > "$TUN_FLAG"
	apply_rules
	set_cron
	write_subinfo_json
	[ "$USE_TUN" = "1" ] && echo_log "TUN 模式已启用（实验功能，网卡 $TUN_DEV）"
	adg_bg
	echo_log "Mihomo 已启动，面板：http://$(lan_ip):$mihomo_ui_port/ui/"
	if [ -n "$(dbus get mihomo_tg_pending)" ]; then
		tg_notify update "🔄 $(html_esc "$(dbus get mihomo_tg_pending)")"; dbus remove mihomo_tg_pending
	elif booting; then
		tg_notify boot "🟢 路由器开机，Mihomo 已上线
当前节点：$(sleep 2; tg_node || echo 未知)"
	elif [ -n "$TG_START" ]; then
		tg_notify start "▶️ Mihomo 已启动"
	fi
	return 0
}

booting() { [ "$(awk '{print int($1)}' /proc/uptime)" -lt 300 ]; }

boot_wait() {
	# 开机：先等路由器时间同步（加密 DNS / TLS 依赖正确时间），最多 60 秒；再按设置额外延迟
	local i=0 d
	while [ "$(nvram get ntp_ready)" != "1" ] && [ $i -lt 60 ]; do sleep 2; i=$((i+2)); done
	d=$mihomo_boot_delay
	case "$d" in ''|*[!0-9]*) d=0 ;; esac
	[ "$d" -gt 600 ] && d=600
	[ "$d" -gt 0 ] && sleep "$d"
	[ -n "$mihomo_data_dir" ] && usb_wait
	return 0
}

update_geo() {
	local base="https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release"
	local f p ok=1
	mkdir -p "$MDIR"
	for f in "country-lite.mmdb:Country.mmdb" "geosite.dat:GeoSite.dat"; do
		echo_log "下载 ${f#*:} ..."
		p=$(real_path "$MDIR/${f#*:}")   # 放在 U 盘时直接写到 U 盘
		if fetch_to "$base/${f%%:*}" "$p.new" "Mozilla/5.0" 180; then
			mv -f "$p.new" "$p"
		else
			rm -f "$p.new"; ok=0
			echo_log "下载 ${f#*:} 失败"
		fi
	done
	[ $ok = 1 ] && dbus set mihomo_geo_time="$(date '+%Y-%m-%d %H:%M')"
	[ $ok = 1 ]
}

# ---------- Telegram 通知 ----------
# 事件：fail=启动失败/守护重启  boot=开机上线  sub=订阅更新  traffic=流量/到期提醒  update=插件/内核更新  start=手动启停
TG_QUEUE=/tmp/mihomo_tg_queue
tg_on() { [ "$mihomo_tg_enable" = "1" ] && [ -n "$mihomo_tg_token" ] && [ -n "$mihomo_tg_chat" ] && case ",${mihomo_tg_ev:-fail,boot,sub,traffic,update}," in *",$1,"*) return 0 ;; esac; return 1; }
html_esc() { printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
tg_post() {
	# 发送一条消息；Mihomo 在运行时走代理（Telegram 在国内直连不通）。成功返回 0，失败把原因写到 /tmp/mihomo_tg_err
	local text="$1" api="${mihomo_tg_api:-https://api.telegram.org}" px="" out=/tmp/mihomo_tg_resp.$$ m
	api=${api%/}
	if is_running; then px="http://127.0.0.1:$(grep -q '^  - name: mh-dl$' "$CFG" 2>/dev/null && echo $DL_PORT || echo $MIXED_PORT)"; fi
	for m in ${px:+proxy} direct; do
		rm -f "$out"
		if [ "$m" = proxy ]; then
			curl -s -m 20 --connect-timeout 10 -x "$px" -o "$out" --data-urlencode "chat_id=$mihomo_tg_chat" --data-urlencode "text=$text" -d parse_mode=HTML -d disable_web_page_preview=true "$api/bot$mihomo_tg_token/sendMessage" 2>/dev/null
		else
			curl -s -m 20 --connect-timeout 10 -o "$out" --data-urlencode "chat_id=$mihomo_tg_chat" --data-urlencode "text=$text" -d parse_mode=HTML -d disable_web_page_preview=true "$api/bot$mihomo_tg_token/sendMessage" 2>/dev/null
		fi
		if grep -q '"ok":true' "$out" 2>/dev/null; then rm -f "$out" /tmp/mihomo_tg_err; return 0; fi
		[ -s "$out" ] && sed -n 's/.*"description":"\([^"]*\)".*/\1/p' "$out" > /tmp/mihomo_tg_err
		[ -s /tmp/mihomo_tg_err ] || echo "连不上 Telegram（${m}）" > /tmp/mihomo_tg_err
		grep -q '"ok":false' "$out" 2>/dev/null && break   # Telegram 明确拒绝（令牌/Chat ID 错），换线路也没用
	done
	rm -f "$out"; return 1
}
tg_title() { echo "<b>Mihomo · $(html_esc "$(nvram get productid 2>/dev/null || echo 路由器)")</b>"; }
tg_flush() {
	# 之前没发出去的（比如启动失败时代理不可用）现在补发
	[ -s "$TG_QUEUE" ] || return 0
	local q; q=$(cat "$TG_QUEUE"); rm -f "$TG_QUEUE"
	tg_post "$(tg_title)
<i>（补发）</i>
$q" || printf '%s\n' "$q" > "$TG_QUEUE"
}
tg_notify() {
	# 用法：tg_notify 事件 消息（可多行，已是 HTML 安全文本）。后台发送，不拖慢主流程
	tg_on "$1" || return 0
	local msg="$2"
	(
		exec 9>&-
		if tg_post "$(tg_title)
$msg
<code>$(date '+%m-%d %H:%M')</code>"; then tg_flush
		else
			# 留到下次能发的时候补发（最多保留 20 行）
			{ cat "$TG_QUEUE" 2>/dev/null; printf '%s · %s\n' "$(date '+%m-%d %H:%M')" "$msg"; } | tail -n 20 > "$TG_QUEUE.t" && mv -f "$TG_QUEUE.t" "$TG_QUEUE"
		fi
	) </dev/null >/dev/null 2>&1 &
}
tg_node() { local n; n=$(api GET "/proxies/GLOBAL" 2>/dev/null | sed -n 's/.*"now":"\([^"]*\)".*/\1/p' | head -1); [ -n "$n" ] && echo "$(html_esc "$n")"; }
tg_traffic_check() {
	# 当前订阅流量用到 80% / 90% / 100%、离到期 7 / 3 / 1 天时各提醒一次
	tg_on traffic || return 0
	[ -n "$ACT_ID" ] || return 0
	local info pct=-1 days=-1 lvl key last up dn tot exp now
	eval "info=\${mihomo_subinfo_$ACT_ID}"; [ -n "$info" ] || return 0
	up=$(echo "$info" | sed -n 's/.*upload=\([0-9]*\).*/\1/p'); dn=$(echo "$info" | sed -n 's/.*download=\([0-9]*\).*/\1/p')
	tot=$(echo "$info" | sed -n 's/.*total=\([0-9]*\).*/\1/p'); exp=$(echo "$info" | sed -n 's/.*expire=\([0-9]*\).*/\1/p'); now=$(date +%s)
	[ -n "$tot" ] && [ "$tot" -gt 0 ] 2>/dev/null && pct=$(awk -v u="${up:-0}" -v d="${dn:-0}" -v t="$tot" 'BEGIN{printf "%d", (u+d)*100/t}')
	[ -n "$exp" ] && [ "$exp" -gt 0 ] 2>/dev/null && days=$(( (exp - now) / 86400 ))
	lvl=""
	if [ "$pct" -ge 100 ]; then lvl="t100"; elif [ "$pct" -ge 90 ]; then lvl="t90"; elif [ "$pct" -ge 80 ]; then lvl="t80"; fi
	key="mihomo_tg_tlast_$ACT_ID"; eval "last=\${$key}"
	if [ -n "$lvl" ] && [ "$lvl" != "$last" ]; then
		dbus set $key=$lvl
		tg_notify traffic "📊 订阅「$(html_esc "$ACT_NAME")」流量已用 <b>${pct}%</b>（$(awk -v b=$(( ${up:-0} + ${dn:-0} )) 'BEGIN{printf "%.1f GB", b/1073741824}') / $(awk -v b=$tot 'BEGIN{printf "%.0f GB", b/1073741824}')）"
	elif [ -z "$lvl" ] && [ -n "$last" ]; then dbus remove $key
	fi
	lvl=""
	if [ "$days" -ge 0 ]; then
		if [ "$days" -le 1 ]; then lvl="d1"; elif [ "$days" -le 3 ]; then lvl="d3"; elif [ "$days" -le 7 ]; then lvl="d7"; fi
	fi
	key="mihomo_tg_dlast_$ACT_ID"; eval "last=\${$key}"
	if [ -n "$lvl" ] && [ "$lvl" != "$last" ]; then
		dbus set $key=$lvl
		tg_notify traffic "⏰ 订阅「$(html_esc "$ACT_NAME")」还有 <b>${days} 天</b>到期（$(date -d @$exp '+%Y-%m-%d' 2>/dev/null || echo "$exp")），记得续费"
	elif [ -z "$lvl" ] && [ -n "$last" ]; then dbus remove $key
	fi
}
tg_test() {
	: > "$LOG"
	if [ -z "$mihomo_tg_token" ] || [ -z "$mihomo_tg_chat" ]; then echo_log "错误：请先填写 Bot Token 和 Chat ID"; return 1; fi
	echo_log "发送测试消息到 Telegram..."
	if tg_post "$(tg_title)
✅ 测试消息：通知已配置好
当前节点：$(tg_node || echo 未运行)
<code>$(date '+%Y-%m-%d %H:%M:%S')</code>"; then
		echo_log "发送成功，请查看 Telegram"
	else
		echo_log "发送失败：$(cat /tmp/mihomo_tg_err 2>/dev/null)"
		echo_log "提示：Token 或 Chat ID 不对会提示 Unauthorized / chat not found；连不上说明代理没运行或节点不通，可以填自建的 API 反代地址"
		return 1
	fi
}

# ---------- 内核 / 插件更新 ----------
core_arch() {
	case "$(uname -m)" in aarch64|armv8*) echo arm64 ;; armv7l) echo armv7 ;; *) echo "" ;; esac
}

update_core() {
	# $1=check 只检查；否则检查并更新
	local arch latest cur url gz=/tmp/mihomo_core.gz nb=/tmp/mihomo_core.new need free old dest
	arch=$(core_arch)
	[ -z "$arch" ] && { echo_log "错误：不支持的架构 $(uname -m)"; return 1; }
	local rel="releases/latest/download" chn="正式版"
	[ "$mihomo_core_channel" = "alpha" ] && { rel="releases/download/Prerelease-Alpha"; chn="Alpha 测试版"; }
	echo_log "检查最新内核版本（$chn）..."
	fetch_gh "https://github.com/MetaCubeX/mihomo/$rel/version.txt" /tmp/mihomo_ver.txt 30 || { echo_log "错误：获取最新版本失败（GitHub 无法访问）"; return 1; }
	latest=$(head -n1 /tmp/mihomo_ver.txt | tr -d ' \r\n'); rm -f /tmp/mihomo_ver.txt
	echo "$latest" | grep -qE '^(v[0-9]+\.[0-9]+|alpha-[0-9a-f]+)' || { echo_log "错误：版本号异常：$latest"; return 1; }
	dbus set mihomo_core_latest="$latest"
	prepare_core >/dev/null 2>&1
	cur=$(dbus get mihomo_core_version)
	if [ "$cur" = "$latest" ]; then echo_log "内核已是最新版本 $cur"; return 0; fi
	if [ "$1" = "check" ]; then echo_log "发现新内核 $latest（当前 $cur），可点「更新内核」"; return 0; fi
	url="https://github.com/MetaCubeX/mihomo/releases/download/$latest/mihomo-linux-$arch-$latest.gz"
	[ "$mihomo_core_channel" = "alpha" ] && url="https://github.com/MetaCubeX/mihomo/$rel/mihomo-linux-$arch-$latest.gz"
	echo_log "下载内核 $latest（$arch）..."
	fetch_gh "$url" "$gz" 300 || { rm -f "$gz"; echo_log "错误：内核下载失败"; return 1; }
	if ! gunzip -c "$gz" > "$nb" 2>/dev/null || ! chmod 755 "$nb" || ! "$nb" -v 2>/dev/null | grep -qi mihomo; then
		rm -f "$gz" "$nb"; echo_log "错误：下载的内核无法运行，已放弃更新"; return 1
	fi
	rm -f "$nb"
	# 选了 U 盘就直接放到 U 盘，JFFS 只留链接
	dest=$(real_path "$CORE_GZ")
	usb_ready && { mkdir -p "$(data_dir)"; dest=$(item_tgt core); }
	need=$(( $(wc -c < "$gz") / 1024 + 64 ))
	free=$(kb_free "$(dirname "$dest")")
	old=0; [ -f "$dest" ] && old=$(( $(wc -c < "$dest") / 1024 ))
	if [ -n "$free" ] && [ $((free + old)) -lt $need ]; then
		rm -f "$gz"; echo_log "错误：$(case "$dest" in /tmp/mnt/*) echo U 盘;; *) echo JFFS;; esac)空间不足（需要约 ${need}KB），已放弃更新"; return 1
	fi
	rm -f /tmp/mihomo_core_old.gz
	[ -f "$dest" ] && cp -f "$dest" /tmp/mihomo_core_old.gz
	cp -f "$gz" "$dest.new" && mv -f "$dest.new" "$dest" || { rm -f "$gz" "$dest.new"; echo_log "错误：写入内核失败"; return 1; }
	[ "$dest" != "$CORE_GZ" ] && { rm -f "$CORE_GZ"; ln -s "$dest" "$CORE_GZ"; }
	rm -f "$gz" "$RUN_BIN"
	if [ "$mihomo_enable" = "1" ]; then
		stop_mihomo
		if ! start_mihomo; then
			echo_log "新内核启动失败，回滚到原来的内核"
			tg_notify fail "⚠️ 新内核启动失败，已回滚到原来的内核"
			if [ -f /tmp/mihomo_core_old.gz ]; then mv -f /tmp/mihomo_core_old.gz "$dest"; else rm -f "$dest" "$CORE_GZ"; fi
			rm -f "$RUN_BIN"; BIN=$KSHOME/bin/mihomo
			start_mihomo || echo_log "启动失败，已恢复为直连"
			return 1
		fi
	else
		prepare_core
	fi
	rm -f /tmp/mihomo_core_old.gz
	echo_log "内核已更新为 $(dbus get mihomo_core_version)"
	tg_notify update "🔄 内核已更新为 $(dbus get mihomo_core_version)"
}

autoupd_mark() {
	# 自动更新的检查结果只写内存（/tmp），避免每 5 分钟写一次闪存
	mkdir -p /tmp/upload; echo "$(date '+%m-%d %H:%M') $*" > /tmp/upload/mihomo_autoupd.txt
}

ver_gt() {
	# $1 > $2 ？（按数字逐段比较，如 1.10.0 > 1.9.3）
	awk -v a="$1" -v b="$2" 'BEGIN{n=split(a,x,".");m=split(b,y,".");k=(n>m)?n:m;for(i=1;i<=k;i++){p=x[i]+0;q=y[i]+0;if(p>q){print 1;exit}if(p<q){print 0;exit}}print 0}'
}

check_plugin() {
	# $1=quiet：自动检查时不写日志，只记录到 dbus
	local base latest q="$1"
	base=${mihomo_update_url%/}
	[ -z "$base" ] && { [ -n "$q" ] || echo_log "错误：还没有填写插件发布地址"; return 1; }
	[ -n "$q" ] || echo_log "检查插件新版本..."
	[ -n "$q" ] && QUIET=1
	if ! fetch_to "$base/version" /tmp/mihomo_pv.txt "Mozilla/5.0" 30 >/dev/null; then
		if ! fetch_gh "$base/version" /tmp/mihomo_pv.txt 30 >/dev/null; then
			QUIET=
			[ -n "$q" ] || echo_log "错误：无法获取 $base/version"
			autoupd_mark "检查失败（发布地址无法访问）"
			return 1
		fi
	fi
	QUIET=
	latest=$(head -n1 /tmp/mihomo_pv.txt | tr -d ' \r\nv'); rm -f /tmp/mihomo_pv.txt
	echo "$latest" | grep -qE '^[0-9]+(\.[0-9]+)+$' || { [ -n "$q" ] || echo_log "错误：版本号异常：$latest"; autoupd_mark "版本号异常"; return 1; }
	[ "$(dbus get mihomo_plugin_latest)" = "$latest" ] || dbus set mihomo_plugin_latest="$latest"
	PLUGIN_LATEST=$latest
	if [ "$(ver_gt "$latest" "$mihomo_version")" != "1" ]; then
		[ -n "$q" ] || echo_log "插件已是最新版本 v$mihomo_version"
		autoupd_mark "已是最新"
		return 2
	fi
	echo_log "发现插件新版本 v$latest（当前 v$mihomo_version）"
	return 0
}

auto_update() {
	# 每 5 分钟由定时任务调用：有新版本才下载安装，同一版本连续失败 3 次后不再重试
	[ "$mihomo_auto_update" = "1" ] && [ -n "$mihomo_update_url" ] || return 0
	check_plugin quiet; [ $? = 0 ] || return 0
	local fv fc
	fv=$(dbus get mihomo_autoupd_failver); fc=$(dbus get mihomo_autoupd_failcnt)
	[ "$fv" = "$PLUGIN_LATEST" ] && [ "${fc:-0}" -ge 3 ] && return 0
	[ "$fv" = "$PLUGIN_LATEST" ] || { fc=0; dbus set mihomo_autoupd_failver="$PLUGIN_LATEST"; }
	dbus set mihomo_autoupd_failcnt=$(( ${fc:-0} + 1 ))   # 安装成功后 install.sh 会清零
	echo_log "自动更新：开始安装 v$PLUGIN_LATEST"
	autoupd_mark "正在更新到 v$PLUGIN_LATEST"
	update_plugin noCheck
}

set_autoupd_cron() {
	cru d mihomo_autoupd 2>/dev/null
	[ "$mihomo_auto_update" = "1" ] && [ -n "$mihomo_update_url" ] && \
		cru a mihomo_autoupd "*/5 * * * * /koolshare/scripts/mihomo_config.sh auto_update"
	return 0
}

update_plugin() {
	local base=${mihomo_update_url%/} rc
	if [ "$1" != "noCheck" ]; then
		check_plugin; rc=$?
		[ $rc = 1 ] && return 1
		[ $rc = 2 ] && return 0
	fi
	echo_log "下载插件 v$PLUGIN_LATEST ..."
	rm -rf /tmp/mihomo /tmp/mihomo.tar.gz
	# 先下小的升级包（不含内核和规则库，约 1MB），没有再下完整包
	if [ -x "$KSHOME/bin/mihomo" ] && { fetch_to "$base/mihomo_lite.tar.gz" /tmp/mihomo.tar.gz "Mozilla/5.0" 120 || fetch_gh "$base/mihomo_lite.tar.gz" /tmp/mihomo.tar.gz 120; }; then
		echo_log "已下载升级包（$(( $(wc -c < /tmp/mihomo.tar.gz) / 1024 ))KB）"
	else
		fetch_to "$base/mihomo.tar.gz" /tmp/mihomo.tar.gz "Mozilla/5.0" 300 || fetch_gh "$base/mihomo.tar.gz" /tmp/mihomo.tar.gz 300 || { echo_log "错误：插件下载失败"; return 1; }
	fi
	tar -tzf /tmp/mihomo.tar.gz 2>/dev/null | grep -q '^mihomo/install.sh$' || { rm -f /tmp/mihomo.tar.gz; echo_log "错误：下载的文件不是本插件的安装包"; return 1; }
	tar -xzf /tmp/mihomo.tar.gz -C /tmp || { echo_log "错误：解压失败"; return 1; }
	# 安装脚本会停止/启动插件、覆盖本脚本，所以放到独立进程里、等本次操作释放锁后再执行
	cat > /tmp/mihomo_selfupd.sh <<EOF
#!/bin/sh
sleep 1
echo "\$(date '+%Y-%m-%d %H:%M:%S') 开始安装 v$PLUGIN_LATEST ..." >> $LOG
sh /tmp/mihomo/install.sh >> $LOG 2>&1
echo "MIHOMO_DONE" >> $LOG
rm -f /tmp/mihomo_selfupd.sh
EOF
	nohup sh /tmp/mihomo_selfupd.sh >/dev/null 2>&1 9>&- </dev/null &
	echo_log "安装程序已启动，完成后页面会自动刷新状态"
	SELF_UPDATING=1
}

dump_config() {
	mkdir -p /tmp/upload
	if [ -f "$CFG" ]; then
		sed 's/^secret: .*/secret: "******"  # 已打码/' "$CFG" > /tmp/upload/mihomo_config.txt
	else
		echo "# 还没有生成配置：请先在「基本设置」里启用并保存一次" > /tmp/upload/mihomo_config.txt
	fi
}

# ---------- 主流程 ----------
case "$1" in
	''|*[!0-9]*) ACTION="$1"; WEB_ID="" ;;
	*) ACTION="$2"; WEB_ID="$1" ;;
esac

run_action() {
	case "$ACTION" in
	start)
		# 开机 / WAN 重连时由软件中心调用（ks-wan-start.sh -> S99mihomo.sh start）
		set_autoupd_cron
		if [ "$mihomo_enable" = "1" ]; then
			if is_running; then apply_rules; set_cron
			else : > "$LOG"; stop_mihomo; start_mihomo; fi
		fi
		;;
	start_nat)
		# 防火墙重启后重新加载规则
		if [ "$mihomo_enable" = "1" ]; then
			if is_running; then apply_rules; else start_mihomo; fi
		fi
		;;
	restart)
		: > "$LOG"
		set_autoupd_cron
		local was=0; is_running && was=1
		stop_mihomo
		if [ "$mihomo_enable" = "1" ]; then
			[ $was = 0 ] && TG_START=1
			start_mihomo || echo_log "启动失败，已恢复为直连"
		else
			[ $was = 1 ] && tg_notify start "⏹ Mihomo 已手动停止，局域网恢复直连"
			save_custom
			apply_storage
			migrate_subs; resolve_active; write_subinfo_json
			echo_log "Mihomo 已关闭"
		fi
		;;
	stop)
		: > "$LOG"; stop_mihomo; echo_log "Mihomo 已停止" ;;
	update_sub)
		[ -n "$WEB_ID" ] && : > "$LOG"
		migrate_subs; resolve_active
		local target="${mihomo_sub_target:-$ACT_ID}"
		dbus remove mihomo_sub_target; dbus remove mihomo_sub_force
		if [ "$mihomo_cfg_mode" = "provider" ]; then
			if is_running; then
				local f=/tmp/mihomo_subs.$$ name url id
				subs_lines > "$f"
				while IFS="$TAB" read -r name url; do
					[ -z "$url" ] && continue
					id=$(sub_id "$url")
					[ -n "$mihomo_sub_target" ] && [ "$id" != "$target" ] && continue
					api PUT "/providers/proxies/sub_$id" >/dev/null && echo_log "已通知内核刷新订阅「$name」" || echo_log "订阅「$name」未在使用中或刷新失败"
				done < "$f"
				rm -f "$f"
				sleep 3; provider_info_sync; write_subinfo_json
			else
				echo_log "内核未运行"
			fi
		else
			find_sub "$target" || { echo_log "错误：找不到要更新的订阅"; return 1; }
			if [ "$target" != "$ACT_ID" ]; then
				# 不是当前订阅：只下载、刷新流量信息，不影响正在运行的代理
				download_sub "$target" "$F_NAME" "$F_URL" && rm -f "$MDIR/sub_$target.yaml.bak"
				write_subinfo_json
				return 0
			fi
			if download_sub "$ACT_ID" "$ACT_NAME" "$ACT_URL"; then
				# 先校验新订阅，失败则回滚，不影响正在运行的代理
				if prepare_core && gen_config; then
					rm -f "$MDIR/sub_$ACT_ID.yaml.bak"
					if [ "$mihomo_enable" = "1" ]; then
						if reload_core; then
							echo_log "已热重载新订阅（现有连接不中断）"
							tg_notify sub "📥 订阅「$(html_esc "$ACT_NAME")」已更新：$(count_nodes "$MDIR/sub_$ACT_ID.yaml") 个节点"
							tg_traffic_check
						else
							echo_log "热重载不可用，改为重启 Mihomo"
							stop_mihomo; start_mihomo
						fi
					fi
				else
					[ -f "$MDIR/sub_$ACT_ID.yaml.bak" ] && mv -f "$MDIR/sub_$ACT_ID.yaml.bak" "$MDIR/sub_$ACT_ID.yaml"
					echo_log "新订阅无效，已保留旧订阅，当前代理不受影响"
					tg_notify sub "⚠️ 订阅「$(html_esc "$ACT_NAME")」新内容无效，已保留旧订阅"
				fi
			fi
		fi
		;;
	ad_trace)
		[ -n "$WEB_ID" ] && : > "$LOG"
		ad_trace
		;;
	update_adguard)
		[ -n "$WEB_ID" ] && : > "$LOG"
		update_adguard
		;;
	update_geo)
		[ -n "$WEB_ID" ] && : > "$LOG"
		if update_geo; then
			if is_running; then
				if reload_core; then echo_log "规则库已热重载（现有连接不中断）"; else stop_mihomo; start_mihomo; fi
			fi
		elif [ -z "$WEB_ID" ]; then
			tg_notify fail "⚠️ 规则库自动更新失败，继续使用旧规则库"
		fi
		;;
	check_core)  : > "$LOG"; update_core check ;;
	update_core) : > "$LOG"; update_core ;;
	check_plugin) : > "$LOG"; check_plugin ;;
	update_plugin) : > "$LOG"; update_plugin ;;
	auto_update) auto_update ;;
	dump_custom)
		# 把当前自定义配置复制到 web 可读目录
		mkdir -p /tmp/upload
		if [ -f "$CUSTOM_CFG" ]; then cp -f "$CUSTOM_CFG" /tmp/upload/mihomo_custom.txt; else : > /tmp/upload/mihomo_custom.txt; fi
		;;
	dump_config) dump_config ;;
	tg_test) tg_test ;;
	dump_storage) dump_storage ;;
	watchdog)
		[ -f "$CORE_LOG" ] && [ "$(wc -c < "$CORE_LOG")" -gt 1048576 ] && tail -n 200 "$CORE_LOG" > "$CORE_LOG.t" && mv -f "$CORE_LOG.t" "$CORE_LOG"
		[ "$mihomo_enable" = "1" ] || return 0
		if ! is_running; then
			echo_log "守护：检测到 Mihomo 未运行，重新启动"
			stop_mihomo
			if start_mihomo; then tg_notify fail "⚠️ Mihomo 意外退出，守护已自动重启"; else echo_log "守护：重启失败，已恢复为直连"; fi
		elif ! ports_ok; then
			# 进程还在但端口没在监听（卡死或端口被占），继续劫持只会让全家断网
			sleep 5
			if ! ports_ok; then
				echo_log "守护：Mihomo 端口无响应，重新启动"
				stop_mihomo
				if start_mihomo; then tg_notify fail "⚠️ Mihomo 端口无响应，守护已自动重启"; else echo_log "守护：重启失败，已恢复为直连"; fi
			fi
		elif ! rules_ok; then
			echo_log "守护：防火墙规则丢失（可能被其它程序重载），重新加载"
			apply_rules
		elif [ "$(date +%M)" = "07" ]; then
			# 每小时：同步「节点订阅」模式的流量信息、检查流量 / 到期提醒、补发没发出去的通知
			cache_save
			adg_bg
			migrate_subs; resolve_active
			[ "$mihomo_cfg_mode" = "provider" ] && { provider_info_sync; write_subinfo_json; }
			tg_traffic_check
			[ -s "$TG_QUEUE" ] && [ "$mihomo_tg_enable" = "1" ] && ( exec 9>&-; tg_flush ) </dev/null >/dev/null 2>&1 &
		fi
		;;
	*)
		echo "用法: $0 {start|stop|restart|update_sub|update_geo|check_core|update_core|check_plugin|update_plugin|watchdog}"
		;;
	esac
}

mkdir -p /tmp/upload
if [ -n "$WEB_ID" ]; then
	# Web 调用：先返回，再在后台执行，页面轮询日志
	case "$ACTION" in
	dump_custom|dump_config|dump_storage)
		run_action
		http_response "$WEB_ID"
		;;
	*)
		http_response "$WEB_ID"
		# 插件自更新时由安装进程写 MIHOMO_DONE
		( flock -x 9 2>/dev/null; run_action; [ "$SELF_UPDATING" = "1" ] || echo "MIHOMO_DONE" >> "$LOG" ) 9>"$LOCK" >/dev/null 2>&1 &
		;;
	esac
elif [ "$ACTION" = "watchdog" ] || [ "$ACTION" = "auto_update" ]; then
	# 有其它操作（保存/更新订阅）正在进行时，本轮守护直接跳过
	( if command -v flock >/dev/null 2>&1; then flock -n -x 9 || exit 0; fi; run_action ) 9>"$LOCK"
elif [ "$ACTION" = "start" ] && [ "$mihomo_enable" = "1" ] && booting && ! is_running; then
	# 开机：后台等时间同步/延迟后再启动，不拖慢其它插件启动
	( boot_wait; flock -x 9 2>/dev/null; run_action ) 9>"$LOCK" </dev/null >/dev/null 2>&1 &
else
	( flock -x 9 2>/dev/null; run_action ) 9>"$LOCK"
fi
