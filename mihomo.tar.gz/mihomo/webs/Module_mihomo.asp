<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html xmlns:v>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache"/>
<meta HTTP-EQUIV="Expires" CONTENT="-1"/>
<link rel="shortcut icon" href="images/favicon.png"/>
<link rel="icon" href="images/favicon.png"/>
<title>软件中心 - Mihomo</title>
<link rel="stylesheet" type="text/css" href="index_style.css"/>
<link rel="stylesheet" type="text/css" href="form_style.css"/>
<link rel="stylesheet" type="text/css" href="usp_style.css"/>
<link rel="stylesheet" type="text/css" href="ParentalControl.css">
<link rel="stylesheet" type="text/css" href="css/icon.css">
<link rel="stylesheet" type="text/css" href="css/element.css">
<link rel="stylesheet" type="text/css" href="res/softcenter.css">
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script type="text/javascript" src="/help.js"></script>
<script type="text/javascript" src="/validator.js"></script>
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/switcherplugin/jquery.iphone-switch.js"></script>
<script type="text/javascript" src="/res/softcenter.js"></script>
<style>
/* ===== Mihomo 设置页（v1.9.0，FlClash 风格；浅色蓝 / 深色橙，可跟随系统） ===== */
#mh{--bg:#f1f2f6;--bg2:#e9e6f4;--sf:#ffffff;--sf2:#f2f3f7;--sf3:#e6e8ef;--line:rgba(17,24,39,.07);--line2:rgba(17,24,39,.14);--tx:#111827;--sec:#4b5563;--mut:#9aa1ad;
  --acc:#1677ff;--acc2:#4f9bff;--on:#fff;--accs:rgba(22,119,255,.12);--ok:#16a34a;--oks:rgba(34,197,94,.15);--warn:#d97706;--warns:rgba(245,158,11,.15);--err:#dc2626;--errs:rgba(220,38,38,.11);
  --sh:0 1px 2px rgba(15,23,42,.04),0 10px 30px -18px rgba(15,23,42,.28);--logbg:#f7f8fb;--logtx:#1f2937;
  position:relative;margin:-5px;padding:18px 18px 16px;border-radius:0;background:var(--bg);background-image:radial-gradient(60% 40% at 0% 0%,var(--bg2),transparent 70%),radial-gradient(50% 40% at 100% 0%,rgba(236,72,153,.06),transparent 70%);
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","PingFang SC","Microsoft YaHei",Arial,sans-serif;color:var(--tx);font-size:13px;line-height:1.6;-webkit-font-smoothing:antialiased;color-scheme:light;transition:background .25s}
#mh[data-theme=dark]{--bg:#0e0e10;--bg2:#1a1418;--sf:#1c1b1e;--sf2:#262529;--sf3:#302f34;--line:rgba(255,255,255,.06);--line2:rgba(255,255,255,.14);--tx:#f4f3f6;--sec:#c9c7ce;--mut:#8b8992;
  --acc:#ff9b3d;--acc2:#ffb86b;--on:#1f1203;--accs:rgba(255,155,61,.14);--ok:#4ade80;--oks:rgba(74,222,128,.14);--warn:#fbbf24;--warns:rgba(251,191,36,.14);--err:#f87171;--errs:rgba(248,113,113,.14);
  --sh:0 1px 2px rgba(0,0,0,.3),0 12px 30px -18px rgba(0,0,0,.6);--logbg:#121214;--logtx:#d6d3dc;color-scheme:dark}
#mh *{box-sizing:border-box}
#mh b{font-variant-numeric:tabular-nums}
#mh svg.i{width:18px;height:18px;flex:0 0 auto;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}

/* 顶栏 */
#mh .mh-head{display:flex;align-items:center;gap:12px;margin-bottom:16px}
#mh .mh-logo{width:42px;height:42px;flex:0 0 auto;border-radius:13px;background:var(--acc);color:var(--on);display:grid;place-items:center;box-shadow:0 8px 18px -8px var(--acc)}
#mh .mh-logo svg{width:22px;height:22px}
#mh .mh-logo svg path{fill:currentColor}
#mh .mh-htext{flex:1;min-width:0}
#mh .mh-title{font-size:22px;font-weight:800;letter-spacing:-.4px;color:var(--tx);line-height:1.2}
#mh .mh-chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:4px}
#mh .mh-chip{display:inline-block;font-size:11px;font-weight:700;line-height:20px;padding:0 9px;border-radius:999px;background:var(--sf);color:var(--sec);box-shadow:var(--sh)}
#mh .mh-chip:empty{display:none}
#mh .mh-ibtn{width:38px;height:38px;flex:0 0 auto;border:0;border-radius:50%;display:grid;place-items:center;background:var(--sf);color:var(--sec);box-shadow:var(--sh);cursor:pointer;transition:transform .12s,color .15s;padding:0}
#mh .mh-ibtn:hover{color:var(--tx)}
#mh .mh-ibtn:active{transform:scale(.94)}
#mh .mh-desc{display:none}

/* 状态卡 */
#mh .mh-hero{display:grid;grid-template-columns:1.55fr 1fr;gap:12px;margin-bottom:14px}
#mh .mh-scard{background:var(--sf);border:1px solid var(--line);border-radius:22px;padding:16px 18px;box-shadow:var(--sh);min-width:0;position:relative;overflow:hidden}
#mh .mh-ch{display:flex;align-items:center;gap:8px;color:var(--sec);font-size:13px;font-weight:600;margin-bottom:8px}
#mh .mh-ch svg.i{width:16px;height:16px;color:var(--mut)}
#mh .mh-status{min-height:150px;display:flex;flex-direction:column;padding-right:130px}
#mh .mh-status .blob{position:absolute;right:-50px;top:-60px;width:250px;height:250px;color:var(--accs);pointer-events:none}
#mh .mh-badge{display:inline-flex;align-items:center;gap:6px;font-weight:700;font-size:11.5px;line-height:18px;padding:2px 10px;border-radius:999px;background:var(--sf2);color:var(--sec)}
#mh .mh-badge i{display:inline-block;position:relative;width:7px;height:7px;border-radius:50%;background:currentColor}
#mh .mh-badge.ok{color:var(--ok);background:var(--oks)} #mh .mh-badge.warn{color:var(--warn);background:var(--warns)} #mh .mh-badge.err{color:var(--err);background:var(--errs)}
#mh .mh-badge.ok i:after,#mh .mh-badge.warn i:after{content:'';position:absolute;left:-4px;top:-4px;right:-4px;bottom:-4px;border-radius:50%;background:currentColor;opacity:.35;animation:mhpulse 1.8s ease-out infinite}
@keyframes mhpulse{0%{transform:scale(.5);opacity:.5}100%{transform:scale(1.6);opacity:0}}
#mh .mh-metrics{display:flex;gap:26px;margin-top:auto;position:relative}
#mh .mh-status .mh-metrics{margin-top:14px}
/* 值勤机器人 */
#mh .bot-wrap{position:relative;display:flex;align-items:center;gap:12px;margin-top:10px}
#mh .bot{--bc:#3b82f6;flex:0 0 auto;width:140px;height:176px;border:0;padding:0;background:transparent;cursor:pointer;position:relative}
#mh .bot[data-st=ok]{--bc:#22c55e} #mh .bot[data-st=warn]{--bc:#f59e0b} #mh .bot[data-st=err]{--bc:#ef4444} #mh .bot[data-st=sleep]{--bc:#94a3b8}
#mh .bot-plat{position:absolute;left:10px;right:10px;bottom:2px;height:18px;border-radius:50%;background:radial-gradient(closest-side,var(--bc),transparent);opacity:.55;transition:background .4s;animation:botPlat 3.2s ease-in-out infinite}
#mh .bot-plat:after{content:"";position:absolute;inset:3px 8px;border-radius:50%;border:1.5px solid var(--bc);opacity:.8}
#mh .bot-figw{position:absolute;left:0;right:0;bottom:8px;height:166px;animation:botFloat 3.2s ease-in-out infinite}
#mh .bot-fig{position:absolute;left:0;right:0;bottom:0;margin:0 auto;opacity:0;transform:translateY(8px) scale(.96);transform-origin:50% 100%;transition:opacity .45s,transform .45s,filter .4s;filter:drop-shadow(0 6px 10px rgba(30,64,175,.18));pointer-events:none}
#mh .bot-fig.p-stand{height:100%} #mh .bot-fig.p-sit{height:136px} #mh .bot-fig.p-sleep{width:142px;bottom:2px} #mh .bot-fig.p-cheer{height:148px;-webkit-mask-image:linear-gradient(#000 78%,transparent);mask-image:linear-gradient(#000 78%,transparent)}
#mh .bot[data-pose=stand] .p-stand,#mh .bot[data-pose=sit] .p-sit,#mh .bot[data-pose=sleep] .p-sleep,#mh .bot[data-pose=cheer] .p-cheer{opacity:1;transform:none;animation:botBreath 3.4s ease-in-out infinite}
#mh .bot[data-pose=sit] .p-sit{animation:botRock 4.2s ease-in-out infinite}
#mh .bot[data-pose=sleep] .p-sleep{animation:botSleepB 4.6s ease-in-out infinite}
#mh .bot[data-pose=cheer] .p-cheer{animation:botCheer .55s ease-in-out 5}
#mh .bot[data-pose=sit] .bot-figw,#mh .bot[data-pose=sleep] .bot-figw{animation:none}
#mh .bot-fx .think{position:absolute;left:14px;top:30px;display:flex;gap:3px;background:#fff;border-radius:12px;padding:6px 8px;box-shadow:0 2px 8px rgba(0,0,0,.12)}
#mh .bot-fx .think em{width:5px;height:5px;border-radius:50%;background:#94a3b8;animation:botBlink 1.2s infinite} #mh .bot-fx .think em:nth-child(2){animation-delay:.2s} #mh .bot-fx .think em:nth-child(3){animation-delay:.4s}
#mh .bot[data-st=ok] .bot-figw{animation:botHop 2.4s ease-in-out infinite}
#mh .bot[data-st=err] .bot-figw{animation:botShake .45s ease-in-out 3,botFloat 3.2s ease-in-out 1.4s infinite}
#mh .bot[data-st=err] .bot-fig{filter:drop-shadow(0 0 8px rgba(239,68,68,.75))}
#mh .bot[data-st=warn] .bot-fig{filter:drop-shadow(0 0 6px rgba(245,158,11,.6))}
#mh .bot[data-st=sleep] .bot-figw{animation:botFloat 5.5s ease-in-out infinite}
#mh .bot[data-st=sleep] .bot-fig{filter:grayscale(.55) brightness(.95)}
#mh .bot-beam{position:absolute;left:0;right:0;top:0;height:4px;background:linear-gradient(90deg,transparent,var(--bc),transparent);box-shadow:0 0 10px var(--bc);opacity:0}
#mh .bot[data-st=scan] .bot-beam{opacity:.9;animation:botBeam 1.3s ease-in-out infinite}
#mh .bot-fx{position:absolute;left:0;right:0;top:0;height:60px;pointer-events:none}
#mh .bot-fx .fx{position:absolute;right:4px;top:8px;width:24px;height:24px;border-radius:12px;color:#fff;font:900 14px/24px system-ui,-apple-system,sans-serif;text-align:center;box-shadow:0 0 0 2.5px var(--card,#fff),0 3px 8px rgba(0,0,0,.18);animation:botPop .35s cubic-bezier(.3,1.7,.5,1)}
#mh .bot-fx .fx.ok{background:#22c55e} #mh .bot-fx .fx.warn{background:#f59e0b} #mh .bot-fx .fx.err{background:#ef4444;animation:botPop .35s cubic-bezier(.3,1.7,.5,1),botBlink 1s .4s infinite}
#mh .bot-fx .sp{position:absolute;font-style:normal;color:#facc15;font-size:13px;animation:botTw 1.8s ease-in-out infinite}
#mh .bot-fx .s1{left:4px;top:18px} #mh .bot-fx .s2{left:24px;top:2px;font-size:9px;animation-delay:.6s} #mh .bot-fx .s3{right:30px;top:0;font-size:10px;color:#f9a8d4;animation-delay:1.1s}
#mh .bot-fx .sweat{position:absolute;right:30px;top:30px;width:8px;height:11px;background:#7dd3fc;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;animation:botSweat 1.6s ease-in infinite}
#mh .bot-fx .zz{position:absolute;font:900 12px/1 system-ui,sans-serif;font-style:normal;color:#94a3b8;animation:botZz 2.4s ease-in-out infinite}
#mh .bot-fx .z1{right:26px;top:56px} #mh .bot-fx .z2{right:14px;top:40px;font-size:14px;animation-delay:.8s} #mh .bot-fx .z3{right:2px;top:22px;font-size:17px;animation-delay:1.6s}
#mh .bot-say{flex:1;min-width:0}
#mh .bot-bubble{position:relative;background:var(--bg2,rgba(127,127,127,.08));border-radius:16px;padding:10px 13px;max-width:440px}
#mh .bot-bubble:before{content:"";position:absolute;left:-7px;top:22px;border:7px solid transparent;border-left:0;border-right-color:var(--bg2,rgba(127,127,127,.08))}
#mh .bot-msg{font-size:13.5px;font-weight:700;color:var(--tx);line-height:1.45}
#mh .bot-msg em{font-style:normal;color:var(--bc2,var(--acc))}
#mh .bot-sub{font-size:11.5px;color:var(--mut);margin-top:3px;line-height:1.45}
#mh .bot-chips{position:relative;display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
#mh .bot-chip{display:inline-flex;align-items:center;gap:5px;border:0;border-radius:999px;padding:4px 10px 4px 8px;font-size:11.5px;font-weight:600;cursor:pointer;background:rgba(127,127,127,.09);color:var(--sec,var(--tx));transition:transform .12s}
#mh .bot-chip:hover{transform:translateY(-1px)}
#mh .bot-chip i{width:7px;height:7px;border-radius:50%;background:#22c55e;flex:0 0 auto}
#mh .bot-chip.warn{background:rgba(245,158,11,.14);color:#b45309} #mh .bot-chip.warn i{background:#f59e0b}
#mh .bot-chip.err{background:rgba(239,68,68,.13);color:#dc2626} #mh .bot-chip.err i{background:#ef4444;animation:botBlink 1s infinite}
#mh .bot-chip.off{opacity:.55} #mh .bot-chip.off i{background:#94a3b8}
#mh .bot-chip.sel{outline:2px solid var(--acc);outline-offset:1px}
#mh .bot-say{cursor:pointer}
#mh .bp-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}
#mh .bp-sum{font-size:15px;font-weight:800;color:var(--tx);display:flex;align-items:center;gap:8px;flex-wrap:wrap}
#mh .bp-top .mh-btn{white-space:nowrap;flex:0 0 auto}
#mh .bp-sum small{font-size:11.5px;font-weight:500;color:var(--mut)}
#mh .bp-face{width:10px;height:10px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 4px rgba(34,197,94,.18)}
#mh .bp-face.warn{background:#f59e0b;box-shadow:0 0 0 4px rgba(245,158,11,.18)} #mh .bp-face.err{background:#ef4444;box-shadow:0 0 0 4px rgba(239,68,68,.18)} #mh .bp-face.sleep{background:#94a3b8;box-shadow:none}
#mh .bp-list{display:grid;grid-template-columns:1fr 1fr;gap:6px}
@media (max-width:640px){#mh .bp-list{grid-template-columns:1fr}}
#mh .bp-it{display:flex;gap:8px;align-items:flex-start;padding:8px 10px;border-radius:12px;background:rgba(127,127,127,.07)}
#mh .bp-it i{width:8px;height:8px;border-radius:50%;background:#22c55e;margin-top:5px;flex:0 0 auto}
#mh .bp-it.warn{background:rgba(245,158,11,.1)} #mh .bp-it.warn i{background:#f59e0b}
#mh .bp-it.err{background:rgba(239,68,68,.1)} #mh .bp-it.err i{background:#ef4444}
#mh .bp-it.off{opacity:.6} #mh .bp-it.off i{background:#94a3b8}
#mh .bp-it b{display:block;font-size:12.5px;color:var(--tx)} #mh .bp-it span{display:block;font-size:11.5px;color:var(--mut);line-height:1.45;margin-top:1px}
#mh .bp-more{display:block;border:0;background:transparent;color:var(--acc);font-size:12.5px;font-weight:600;cursor:pointer;padding:6px 0 0}
#mh .bp-list:empty{display:none}
#mh .bp-chat{margin-top:14px;border-top:1px solid rgba(127,127,127,.15);padding-top:12px}
#mh .bp-ct{font-size:13px;font-weight:800;color:var(--tx);margin-bottom:8px}
#mh .bp-msgs{max-height:300px;min-height:80px;overflow:auto;display:flex;flex-direction:column;gap:8px;padding:2px}
#mh .bp-m{display:flex;flex:0 0 auto}
#mh .bp-m.ai{gap:8px;align-items:flex-start}
#mh .bp-m.ai:before{content:"";flex:0 0 30px;height:30px;border-radius:50%;background:#eef2ff url(/res/mihomo_bot02_main.jpg) center/cover;box-shadow:0 0 0 2px rgba(99,102,241,.35)} #mh .bp-m.me{justify-content:flex-end}
#mh .bp-b{max-width:85%;padding:9px 12px;border-radius:14px;font-size:13px;line-height:1.55;color:var(--tx);background:rgba(99,102,241,.1);border-top-left-radius:4px}
#mh .bp-m.me .bp-b{background:var(--acc);color:#fff;border-radius:14px;border-top-right-radius:4px}
#mh .bp-by{font-size:10.5px;color:var(--mut);margin-top:6px} #mh .bp-by.err{color:#d97706}
#mh .bp-mode span{font-size:11px;font-weight:500;color:var(--mut);margin-left:6px} #mh .bp-mode span.on{color:#16a34a;font-weight:700}
#mh .ai-res{font-size:12px;color:var(--mut);align-self:center} #mh .ai-res.ok{color:#16a34a;font-weight:600} #mh .ai-res.err{color:#dc2626}
#mh .bp-acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
#mh .bp-dots{display:flex;gap:4px;padding:12px 14px} #mh .bp-dots i{width:6px;height:6px;border-radius:50%;background:var(--mut);animation:botBlink 1s infinite} #mh .bp-dots i:nth-child(2){animation-delay:.2s} #mh .bp-dots i:nth-child(3){animation-delay:.4s}
#mh .bp-sugs{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 8px}
#mh .bp-sug{border:1px solid rgba(99,102,241,.35);background:transparent;color:#6366f1;border-radius:999px;padding:4px 10px;font-size:12px;cursor:pointer}
#mh .bp-in{display:flex;gap:8px} #mh .bp-in .mh-input{flex:1;min-width:0}
@keyframes botSpin{to{transform:rotate(360deg)}}
@keyframes botBreath{0%,100%{transform:scale(1,1)}50%{transform:scale(1.012,1.022)}}
@keyframes botRock{0%,100%{transform:rotate(-1.6deg)}50%{transform:rotate(1.6deg) scale(1.01,1.02)}}
@keyframes botSleepB{0%,100%{transform:scale(1,1)}45%{transform:scale(1.02,1.045)}}
@keyframes botCheer{0%,100%{transform:translateY(0) rotate(0)}30%{transform:translateY(-9px) rotate(-3deg)}60%{transform:translateY(-3px) rotate(3deg)}}
@keyframes botHop{0%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}55%{transform:translateY(-1px)}}
@keyframes botPlat{0%,100%{transform:scaleX(1);opacity:.55}50%{transform:scaleX(.88);opacity:.35}}
@keyframes botBeam{0%{top:4%}50%{top:92%}100%{top:4%}}
@keyframes botPop{0%{transform:scale(0)}100%{transform:scale(1)}}
@keyframes botTw{0%,100%{opacity:.2;transform:scale(.7)}50%{opacity:1;transform:scale(1.15)}}
@keyframes botSweat{0%{opacity:0;transform:translateY(-4px)}30%{opacity:1}100%{opacity:0;transform:translateY(10px)}}
@keyframes botFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@keyframes botShadow{0%,100%{transform:scaleX(1);opacity:1}50%{transform:scaleX(.85);opacity:.7}}
@keyframes botBlink{0%,100%{opacity:1}50%{opacity:.35}}
@keyframes botWink{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}
@keyframes botScan{0%,100%{transform:translateX(-7px)}50%{transform:translateX(7px)}}
@keyframes botShake{0%,100%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}}
@keyframes botWave{0%,60%,100%{transform:rotate(0)}70%,90%{transform:rotate(-35deg)}80%{transform:rotate(-15deg)}}
@keyframes botZz{0%{opacity:0;transform:translate(0,0)}30%{opacity:1}100%{opacity:0;transform:translate(10px,-14px)}}
@media (prefers-reduced-motion:reduce){#mh .bot *{animation:none!important}}
#mh .mh-metrics span{display:block;font-size:12px;color:var(--mut)}
#mh .mh-metrics b{display:block;font-size:22px;font-weight:800;letter-spacing:-.4px;color:var(--tx);white-space:nowrap}
#mh .mh-metrics b small{font-size:12px;font-weight:700;color:var(--sec);margin-left:3px;letter-spacing:0}
#mh #st_hint{position:relative;color:var(--mut);font-size:12.5px;margin-top:6px}
#mh .mh-power{position:absolute;right:26px;top:50%;margin-top:-44px;width:88px;height:88px;border:0;padding:0;background:transparent;cursor:pointer;color:var(--acc);transition:transform .15s}
#mh .mh-power:active{transform:scale(.94)}
#mh .mh-power svg.cookie{position:absolute;left:0;top:0;width:100%;height:100%;filter:drop-shadow(0 8px 18px rgba(0,0,0,.18));transition:transform .6s cubic-bezier(.2,.8,.2,1)}
#mh .mh-power:hover svg.cookie{transform:rotate(30deg)}
#mh .mh-power .pi{position:absolute;left:0;top:0;right:0;bottom:0;display:grid;place-items:center;color:var(--on)}
#mh .mh-power .pi svg{width:28px;height:28px;fill:currentColor}
#mh .mh-power.off{color:var(--mut)}
#mh .mh-power.off .pi{color:#fff}
#mh .mh-side{display:flex;flex-direction:column;gap:12px}
#mh .mh-side .mh-scard{flex:1;display:flex;flex-direction:column}
#mh #ui_link{margin-top:auto}
#mh #ui_link a{display:flex;align-items:center;justify-content:center;gap:8px;color:var(--on);text-decoration:none;font-weight:700;font-size:13.5px;padding:11px 14px;border-radius:14px;background:var(--acc);box-shadow:0 8px 18px -8px var(--acc)}
#mh #ui_link a svg{stroke:currentColor}
#mh #ui_link a:hover{filter:brightness(1.06)}
#mh #ui_link .off{display:block;text-align:center;padding:11px;border-radius:14px;background:var(--sf2);color:var(--mut);font-size:12.5px;font-weight:600}
#mh .mh-ping{display:flex;flex-direction:column;gap:6px;cursor:pointer}
#mh .mh-pill{display:flex;align-items:center;gap:8px;padding:6px 10px 6px 6px;border-radius:12px;background:var(--sf2);font-size:12.5px;color:var(--mut);white-space:nowrap;transition:background .2s}
#mh .mh-pill em{flex:1;font-style:normal;color:var(--sec);font-weight:600}
#mh .mh-pill b{font-weight:800;color:inherit}
#mh .mh-pill i{display:inline-flex;align-items:center;justify-content:center;position:relative;width:22px;height:22px;border-radius:7px;background:#fff;flex:0 0 auto;box-shadow:0 0 0 1px var(--line2)}
#mh .mh-pill i img{width:15px;height:15px;display:block}
#mh .mh-pill.good{color:var(--ok)} #mh .mh-pill.mid{color:var(--warn)} #mh .mh-pill.bad{color:var(--err)}
#mh .mh-pill.beat i:after{content:'';position:absolute;left:-4px;top:-4px;right:-4px;bottom:-4px;border-radius:9px;border:2px solid currentColor;opacity:0;animation:mhbeat .9s ease-out}
@keyframes mhbeat{0%{transform:scale(.7);opacity:.7}100%{transform:scale(1.3);opacity:0}}
#mh .mh-pill.testing i{animation:mhblink .6s ease-in-out infinite alternate}
@keyframes mhblink{from{opacity:1}to{opacity:.45}}

/* 标签页 */
#mh .mh-tabs{display:flex;gap:4px;padding:5px;margin-bottom:12px;background:var(--sf);border:1px solid var(--line);border-radius:18px;box-shadow:var(--sh)}
#mh .mh-tabs a{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;text-align:center;padding:8px 2px 7px;border-radius:13px;color:var(--sec);font-weight:700;font-size:12px;cursor:pointer;background:transparent;transition:background .15s,color .15s;margin:0;text-decoration:none}
#mh .mh-tabs a svg.i{width:18px;height:18px}
#mh .mh-tabs a:hover{color:var(--tx);background:var(--sf2)}
#mh .mh-tabs a.active{background:var(--acc);color:var(--on);box-shadow:0 6px 14px -6px var(--acc)}

/* 设置卡 */
#mh .mh-card{background:var(--sf);border:1px solid var(--line);border-radius:22px;padding:4px 18px;box-shadow:var(--sh)}
#mh .mh-row{display:flex;gap:16px;padding:14px 0;border-bottom:1px solid var(--line);align-items:flex-start}
#mh .mh-row:last-child{border-bottom:0}
#mh .mh-row>label.k,#mh .mh-row>.k{flex:0 0 150px;font-weight:700;font-size:13.5px;color:var(--tx);padding-top:8px;line-height:1.4;margin:0}
#mh .mh-row .k small{display:block;font-weight:500;font-size:11.5px;color:var(--mut);margin-top:3px}
#mh .mh-row>.v{flex:1;min-width:0}
#mh .mh-row.sw>.k{padding-top:3px}

/* 输入控件 */
#mh input.mh-input,#mh select.mh-sel,#mh textarea.mh-area{width:100%;max-width:100%;height:auto;background:var(--sf2);color:var(--tx);border:1px solid transparent;border-radius:12px;padding:9px 12px;font-size:13px;font-family:inherit;outline:none;box-shadow:none;transition:border-color .15s,box-shadow .15s,background .15s;margin:0}
#mh input.mh-input.short,#mh select.mh-sel{width:auto;min-width:240px;min-width:min(240px,100%)}
#mh input.mh-input.port{width:110px;min-width:0}
#mh select.mh-sel{-webkit-appearance:none;appearance:none;padding-right:34px;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239aa1ad' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center}
#mh select.mh-sel option{background:var(--sf);color:var(--tx)}
#mh textarea.mh-area{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,"Lucida Console",monospace;font-size:12px;line-height:1.6;resize:vertical}
#mh input.mh-input:focus,#mh select.mh-sel:focus,#mh textarea.mh-area:focus{border-color:var(--acc);box-shadow:0 0 0 4px var(--accs);background:var(--sf)}
#mh input.mh-input::placeholder,#mh textarea.mh-area::placeholder{color:var(--mut)}
#mh #mihomo_sub_url{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px}

/* 开关（Material 3） */
#mh .mh-switch{display:inline-flex;align-items:flex-start;gap:12px;cursor:pointer;color:var(--sec);font-weight:500}
#mh .mh-switch input{-webkit-appearance:none;appearance:none;position:relative;flex:0 0 auto;width:46px;height:26px;margin:0;border-radius:999px;background:var(--sf3);border:2px solid var(--line2);cursor:pointer;transition:background .2s,border-color .2s;outline:none}
#mh .mh-switch input:before{content:'';position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:var(--mut);transition:transform .2s,background .2s,width .2s,height .2s,top .2s,left .2s}
#mh .mh-switch input:checked{background:var(--acc);border-color:var(--acc)}
#mh .mh-switch input:checked:before{background:var(--on);width:20px;height:20px;top:1px;left:1px;transform:translateX(20px)}
#mh .mh-switch input:focus-visible{box-shadow:0 0 0 4px var(--accs)}
#mh .mh-switch span{padding-top:2px;line-height:1.5}

/* 提示 */
#mh .mh-tip,#mh .mh-hint{display:block;color:var(--mut);font-size:12px;line-height:1.65;margin-top:6px}
#mh .mh-info{display:block;margin-top:8px;padding:9px 12px;border-radius:12px;background:var(--accs);color:var(--acc);font-size:12px;line-height:1.65}
#mh .mh-info:empty{display:none}
#mh .mh-warnbox{display:block;margin-top:8px;padding:9px 12px;border-radius:12px;background:var(--warns);color:var(--warn);font-size:12px;line-height:1.65}
#mh .mh-warnbox code,#mh .mh-tip code,#mh .mh-note code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;background:var(--sf2);padding:1px 6px;border-radius:5px;color:var(--err)}
#mh .mh-ok{color:var(--ok);font-weight:700} #mh .mh-err{color:var(--err);font-weight:700} #mh .mh-run{color:var(--warn);font-weight:700}
#mh #sub_time{color:var(--mut);font-size:11.5px;margin-top:5px}

/* 日志 / 配置 */
#mh #panel7{background:var(--sf);border:1px solid var(--line);border-radius:22px;padding:14px 16px;box-shadow:var(--sh)}
#mh .mh-logbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;min-height:24px}
#mh .mh-logbar .t{font-weight:800;font-size:14px}
#mh textarea.mh-log,#mh textarea.mh-cfg{width:100%;height:340px;margin:0;background:var(--logbg);color:var(--logtx);border:1px solid var(--line);border-radius:14px;padding:12px 14px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,"Lucida Console",monospace;font-size:12px;line-height:1.7;resize:vertical;outline:none;box-shadow:none}
#mh textarea.mh-cfg{height:420px;font-size:11.5px}

/* 按钮 */
#mh .mh-btns{position:sticky;bottom:8px;z-index:5;display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin:14px auto 4px;padding:8px;width:max-content;max-width:100%;border-radius:20px;background:var(--sf);border:1px solid var(--line);box-shadow:0 12px 30px -12px rgba(0,0,0,.35)}
#mh .mh-btn{-webkit-appearance:none;appearance:none;height:auto;border:0;border-radius:13px;padding:10px 22px;font-size:13.5px;font-weight:700;font-family:inherit;color:var(--sec);background:var(--sf2);cursor:pointer;transition:transform .12s,background .15s,filter .15s;min-width:0;margin:0;line-height:1.4}
#mh .mh-btn:hover{background:var(--sf3);color:var(--tx)}
#mh .mh-btn:active{transform:scale(.97)}
#mh .mh-btn.primary{background:var(--acc);color:var(--on);box-shadow:0 8px 18px -8px var(--acc)}
#mh .mh-btn.primary:hover{filter:brightness(1.06);background:var(--acc);color:var(--on)}
#mh .mh-btn[disabled]{opacity:.45;cursor:not-allowed;transform:none}
#mh .mh-btn.sm{padding:6px 12px;font-size:12px;border-radius:10px}
#mh .mh-btn.danger{color:var(--err);background:var(--errs)}

/* 底部说明 */
#mh .mh-note{margin-top:14px;padding:12px 16px;border-radius:18px;background:var(--sf2);color:var(--mut);font-size:12px;line-height:1.9}
#mh .mh-note b{color:var(--sec);font-weight:600}
#mh .mh-ports{display:flex;flex-wrap:wrap;gap:6px;margin:2px 0 6px}
#mh .mh-ports span{font-size:11.5px;padding:2px 10px;border-radius:999px;background:var(--sf);color:var(--sec)}
#mh .mh-ports span b{color:var(--tx);margin-left:4px}
#mh .mh-enable-v{display:block}

/* 订阅列表 */
#mh .sub-list{display:flex;flex-direction:column;gap:8px}
#mh .sub-item{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;padding:11px 12px;border-radius:16px;background:var(--sf2);border:1px solid transparent}
#mh .sub-item.on{border-color:var(--acc);background:var(--accs)}
#mh .sub-item input[type=radio]{width:18px;height:18px;margin:0;accent-color:var(--acc);cursor:pointer}
#mh .sub-main{min-width:0}
#mh .sub-name{font-weight:800;color:var(--tx);display:flex;align-items:center;gap:8px;flex-wrap:wrap}
#mh .sub-name .tag{font-size:10.5px;font-weight:700;padding:0 8px;line-height:18px;border-radius:999px;background:var(--acc);color:var(--on)}
#mh .sub-url{font-size:11.5px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
#mh .sub-meta{font-size:11.5px;color:var(--sec);margin-top:4px;display:flex;gap:10px;flex-wrap:wrap}
#mh .sub-bar{height:6px;border-radius:6px;background:var(--sf3);margin-top:6px;overflow:hidden}
#mh .sub-bar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,var(--acc),var(--acc2))}
#mh .sub-bar i.warn{background:linear-gradient(90deg,#fbbf24,#f97316)} #mh .sub-bar i.err{background:linear-gradient(90deg,#f87171,#ef4444)}
#mh .sub-ops{display:flex;gap:6px}
#mh .sub-add{display:grid;grid-template-columns:150px 1fr auto;gap:8px;margin-top:10px}
#mh .sub-empty{padding:16px;border-radius:16px;border:1px dashed var(--line2);color:var(--mut);text-align:center;font-size:12.5px}
#mh .dirty{display:none;margin-top:8px;color:var(--warn);font-size:12px}
#mh .dirty.show{display:block}
#mh .kv2{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:13px;align-items:center}
#mh .kv2 span{color:var(--mut)} #mh .kv2 b{color:var(--tx);font-weight:800}
#mh .row-btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
#mh .adt-box{margin-top:10px;max-height:320px;overflow:auto;border-radius:12px}
#mh .adt-box:empty{display:none}
#mh .adt-head,#mh .adt-empty{font-size:12px;color:var(--mh-sub,#8a8fa3);padding:4px 2px 6px}
#mh .adt{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border-radius:10px;background:rgba(127,127,127,.07);margin-bottom:6px}
#mh .adt-d{min-width:0;display:flex;flex-direction:column;gap:2px}
#mh .adt-d code{font-size:12.5px;word-break:break-all}
#mh .adt-d small{font-size:11.5px;color:var(--mh-sub,#8a8fa3)}
#mh .adt-b{display:flex;gap:6px;flex:0 0 auto;align-items:center;flex-wrap:wrap;justify-content:flex-end}
#mh .adt-ad{color:#dc2626;font-weight:600}
#mh .adt-ok{font-size:12px;color:#16a34a;font-weight:600}
#mh .adt-note{font-size:11.5px;color:#d97706;max-width:150px;text-align:right}
#mh .chk{display:flex;flex-direction:column;gap:10px}
/* 快捷开关（Clash Party 风格卡片网格） */
#mh .qgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;padding:16px 0 6px}
#mh .qt{position:relative;display:flex;flex-direction:column;gap:2px;min-height:96px;padding:13px 14px;border-radius:18px;background:var(--sf2);border:1.5px solid transparent;cursor:pointer;transition:background .2s,border-color .2s,transform .12s;user-select:none;-webkit-user-select:none}
#mh .qt:active{transform:scale(.98)}
#mh .qt:hover{border-color:var(--line2)}
#mh .qt .qi{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:var(--sf);color:var(--sec);margin-bottom:8px;transition:background .2s,color .2s}
#mh .qt .qi svg.i{width:18px;height:18px}
#mh .qt b{font-size:14px;font-weight:800;color:var(--tx)}
#mh .qt span{font-size:11.5px;color:var(--mut);line-height:1.45}
#mh .qt .qs{position:absolute;right:12px;top:14px;width:38px;height:22px;border-radius:999px;background:var(--sf3);border:2px solid var(--line2);transition:background .2s,border-color .2s}
#mh .qt .qs:before{content:'';position:absolute;left:2px;top:2px;width:14px;height:14px;border-radius:50%;background:var(--mut);transition:transform .2s,background .2s}
#mh .qt.on{background:var(--accs)}
#mh .qt.on .qi{background:var(--acc);color:var(--on)}
#mh .qt.on .qs{background:var(--acc);border-color:var(--acc)}
#mh .qt.on .qs:before{background:var(--on);transform:translateX(16px)}
#mh .qt.dirty{border-color:var(--warn)}
#mh .qt.dirty:after{content:'未保存';position:absolute;right:12px;bottom:10px;font-size:10.5px;font-weight:700;color:var(--warn)}
#mh .qnote{display:none;margin:4px 0 10px;padding:9px 12px;border-radius:12px;background:var(--warns);color:var(--warn);font-size:12px;font-weight:600}
#mh .qnote.show{display:block}
#mh .mh-hsave{display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;height:38px;padding:0 16px;border-radius:19px;white-space:nowrap}
#mh .mh-hsave .i{width:16px;height:16px;stroke:currentColor;stroke-width:2.6;fill:none}
#mh .mh-hsave.pulse,#mh .mh-btns.pulse .primary{animation:mhglow 1.4s ease-in-out infinite}
@keyframes mhglow{0%,100%{box-shadow:0 8px 18px -8px var(--acc)}50%{box-shadow:0 0 0 6px var(--accs),0 8px 18px -8px var(--acc)}}

#mh .tg-evs{display:grid;grid-template-columns:1fr 1fr;gap:10px 18px}
#mh .tg-ev span{line-height:1.45}
#mh .tg-ev small{color:var(--mut);font-size:11.5px}

/* ===== 小组件布局 ===== */
#mh .mh-gone{display:none!important}
#mh .mh-sec{margin:0 0 14px}
#mh .mh-sect{font-size:12.5px;font-weight:800;color:var(--mut);letter-spacing:.5px;margin:2px 4px 8px}
/* 快捷开关：4 列小卡（图标、开关在上，标题在下） */
#mh .mh-sec .qgrid{grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;padding:0}
#mh .mh-sec .qt{min-height:0;display:block;padding:10px 12px 11px;border-radius:16px;background:var(--sf);border:1px solid var(--line);box-shadow:var(--sh)}
#mh .mh-sec .qt .qi{width:30px;height:30px;border-radius:10px;margin:0 0 8px;background:var(--sf2)}
#mh .mh-sec .qt .qi svg.i{width:16px;height:16px}
#mh .mh-sec .qt b{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#mh .mh-sec .qt>span:not(.qs){display:none}
#mh .mh-sec .qt .qs{top:14px;right:12px;width:36px;height:22px}
#mh .mh-sec .qt.on{background:var(--accs);border-color:transparent}
#mh .mh-sec .qt.dirty{border-color:var(--warn)}
#mh .mh-sec .qt.dirty:after{right:12px;bottom:12px;font-size:10px}
#mh .mh-sec .qnote{margin:8px 0 0}
/* 功能小卡片 */
#mh .wg-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
#mh .wg{position:relative;display:flex;flex-direction:column;min-width:0;min-height:112px;padding:12px 14px;border-radius:18px;background:var(--sf);border:1px solid var(--line);box-shadow:var(--sh);cursor:pointer;transition:transform .12s,border-color .15s,box-shadow .15s}
#mh .wg:hover{border-color:var(--line2);box-shadow:0 1px 2px rgba(0,0,0,.05),0 14px 30px -16px rgba(15,23,42,.35)}
#mh .wg:active{transform:scale(.985)}
#mh .wg.s2{grid-column:span 2}
#mh .wg.s4{grid-column:1/-1;min-height:0}
#mh .wg-h{display:flex;align-items:center;gap:8px;margin-bottom:8px;min-width:0}
#mh .wg-h b{flex:1;font-size:12.5px;font-weight:700;color:var(--sec);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#mh .wg-ic{width:26px;height:26px;flex:0 0 auto;border-radius:8px;display:grid;place-items:center;color:#fff}
#mh .wg-ic svg.i{width:15px;height:15px}
#mh .wg-chev{width:15px!important;height:15px!important;color:var(--mut);opacity:.6}
#mh .wg-v{font-size:17px;font-weight:800;color:var(--tx);letter-spacing:-.2px;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#mh .wg-s{margin-top:4px;font-size:11.5px;color:var(--mut);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
#mh .wg.s2 .wg-s{-webkit-line-clamp:3}
#mh .wg-x{position:absolute;right:12px;top:11px;display:flex;gap:6px}
#mh .wg.has-x .wg-chev{display:none}
#mh .wg.has-x .wg-h b{padding-right:58px}
#mh .wg-x:empty{display:none}
#mh .wg-act{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:999px;background:var(--sf2);color:var(--sec);font-size:11.5px;font-weight:700;cursor:pointer;transition:background .15s,color .15s}
#mh .wg-act:hover{background:var(--acc);color:var(--on)}
#mh .wg-act svg.i{width:12px;height:12px}
#mh .wg-bar{height:6px;border-radius:6px;background:var(--sf3);overflow:hidden;margin-top:8px}
#mh .wg-bar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,var(--acc),var(--acc2))}
#mh .wg-bar i.warn{background:linear-gradient(90deg,#fbbf24,#f97316)}#mh .wg-bar i.err{background:linear-gradient(90deg,#f87171,#ef4444)}
#mh .wdot{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--line2);margin:0 4px 1px 0;vertical-align:middle}
#mh .wdot.on{background:var(--ok)}
#mh .wwarn{color:var(--warn);font-weight:700}#mh .werr{color:var(--err);font-weight:700}#mh .wok{color:var(--ok);font-weight:700}#mh .wmut{color:var(--mut);font-weight:500;font-size:13px}
#mh .wg.s4 .wg-v{white-space:normal}
#mh .wg-log{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;font-weight:500;color:var(--sec);line-height:1.7;letter-spacing:0}
#mh .wg-log div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* 弹层 */
#mh .sh-ov{position:fixed;left:0;top:0;right:0;bottom:0;z-index:2000;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(10,12,20,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
#mh .sh-ov.open{display:flex;animation:mhfade .18s ease}
#mh .sh-ov.open .sh{animation:mhpop .24s cubic-bezier(.2,.9,.3,1.12)}
@keyframes mhfade{from{opacity:0}to{opacity:1}}
@keyframes mhpop{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
#mh .sh{width:min(640px,96vw);max-height:86vh;display:flex;flex-direction:column;background:var(--bg);border-radius:24px;box-shadow:0 30px 80px -20px rgba(0,0,0,.55);overflow:hidden}
#mh .sh-ov.wide .sh{width:min(860px,96vw)}
#mh .sh-head{display:flex;align-items:center;gap:10px;padding:14px 16px;background:var(--sf);border-bottom:1px solid var(--line)}
#mh .sh-head b{flex:1;font-size:16px;font-weight:800;color:var(--tx)}
#mh .sh-head .wg-ic{width:30px;height:30px;border-radius:10px}
#mh .sh-x{width:32px;height:32px;box-shadow:none;background:var(--sf2)}
#mh .sh-x svg.i{width:16px;height:16px}
#mh .sh-body{flex:1;overflow:auto;padding:14px}
#mh .sh-pane.mh-card{box-shadow:none}
#mh .sh-pane .mh-row>label.k,#mh .sh-pane .mh-row>.k{flex-basis:130px}
#mh .sh-pane textarea.mh-log{height:min(52vh,460px)}
#mh .sh-pane textarea.mh-cfg{height:min(56vh,520px)}
#mh .sh-pane .mh-logbar{margin-bottom:8px}
#mh .sh-foot{display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--sf);border-top:1px solid var(--line)}
#mh .sh-foot span{flex:1;font-size:11.5px;color:var(--mut)}
#mh .sh-foot .mh-btn{padding:9px 18px}
#mh .sh-done{border:0;border-radius:13px;padding:9px 18px;font-size:13.5px;font-weight:700;font-family:inherit;color:var(--sec);background:var(--sf2);cursor:pointer}
#mh .sh-done:hover{background:var(--sf3);color:var(--tx)}

</style>
<script>
var db_mihomo = {};
var _responseLen = 0;
var noChange = 0;
var status_timer = null;

function E(id){ return document.getElementById(id); }
function md5(str){
	function rh(n){var s="",j;for(j=0;j<=3;j++)s+=((n>>(j*8+4))&15).toString(16)+((n>>(j*8))&15).toString(16);return s}
	function ad(x,y){var l=(x&65535)+(y&65535);return(((x>>16)+(y>>16)+(l>>16))<<16)|(l&65535)}
	function rl(n,c){return(n<<c)|(n>>>(32-c))}
	function cm(q,a,b,x,s,t){return ad(rl(ad(ad(a,q),ad(x,t)),s),b)}
	function ff(a,b,c,d,x,s,t){return cm((b&c)|((~b)&d),a,b,x,s,t)}
	function gg(a,b,c,d,x,s,t){return cm((b&d)|(c&(~d)),a,b,x,s,t)}
	function hh(a,b,c,d,x,s,t){return cm(b^c^d,a,b,x,s,t)}
	function ii(a,b,c,d,x,s,t){return cm(c^(b|(~d)),a,b,x,s,t)}
	str=unescape(encodeURIComponent(str));
	var n=((str.length+8)>>6)+1,x=new Array(n*16),i;for(i=0;i<n*16;i++)x[i]=0;
	for(i=0;i<str.length;i++)x[i>>2]|=str.charCodeAt(i)<<((i%4)*8);
	x[i>>2]|=0x80<<((i%4)*8);x[n*16-2]=str.length*8;
	var a=1732584193,b=-271733879,c=-1732584194,d=271733878,oa,ob,oc,od;
	for(i=0;i<x.length;i+=16){oa=a;ob=b;oc=c;od=d;
	a=ff(a,b,c,d,x[i],7,-680876936);d=ff(d,a,b,c,x[i+1],12,-389564586);c=ff(c,d,a,b,x[i+2],17,606105819);b=ff(b,c,d,a,x[i+3],22,-1044525330);
	a=ff(a,b,c,d,x[i+4],7,-176418897);d=ff(d,a,b,c,x[i+5],12,1200080426);c=ff(c,d,a,b,x[i+6],17,-1473231341);b=ff(b,c,d,a,x[i+7],22,-45705983);
	a=ff(a,b,c,d,x[i+8],7,1770035416);d=ff(d,a,b,c,x[i+9],12,-1958414417);c=ff(c,d,a,b,x[i+10],17,-42063);b=ff(b,c,d,a,x[i+11],22,-1990404162);
	a=ff(a,b,c,d,x[i+12],7,1804603682);d=ff(d,a,b,c,x[i+13],12,-40341101);c=ff(c,d,a,b,x[i+14],17,-1502002290);b=ff(b,c,d,a,x[i+15],22,1236535329);
	a=gg(a,b,c,d,x[i+1],5,-165796510);d=gg(d,a,b,c,x[i+6],9,-1069501632);c=gg(c,d,a,b,x[i+11],14,643717713);b=gg(b,c,d,a,x[i],20,-373897302);
	a=gg(a,b,c,d,x[i+5],5,-701558691);d=gg(d,a,b,c,x[i+10],9,38016083);c=gg(c,d,a,b,x[i+15],14,-660478335);b=gg(b,c,d,a,x[i+4],20,-405537848);
	a=gg(a,b,c,d,x[i+9],5,568446438);d=gg(d,a,b,c,x[i+14],9,-1019803690);c=gg(c,d,a,b,x[i+3],14,-187363961);b=gg(b,c,d,a,x[i+8],20,1163531501);
	a=gg(a,b,c,d,x[i+13],5,-1444681467);d=gg(d,a,b,c,x[i+2],9,-51403784);c=gg(c,d,a,b,x[i+7],14,1735328473);b=gg(b,c,d,a,x[i+12],20,-1926607734);
	a=hh(a,b,c,d,x[i+5],4,-378558);d=hh(d,a,b,c,x[i+8],11,-2022574463);c=hh(c,d,a,b,x[i+11],16,1839030562);b=hh(b,c,d,a,x[i+14],23,-35309556);
	a=hh(a,b,c,d,x[i+1],4,-1530992060);d=hh(d,a,b,c,x[i+4],11,1272893353);c=hh(c,d,a,b,x[i+7],16,-155497632);b=hh(b,c,d,a,x[i+10],23,-1094730640);
	a=hh(a,b,c,d,x[i+13],4,681279174);d=hh(d,a,b,c,x[i],11,-358537222);c=hh(c,d,a,b,x[i+3],16,-722521979);b=hh(b,c,d,a,x[i+6],23,76029189);
	a=hh(a,b,c,d,x[i+9],4,-640364487);d=hh(d,a,b,c,x[i+12],11,-421815835);c=hh(c,d,a,b,x[i+15],16,530742520);b=hh(b,c,d,a,x[i+2],23,-995338651);
	a=ii(a,b,c,d,x[i],6,-198630844);d=ii(d,a,b,c,x[i+7],10,1126891415);c=ii(c,d,a,b,x[i+14],15,-1416354905);b=ii(b,c,d,a,x[i+5],21,-57434055);
	a=ii(a,b,c,d,x[i+12],6,1700485571);d=ii(d,a,b,c,x[i+3],10,-1894986606);c=ii(c,d,a,b,x[i+10],15,-1051523);b=ii(b,c,d,a,x[i+1],21,-2054922799);
	a=ii(a,b,c,d,x[i+8],6,1873313359);d=ii(d,a,b,c,x[i+15],10,-30611744);c=ii(c,d,a,b,x[i+6],15,-1560198380);b=ii(b,c,d,a,x[i+13],21,1309151649);
	a=ii(a,b,c,d,x[i+4],6,-145523070);d=ii(d,a,b,c,x[i+11],10,-1120210379);c=ii(c,d,a,b,x[i+2],15,718787259);b=ii(b,c,d,a,x[i+9],21,-343485551);
	a=ad(a,oa);b=ad(b,ob);c=ad(c,oc);d=ad(d,od)}
	return rh(a)+rh(b)+rh(c)+rh(d);
}

var TAB_N = 8, LOG_TAB = 7;
var SUBS = [], SUB_ACTIVE = "", subs_dirty = false;
function esc(s){ return String(s == null ? "" : s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function fmt_bytes(n){ n = +n || 0; var u = ["B","KB","MB","GB","TB","PB"], i = 0; while (n >= 1024 && i < u.length - 1){ n /= 1024; i++; } return (n >= 100 || i == 0 ? n.toFixed(0) : n.toFixed(1)) + " " + u[i]; }
function parse_subinfo(s){
	// upload=..;download=..;total=..;expire=..  或  left=120 GB;expire_date=2026-12-01
	var o = {}; String(s || "").split(";").forEach(function(kv){ var i = kv.indexOf("="); if (i > 0) o[kv.slice(0, i).trim().toLowerCase()] = kv.slice(i + 1).trim(); });
	var r = {};
	if (o.total){ r.used = (+o.upload || 0) + (+o.download || 0); r.total = +o.total || 0; }
	if (o.left) r.left = o.left;
	if (o.expire && +o.expire > 0){ var d = new Date(+o.expire * 1000); r.expire = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); r.days = Math.ceil((d - new Date()) / 864e5); }
	else if (o.expire_date){ r.expire = o.expire_date; r.days = Math.ceil((new Date(o.expire_date.replace(/-/g, "/")) - new Date()) / 864e5); }
	return r;
}
function subinfo_html(id){
	var r = parse_subinfo(db_mihomo["mihomo_subinfo_" + id]), t = db_mihomo["mihomo_subtime_" + id], h = [], bar = "";
	if (r.total){
		var pct = Math.min(100, Math.round(r.used / r.total * 100));
		h.push("已用 " + fmt_bytes(r.used) + " / " + fmt_bytes(r.total) + "（剩 " + fmt_bytes(Math.max(0, r.total - r.used)) + "）");
		bar = "<div class='sub-bar'><i class='" + (pct >= 90 ? "err" : pct >= 75 ? "warn" : "") + "' style='width:" + pct + "%'></i></div>";
	} else if (r.left) h.push("剩余 " + esc(r.left));
	if (r.expire) h.push((r.days != null && r.days < 0 ? "<span style='color:#f87171'>已过期 " : r.days != null && r.days <= 7 ? "<span style='color:#fbbf24'>" : "<span>") + "到期 " + esc(r.expire) + (r.days != null && r.days >= 0 ? "（" + r.days + " 天）" : "") + "</span>");
	if (t) h.push("<span style='color:var(--mut)'>更新于 " + esc(t) + "</span>");
	if (!h.length) h.push("<span style='color:var(--mut)'>还没有流量信息（更新一次订阅后显示；部分机场不提供）</span>");
	return "<div class='sub-meta'>" + h.join("") + "</div>" + bar;
}
function load_subs(){
	SUBS = [];
	b64d(db_mihomo["mihomo_subs"]).split(/\r?\n/).forEach(function(l){
		var i = l.indexOf("\t"); if (i < 0) return; var url = l.slice(i + 1).trim(); if (!url) return;
		SUBS.push({name: l.slice(0, i), url: url, id: md5(url).slice(0, 8)});
	});
	if (!SUBS.length && db_mihomo["mihomo_sub_url"]){ var u = b64d(db_mihomo["mihomo_sub_url"]); if (u) SUBS.push({name: "默认订阅", url: u, id: md5(u).slice(0, 8)}); }
	SUB_ACTIVE = db_mihomo["mihomo_sub_active"] || (SUBS[0] ? SUBS[0].id : "");
	if (SUBS.length && !SUBS.some(function(x){ return x.id == SUB_ACTIVE; })) SUB_ACTIVE = SUBS[0].id;
	subs_dirty = false;
}
function mask_url(u){ var m = String(u).match(/^(https?:\/\/[^\/?#]+)(.*)$/); return m ? m[1] + (m[2].length > 1 ? "/…" : "") : u; }
function render_subs(){
	var box = E("sub_list"); if (!box) return;
	if (!SUBS.length){ box.innerHTML = "<div class='sub-empty'>还没有订阅，在下面填写名称和地址后点「添加」</div>"; }
	else box.innerHTML = SUBS.map(function(x, i){
		var on = x.id == SUB_ACTIVE;
		return "<div class='sub-item" + (on ? " on" : "") + "'><input type='radio' name='sub_act' " + (on ? "checked" : "") + " onclick='sub_set_active(" + i + ")' title='设为当前订阅'/>" +
			"<div class='sub-main'><div class='sub-name'>" + esc(x.name) + (on ? "<span class='tag'>当前</span>" : "") + "</div><div class='sub-url' title='" + esc(x.url) + "'>" + esc(mask_url(x.url)) + "</div>" + subinfo_html(x.id) + "</div>" +
			"<div class='sub-ops'><input type='button' class='mh-btn sm' value='更新' onclick='sub_update(" + i + ")'/><input type='button' class='mh-btn sm danger' value='删除' onclick='sub_del(" + i + ")'/></div></div>";
	}).join("");
	E("sub_dirty").className = "dirty" + (subs_dirty ? " show" : "");
	var cur = SUBS.filter(function(x){ return x.id == SUB_ACTIVE; })[0], sm = E("sub_summary");
	if (sm) sm.innerHTML = cur ? "<b style='color:#fff'>" + esc(cur.name) + "</b>" + subinfo_html(cur.id) : "还没有订阅";
}
function sub_add(){
	var n = E("sub_new_name").value.replace(/[\t\r\n]/g, " ").trim(), u = E("sub_new_url").value.trim();
	if (!/^https?:\/\//.test(u)){ alert("请填写以 http:// 或 https:// 开头的订阅地址"); return; }
	var id = md5(u).slice(0, 8);
	if (SUBS.some(function(x){ return x.id == id; })){ alert("这个订阅地址已经添加过了"); return; }
	SUBS.push({name: n || ("订阅 " + (SUBS.length + 1)), url: u, id: id});
	if (!SUB_ACTIVE) SUB_ACTIVE = id;
	E("sub_new_name").value = ""; E("sub_new_url").value = "";
	subs_dirty = true; render_subs();
}
function sub_del(i){
	if (!confirm("删除订阅「" + SUBS[i].name + "」？")) return;
	var was = SUBS[i].id == SUB_ACTIVE; SUBS.splice(i, 1);
	if (was) SUB_ACTIVE = SUBS[0] ? SUBS[0].id : "";
	subs_dirty = true; render_subs();
}
function sub_set_active(i){ if (SUBS[i].id != SUB_ACTIVE){ SUB_ACTIVE = SUBS[i].id; subs_dirty = true; render_subs(); } }
function sub_update(i){
	if (subs_dirty){ alert("订阅列表有改动还没保存，请先点「保存并应用」"); return; }
	api_call("update_sub", {"mihomo_sub_target": SUBS[i].id});
}
function load_autoupd_status(){
	var el = E("autoupd_status"); if (!el) return;
	if (!db_mihomo["mihomo_update_url"]){ el.innerHTML = "填写发布地址并保存后，自动更新才会开始工作。"; return; }
	if (db_mihomo["mihomo_auto_update"] == "0"){ el.innerHTML = "自动更新已关闭。"; return; }
	$.ajax({ url: "/_temp/mihomo_autoupd.txt", dataType: "text", cache: false,
		success: function(t){ t = String(t || "").trim(); el.innerHTML = t ? "上次自动检查：" + esc(t) : "等待第一次自动检查（5 分钟内）"; },
		error: function(){ el.innerHTML = "等待第一次自动检查（5 分钟内）"; } });
}
function tg_test(){
	var d = collect();
	if (!d["mihomo_tg_token"] || !d["mihomo_tg_chat"]){ alert("请先填写 Bot Token 和 Chat ID"); return; }
	if (!/^\d+:[\w-]{20,}$/.test(d["mihomo_tg_token"])){ alert("Bot Token 格式不对，应该像 123456789:AAH... 这样"); return; }
	if (!/^-?\d+$/.test(d["mihomo_tg_chat"])){ alert("Chat ID 应该是一串数字（群组是 -100 开头）"); return; }
	if (!validate(d)) return;
	api_call("tg_test", d);
}
function plugin_action(a){
	var u = E("mihomo_update_url").value.trim();
	if (!/^https?:\/\//.test(u)){ alert("请先填写插件发布地址（http:// 或 https:// 开头）"); return; }
	api_call(a, {"mihomo_update_url": u});
}
var STORAGE_OK = false;
function kbtxt(k){ k = parseInt(k) || 0; return k >= 1048576 ? (k / 1048576).toFixed(1) + " GB" : k >= 1024 ? (k / 1024).toFixed(1) + " MB" : k + " KB"; }
function load_storage(){
	var sel = E("mihomo_data_dir"), info = E("storage_info"); if (!sel) return;
	var cur = STORAGE_OK ? sel.value : (db_mihomo["mihomo_data_dir"] || "");
	var id = parseInt(Math.random() * 100000000);
	info.innerHTML = "读取中…";
	$.ajax({ type: "POST", url: "/_api/", data: JSON.stringify({"id": id, "method": "mihomo_config.sh", "params": ["dump_storage"], "fields": {}}), dataType: "json",
		success: function(){ $.ajax({ url: "/_temp/mihomo_storage.txt", dataType: "text", cache: false, success: function(t){
			var lines = String(t || "").split("\n"), html = [], seen = false;
			while (sel.options.length > 1) sel.remove(1);
			lines.forEach(function(l){
				var a = l.trim().split(/\s+/);
				if (a[0] == "jffs") html.push("JFFS 剩余 <b>" + kbtxt(a[1]) + "</b> / 共 " + kbtxt(a[2]) + "，插件数据在 JFFS 上占 " + kbtxt(a[3]));
				else if (a[0] == "usb" && a[1]){
					var o = document.createElement("option"); o.value = a[1];
					o.text = "U 盘 " + a[1].replace("/tmp/mnt/", "") + "（剩余 " + kbtxt(a[2]) + "，" + (a[4] || "") + "）";
					sel.appendChild(o); if (a[1] == cur) seen = true;
				}
			});
			if (cur && !seen){ var o = document.createElement("option"); o.value = cur; o.text = "U 盘 " + cur.replace("/tmp/mnt/", "") + "（当前没有挂载）"; sel.appendChild(o); }
			sel.value = cur;
			if (sel.options.length < 2) html.push("没有检测到 U 盘：插上后点「刷新」");
			info.innerHTML = html.join("<br>"); STORAGE_OK = true;
		}, error: function(){ info.innerHTML = "读取失败"; } }); },
		error: function(){ info.innerHTML = "读取失败"; } });
}
function load_config(){
	var id = parseInt(Math.random() * 100000000);
	E("mihomo_cfg_view").value = "加载中…";
	$.ajax({ type: "POST", url: "/_api/", data: JSON.stringify({"id": id, "method": "mihomo_config.sh", "params": ["dump_config"], "fields": {}}), dataType: "json",
		success: function(){ $.ajax({ url: "/_temp/mihomo_config.txt", dataType: "text", cache: false, success: function(t){ E("mihomo_cfg_view").value = t; }, error: function(){ E("mihomo_cfg_view").value = "读取失败"; } }); },
		error: function(){ E("mihomo_cfg_view").value = "读取失败"; } });
}
function download_config(){
	var t = E("mihomo_cfg_view").value;
	if (!t || /^加载中|^读取失败/.test(t)){ alert("请先点「刷新」加载配置"); return; }
	try { var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([t], {type: "text/yaml"})); a.download = "mihomo_config.yaml"; document.body.appendChild(a); a.click(); setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 500); } catch(e){ alert("浏览器不支持下载，请手动复制"); }
}

function b64e(s){ try { return btoa(unescape(encodeURIComponent(s))); } catch(e){ return ""; } }
function b64d(s){ try { return s ? decodeURIComponent(escape(atob(s))) : ""; } catch(e){ return ""; } }


/* 快捷开关：卡片和下面各页的复选框是同一个设置 */
var QT_INIT = {};
function qt_render(){
	var any = false;
	[].forEach.call(document.querySelectorAll("#qgrid .qt"), function(t){
		var c = E(t.getAttribute("data-for")); if (!c) return;
		var id = c.id; if (!(id in QT_INIT)) QT_INIT[id] = c.checked;
		var dirty = QT_INIT[id] != c.checked; if (dirty) any = true;
		t.className = "qt" + (c.checked ? " on" : "") + (dirty ? " dirty" : "");
	});
	E("qnote").className = "qnote" + (any ? " show" : "");
	var sb = E("btn_save"); if (sb) sb.className = "mh-btn primary mh-hsave" + (any ? " pulse" : "");
}
function qt_reset(){ QT_INIT = {}; qt_render(); }
function qt_toggle(t){
	var c = E(t.getAttribute("data-for")); if (!c) return;
	c.checked = !c.checked;
	if (typeof c.onchange == "function") c.onchange();
	qt_render();
}
/* ===== 小组件布局（v2.0）：每个功能一张小卡片，点开在弹层里设置 ===== */
var MH_IC = {
	bot:'<rect x="4" y="7" width="16" height="12" rx="5"/><path d="M12 7V4"/><circle cx="12" cy="3" r="1"/><path d="M9 12v1M15 12v1"/>',
	link:'<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
	layers:'<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
	net:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
	shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9.5 9.5 5 5M14.5 9.5l-5 5"/>',
	devices:'<rect x="2" y="5" width="14" height="10" rx="2"/><path d="M6 19h6M9 15v4"/><rect x="17" y="9" width="5" height="10" rx="1.5"/>',
	list:'<path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01" stroke-width="3"/>',
	code:'<path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
	monitor:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
	clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
	disk:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 14h.01M11 14h6"/>',
	bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
	cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
	box:'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
	globe:'<circle cx="12" cy="12" r="9"/><path d="M3.6 9h16.8M3.6 15h16.8M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/>',
	file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
	term:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M13 15h4"/>',
	chev:'<path d="m9 6 6 6-6 6"/>', x:'<path d="M6 6l12 12M18 6 6 18"/>', refresh:'<path d="M20 11a8 8 0 0 0-14.6-4.5M4 4v4h4M4 13a8 8 0 0 0 14.6 4.5M20 20v-4h-4"/>'
};
function mh_svg(n, cls){ return '<svg class="i' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24">' + (MH_IC[n] || '') + '</svg>'; }
/* 每个弹层放哪些设置行（按行标题找） */
var MH_SHEETS = {
	bot:   {t:"值勤机器人", ic:"bot", c:"#6366f1", rows:[], open: function(){ bot_pane_render(); }},
	sub:   {t:"订阅", ic:"link", c:"#3b82f6", rows:["订阅列表","合并订阅","订阅 User-Agent","订阅自动更新"]},
	mode:  {t:"配置与 DNS", ic:"layers", c:"#8b5cf6", rows:["配置模式","当前订阅","自定义配置","DNS 模式","内核日志级别","Claude 助手","API Key","模型","API 地址"]},
	net:   {t:"网络", ic:"net", c:"#0ea5e9", rows:["UDP 透明代理","代理路由器自身","GitHub 走代理","IPv6 防泄漏","WebRTC 防泄漏","保留 fake-ip 记录","TUN 模式"]},
	ad:    {t:"去广告", ic:"shield", c:"#ef4444", rows:["屏蔽广告","去广告规则集","放行名单"], open: function(){ ad_trace_load(); }},
	dev:   {t:"设备", ic:"devices", c:"#14b8a6", rows:["访问控制","不走代理的设备","设备专用策略"]},
	rules: {t:"自定义规则", ic:"list", c:"#f59e0b", rows:["自定义规则"]},
	ov:    {t:"覆写", ic:"code", c:"#a855f7", rows:["覆写配置"]},
	panel: {t:"控制面板", ic:"monitor", c:"#06b6d4", rows:["面板端口","面板密钥"]},
	timer: {t:"定时", ic:"clock", c:"#f97316", rows:["开机启动延迟","定时重启"]},
	store: {t:"存储", ic:"disk", c:"#64748b", rows:["数据存放位置"], open:function(){ load_storage(); }},
	tg:    {t:"Telegram 通知", ic:"bell", c:"#229ed9", rows:["Telegram 通知","Bot Token","Chat ID","通知哪些事","API 地址","测试"]},
	core:  {t:"内核", ic:"cpu", c:"#22c55e", rows:["Mihomo 内核","内核版本通道"]},
	plugin:{t:"插件更新", ic:"box", c:"#ec4899", rows:["插件"], open:function(){ load_autoupd_status(); }},
	geo:   {t:"规则库", ic:"globe", c:"#10b981", rows:["规则库自动更新"]},
	cfg:   {t:"生成的配置", ic:"file", c:"#6366f1", rows:["生成的配置"], wide:1, open:function(){ if (!E("mihomo_cfg_view").value) load_config(); }},
	log:   {t:"运行日志", ic:"term", c:"#334155", node:"panel7", wide:1}
};
var MH_WIDGETS = [["sub",2],["mode",1],["net",1],["ad",1],["dev",1],["rules",1],["ov",1],["panel",1],["timer",1],["store",1],["tg",1],["core",1],["plugin",1],["geo",1],["cfg",1],["log",4]];
var MH_CUR_SHEET = "";
function mh_row_by_label(lb){
	var rows = document.querySelectorAll("#mh [id^=panel] .mh-row, #mh .sh-pane .mh-row");
	for (var i = 0; i < rows.length; i++){ var k = rows[i].querySelector(".k"); if (k && k.firstChild && String(k.firstChild.textContent).trim() == lb) return rows[i]; }
	return null;
}
function mh_build_widgets(){
	var dash = E("mh_dash"); if (!dash || dash.getAttribute("data-built")) return;
	dash.setAttribute("data-built", "1");
	/* 快捷开关挪到最上面，多加两个 */
	var q = E("qgrid"), qn = E("qnote");
	var extra = [["mihomo_github_proxy","net","GitHub 走代理","GitHub 固定走第一个策略组"],["mihomo_tg_enable","bell","TG 通知","异常、到期推送到 Telegram"]];
	extra.forEach(function(x){ var d = document.createElement("div"); d.className = "qt"; d.setAttribute("data-for", x[0]); d.setAttribute("onclick", "qt_toggle(this)"); d.innerHTML = '<span class="qs"></span><div class="qi">' + mh_svg(x[1]) + '</div><b>' + x[2] + '</b><span>' + x[3] + '</span>'; q.appendChild(d); var c = E(x[0]); if (c) c.addEventListener("change", qt_render); });
	var sec1 = document.createElement("div"); sec1.className = "mh-sec"; sec1.innerHTML = '<div class="mh-sect">快捷开关</div>';
	sec1.appendChild(q); if (qn) sec1.appendChild(qn); dash.appendChild(sec1);
	/* 小组件 */
	var sec2 = document.createElement("div"); sec2.className = "mh-sec"; sec2.innerHTML = '<div class="mh-sect">功能</div>';
	var g = document.createElement("div"); g.className = "wg-grid"; g.id = "wg_grid";
	MH_WIDGETS.forEach(function(w){
		var s = MH_SHEETS[w[0]], el = document.createElement("div");
		el.className = "wg" + (w[1] > 1 ? " s" + w[1] : ""); el.id = "wg_" + w[0]; el.setAttribute("data-k", w[0]);
		el.innerHTML = '<div class="wg-h"><span class="wg-ic" style="background:' + s.c + '">' + mh_svg(s.ic) + '</span><b>' + s.t + '</b>' + mh_svg("chev", "wg-chev") + '</div><div class="wg-v" id="wgv_' + w[0] + '">—</div><div class="wg-s" id="wgs_' + w[0] + '"></div><div class="wg-x" id="wgx_' + w[0] + '"></div>';
		el.onclick = function(e){ if (e.target.closest && e.target.closest(".wg-act")) return; mh_sheet_open(w[0]); };
		g.appendChild(el);
	});
	sec2.appendChild(g); dash.appendChild(sec2);
	/* 弹层 */
	var ov = document.createElement("div"); ov.className = "sh-ov"; ov.id = "sh_ov";
	ov.innerHTML = '<div class="sh"><div class="sh-head"><span class="wg-ic" id="sh_ic"></span><b id="sh_title"></b><button type="button" class="mh-ibtn sh-x" onclick="mh_sheet_close()" aria-label="关闭">' + mh_svg("x") + '</button></div><div class="sh-body" id="sh_body"></div><div class="sh-foot"><span id="sh_hint">改动会在开关上标「未保存」，点「保存并应用」生效</span><button type="button" class="sh-done" onclick="mh_sheet_close()">完成</button><button type="button" class="mh-btn primary" id="sh_save" onclick="mh_sheet_close();save()">保存并应用</button></div></div>';
	ov.onclick = function(e){ if (e.target === ov) mh_sheet_close(); };
	E("mh").appendChild(ov);
	var body = E("sh_body");
	for (var k in MH_SHEETS){
		var s = MH_SHEETS[k], pane = document.createElement("div");
		pane.className = "sh-pane" + (k == "log" ? "" : " mh-card"); pane.id = "pane_" + k; pane.style.display = "none";
		if (s.node){ var n = E(s.node); if (n){ while (n.firstChild) pane.appendChild(n.firstChild); } }
		if (k == "bot") pane.innerHTML = '<div class="bp-top"><div class="bp-sum" id="bp_sum">—</div><button type="button" class="mh-btn sm" onclick="bot_check(true)">重新巡检</button></div><div class="bp-list" id="bp_list"></div><button type="button" class="bp-more" id="bp_more" onclick="BOT.all=!BOT.all;bot_pane_render()"></button><div class="bp-chat"><div class="bp-ct">和机器人聊聊 <span class="bp-mode" id="bp_mode"></span></div><div class="bp-msgs" id="bp_msgs"></div><div class="bp-sugs" id="bp_sugs"></div><form class="bp-in" onsubmit="bot_send();return false;"><input type="text" id="bp_q" class="mh-input" autocomplete="off" placeholder="问我点什么，比如：为什么网页打不开？"/><button type="submit" class="mh-btn primary sm">发送</button></form></div>';
		if (k == "geo") pane.innerHTML = '<div class="mh-row"><div class="k">GeoSite / GeoIP<small>域名、IP 归属数据库</small></div><div class="v"><div class="kv2"><span>上次更新</span><b id="geo_time_v">—</b></div><div class="row-btns"><input type="button" class="mh-btn sm" value="立即更新" onclick="mh_sheet_close();update_geo()"/></div><span class="mh-tip">规则里的 GEOSITE / GEOIP 靠它判断网站和 IP 属于哪里。更新后直接生效，不中断连接。</span></div></div>';
		(s.rows || []).forEach(function(lb){ var r = mh_row_by_label(lb); if (r) pane.appendChild(r); });
		body.appendChild(pane);
	}
	/* 原来的标签栏和面板不再显示 */
	document.querySelectorAll("#mh .mh-tabs, #mh [id^=panel]").forEach(function(x){ x.style.display = "none"; x.classList.add("mh-gone"); });
	/* 卡片上的快捷操作 */
	["sub","geo","core","plugin"].forEach(function(k){ E("wg_" + k).className += " has-x"; });
	E("wgx_sub").innerHTML = '<span class="wg-act" onclick="update_sub()">' + mh_svg("refresh") + '更新</span>';
	E("wgx_geo").innerHTML = '<span class="wg-act" onclick="update_geo()">' + mh_svg("refresh") + '更新</span>';
	E("wgx_core").innerHTML = '<span class="wg-act" onclick="api_call(\'check_core\',{})">检查</span>';
	E("wgx_plugin").innerHTML = '<span class="wg-act" onclick="plugin_action(\'check_plugin\')">检查</span>';
	E("mh").addEventListener("input", mh_refresh_widgets_soon);
	E("mh").addEventListener("change", mh_refresh_widgets_soon);
	document.addEventListener("keydown", function(e){ if (e.key == "Escape") mh_sheet_close(); });
}
function mh_sheet_open(k){
	var s = MH_SHEETS[k]; if (!s) return;
	for (var x in MH_SHEETS){ var p = E("pane_" + x); if (p) p.style.display = (x == k) ? "" : "none"; }
	E("sh_title").textContent = s.t; E("sh_ic").innerHTML = mh_svg(s.ic); E("sh_ic").style.background = s.c;
	var ov = E("sh_ov"); ov.className = "sh-ov open" + (s.wide ? " wide" : "");
	E("sh_save").style.display = (k == "log" || k == "cfg" || k == "bot") ? "none" : "";
	E("sh_hint").style.display = E("sh_save").style.display;
	MH_CUR_SHEET = k;
	if (s.open) setTimeout(s.open, 0);
	if (k == "log"){ var l = E("mihomo_log"); if (l) l.scrollTop = l.scrollHeight; }
}
function mh_sheet_close(){ var ov = E("sh_ov"); if (ov) ov.className = "sh-ov"; MH_CUR_SHEET = ""; mh_refresh_widgets(); }
var _mh_rt = 0;
function mh_refresh_widgets_soon(){ clearTimeout(_mh_rt); _mh_rt = setTimeout(mh_refresh_widgets, 120); }
function mh_lines(id){ var e = E(id); return e ? e.value.split(/\r?\n/).filter(function(l){ l = l.trim(); return l && l.charAt(0) != "#"; }).length : 0; }
function mh_set(k, v, s){ var a = E("wgv_" + k), b = E("wgs_" + k); if (a) a.innerHTML = v; if (b) b.innerHTML = s || ""; }
function mh_opt(id){ var e = E(id); if (!e || e.selectedIndex < 0) return ""; return e.options[e.selectedIndex].text; }
function mh_dot(on, t){ return '<span class="wdot' + (on ? ' on' : '') + '"></span>' + t; }
function mh_refresh_widgets(){
	if (!E("wg_grid")) return;
	var on = function(id){ var e = E(id); return e && e.checked; };
	/* 订阅 */
	var act = null; SUBS.forEach(function(x){ if (x.id == SUB_ACTIVE) act = x; });
	var mode = E("mihomo_cfg_mode") ? E("mihomo_cfg_mode").value : "sub";
	if (mode == "custom") mh_set("sub", "自定义配置", "当前用的是你粘贴的 YAML，不读订阅");
	else if (!act) mh_set("sub", "还没有订阅", "点这里添加机场订阅地址");
	else {
		var r = parse_subinfo(db_mihomo["mihomo_subinfo_" + act.id]), sub = [], bar = "";
		if (r.total){ var pct = Math.min(100, Math.round(r.used / r.total * 100)); sub.push("已用 " + fmt_bytes(r.used) + " / " + fmt_bytes(r.total)); bar = '<div class="wg-bar"><i class="' + (pct >= 90 ? "err" : pct >= 75 ? "warn" : "") + '" style="width:' + Math.max(2, pct) + '%"></i></div>'; }
		if (r.days != null) sub.push(r.days < 0 ? '<span class="werr">已过期</span>' : (r.days <= 7 ? '<span class="wwarn">剩 ' + r.days + ' 天</span>' : "剩 " + r.days + " 天"));
		sub.push(SUBS.length + " 个订阅" + (subs_dirty ? ' · <span class="wwarn">未保存</span>' : ""));
		mh_set("sub", esc(act.name), sub.join(" · ") + bar);
	}
	/* 配置与 DNS */
	mh_set("mode", esc(mh_opt("mihomo_cfg_mode").replace(/（.*$/, "")), "DNS " + esc(E("mihomo_dns_mode") ? E("mihomo_dns_mode").value : "") + " · 日志 " + esc(E("mihomo_log_level") ? E("mihomo_log_level").value : "") + (on("mihomo_ai_enable") ? " · Claude 已接入" : ""));
	/* 网络 */
	mh_set("net", on("mihomo_tun") ? "TUN 模式" + (MH_RUN && !MH_TUN ? ' <span class="wwarn">未生效</span>' : "") : (on("mihomo_udp") ? "TCP + UDP" : "仅 TCP"), mh_dot(on("mihomo_ipv6_block"), "IPv6 防泄漏") + " " + mh_dot(E("mihomo_webrtc").value != "off", "WebRTC") + " " + mh_dot(on("mihomo_router_proxy"), "路由器自身") + " " + mh_dot(on("mihomo_github_proxy"), "GitHub"));
	/* 去广告 */
	var nads = document.querySelectorAll("#mh input[id^=adr_]:checked").length + (E("adr_heidai") && E("adr_heidai").value ? 1 : 0);
	mh_set("ad", on("mihomo_adblock") || nads ? "已开启" : "未开启", (on("mihomo_adblock") ? "内置规则" : "内置规则关") + " · " + nads + " 个规则集" + (mh_lines("mihomo_ad_allow") ? " · 放行 " + mh_lines("mihomo_ad_allow") : ""));
	/* 设备 */
	var acl = E("mihomo_acl_mode") ? E("mihomo_acl_mode").value : "all";
	mh_set("dev", acl == "only" ? "只代理名单设备" : "全部设备", "名单 " + (E("mihomo_proxy_ip") ? E("mihomo_proxy_ip").value.split(/[\s,]+/).filter(Boolean).length : 0) + " · 不代理 " + mh_lines("mihomo_bypass_ip") + " · 专用策略 " + mh_lines("mihomo_dev_rules"));
	/* 规则 / 覆写 */
	var nr = mh_lines("mihomo_rules"); mh_set("rules", nr ? nr + " 条" : "未使用", nr ? "放在所有规则最前面" : "比如让某个网站直连或走指定分组");
	var no = mh_lines("mihomo_overlay"); mh_set("ov", no ? no + " 行" : "未使用", no ? "混入订阅：分组、规则、hosts 等" : "不改订阅也能加分组和规则");
	/* 控制面板 */
	var sec = E("mihomo_secret") ? E("mihomo_secret").value : "";
	mh_set("panel", ":" + esc(E("mihomo_ui_port") ? E("mihomo_ui_port").value || "9090" : "9090"), sec ? "密钥 ••••" + esc(sec.slice(-4)) : '<span class="wwarn">没有密钥</span>');
	/* 定时 */
	var rh = E("mihomo_restart_hour") ? E("mihomo_restart_hour").value : "", bd = E("mihomo_boot_delay") ? E("mihomo_boot_delay").value : "0", si = mh_opt("mihomo_sub_interval");
	mh_set("timer", rh !== "" ? "每天 " + rh + ":35 重启" : "不定时重启", "开机延迟 " + (bd || 0) + " 秒 · 订阅 " + esc(si || "不自动更新"));
	/* 存储 */
	var dd = E("mihomo_data_dir") ? E("mihomo_data_dir").value : "", si2 = E("storage_info") ? E("storage_info").textContent : "";
	var jf = si2.match(/JFFS 剩余 ([0-9.]+ [KMG]B)/);
	mh_set("store", dd ? "U 盘 " + esc(dd.replace("/tmp/mnt/", "")) : "路由器 JFFS", jf ? "JFFS 剩 " + jf[1] : "点开查看剩余空间");
	/* 通知 */
	var tgc = E("mihomo_tg_chat") ? E("mihomo_tg_chat").value : "";
	mh_set("tg", on("mihomo_tg_enable") ? (tgc ? "已开启" : '<span class="wwarn">缺 Chat ID</span>') : "未开启", on("mihomo_tg_enable") ? document.querySelectorAll("#tg_evs input:checked").length + " 类事件" : "异常、到期推送到手机");
	/* 内核 / 插件 / 规则库 / 配置 */
	var cc = E("upd_core_cur") ? E("upd_core_cur").textContent : "", cn = E("upd_core_new") ? E("upd_core_new").textContent : "";
	var cv = cc && cc != "-" ? cc : (db_mihomo["mihomo_core_version"] || (E("core_version") ? E("core_version").textContent.replace(/^内核\s*/, "") : "") || "—");
	var alpha = E("mihomo_core_channel") && E("mihomo_core_channel").value == "alpha";
	mh_set("core", esc(cv), (alpha ? '<span class="wwarn">Alpha 通道</span> · ' : "正式版通道 · ") + (/^(v|alpha-)/.test(cn) && cn != cc ? '<span class="wok">可更新 ' + esc(cn) + '</span>' : "点「检查」看新版本"));
	mh_set("plugin", "v" + esc(db_mihomo["mihomo_version"] || ""), mh_dot(on("mihomo_auto_update"), on("mihomo_auto_update") ? "每 5 分钟自动更新" : "自动更新已关"));
	var gt = db_mihomo["mihomo_geo_time"] || ""; if (E("geo_time_v")) E("geo_time_v").textContent = gt || "还没更新过";
	mh_set("geo", gt ? esc(gt.slice(5)) : "未更新", mh_dot(on("mihomo_geo_auto"), on("mihomo_geo_auto") ? "每周自动更新" : "自动更新已关"));
	mh_set("cfg", "查看", "插件实际交给内核的配置");
	/* 日志：最后 3 行 */
	var lg = E("mihomo_log") ? E("mihomo_log").value.replace(/\s+$/, "").split("\n").slice(-3) : [];
	mh_set("log", lg.length && lg[0] ? '<div class="wg-log">' + lg.map(function(l){ return "<div>" + esc(l.replace(/^\d{4}-\d\d-\d\d /, "")) + "</div>"; }).join("") + "</div>" : '<span class="wmut">还没有日志</span>', "");
	if (E("note_ui_port") && E("mihomo_ui_port")) E("note_ui_port").textContent = E("mihomo_ui_port").value || "9090";
}

/* 接到原有流程上 */
var _mh_switch_tab = switch_tab;
switch_tab = function(n){
	if (!E("wg_grid")) return _mh_switch_tab(n);
	if (n == LOG_TAB) mh_sheet_open("log"); else if (n == 6) mh_sheet_open("cfg"); else if (n == 8) mh_sheet_open("tg");
};
var _mh_conf2obj = conf2obj;
conf2obj = function(){ _mh_conf2obj(); mh_refresh_widgets_soon(); };
setInterval(function(){ if (E("wg_grid") && !MH_CUR_SHEET) mh_refresh_widgets(); }, 2000);
function init(){
	mh_apply_theme();
	show_menu(menu_hook);
	get_dbus_data();
	get_status();
	status_timer = setInterval(get_status, 5000);
	start_ping();
	[].forEach.call(document.querySelectorAll("#qgrid .qt"), function(t){ var c = E(t.getAttribute("data-for")); if (c) c.addEventListener("change", qt_render); });
	mh_build_widgets();
	qt_reset();
	mh_refresh_widgets();
}


/* ===== GitHub / YouTube / 百度 延迟心跳（在浏览器里测，走本设备真实线路） ===== */
var PING_SITES = {
	github:  "https://github.com/favicon.ico",
	youtube: "https://www.youtube.com/generate_204",
	baidu:   "https://www.baidu.com/favicon.ico"
};
var ping_timer = null, ping_busy = {};
function ping_one(site){
	if (ping_busy[site] || !window.fetch) return;
	var el = document.querySelector('#mh_ping .mh-pill[data-site="' + site + '"]');
	if (!el) return;
	ping_busy[site] = true;
	el.className = el.className.replace(/\s*(beat|testing)/g, "") + " testing";
	var ctl = window.AbortController ? new AbortController() : null;
	var to = setTimeout(function(){ if (ctl) try { ctl.abort(); } catch(e){} }, 5000);
	var t0 = (window.performance && performance.now) ? performance.now() : Date.now();
	var opt = {mode: "no-cors", cache: "no-store", credentials: "omit"};
	if (ctl) opt.signal = ctl.signal;
	var fired = false;
	var done = function(ok){
		if (fired) return; fired = true;
		clearTimeout(to);
		var ms = Math.round(((window.performance && performance.now) ? performance.now() : Date.now()) - t0);
		if (ok && ms >= 5000) ok = false;
		var cls = !ok ? "bad" : (ms < 300 ? "good" : (ms < 800 ? "mid" : "bad"));
		el.querySelector("b").innerHTML = ok ? (ms + " ms") : "超时";
		el.className = "mh-pill " + cls;
		void el.offsetWidth; el.className = "mh-pill " + cls + " beat";
		ping_busy[site] = false;
	};
	var u = PING_SITES[site] + (PING_SITES[site].indexOf("?") > -1 ? "&" : "?") + "_=" + Date.now();
	/* 图片探测和 fetch 同时发，先收到响应的算数（手机 Safari 上 no-cors fetch 可能一直挂起） */
	var img = new Image(); img.onload = img.onerror = function(){ img.onload = img.onerror = null; done(true); }; img.src = u;
	fetch(u, opt).then(function(){ done(true); }, function(){});
	setTimeout(function(){ done(false); }, 5200);
}
function ping_all(){
	if (document.hidden) return;
	for (var k in PING_SITES) ping_one(k);
}
function start_ping(){
	ping_all();
	if (ping_timer) clearInterval(ping_timer);
	ping_timer = setInterval(ping_all, 5000);
	var box = E("mh_ping");
	if (box) box.onclick = function(e){ e.preventDefault(); e.stopPropagation(); ping_all(); };
	document.addEventListener("visibilitychange", function(){ if (!document.hidden) ping_all(); });
}

function menu_hook(){
	tabtitle[tabtitle.length - 1] = new Array("", "Mihomo");
	tablink[tablink.length - 1] = new Array("", "Module_mihomo.asp");
}

function reload_Soft_Center(){ location.href = "/Module_Softcenter.asp"; }

function get_dbus_data(){
	$.ajax({
		type: "GET",
		url: "/_api/mihomo_",
		dataType: "json",
		async: false,
		success: function(data){
			db_mihomo = data.result[0] || {};
			conf2obj();
		}
	});
}

function conf2obj(){
	E("mihomo_tg_enable").checked = db_mihomo["mihomo_tg_enable"] == "1";
	E("mihomo_tg_token").value = db_mihomo["mihomo_tg_token"] || "";
	E("mihomo_tg_chat").value = db_mihomo["mihomo_tg_chat"] || "";
	E("mihomo_tg_api").value = db_mihomo["mihomo_tg_api"] || "";
	var evs = db_mihomo["mihomo_tg_ev"];
	[].forEach.call(document.querySelectorAll("#tg_evs input"), function(c){
		var list = (evs == null || evs === "") ? "fail,boot,sub,traffic,update" : evs;
		c.checked = ("," + list + ",").indexOf("," + c.getAttribute("data-ev") + ",") > -1;
	});
	E("mihomo_enable").checked = db_mihomo["mihomo_enable"] == "1";
	E("mihomo_cfg_mode").value = db_mihomo["mihomo_cfg_mode"] || "sub";
	E("mihomo_dns_mode").value = db_mihomo["mihomo_dns_mode"] || "fake-ip";
	E("mihomo_udp").checked = db_mihomo["mihomo_udp"] == "1";
	E("mihomo_adblock").checked = db_mihomo["mihomo_adblock"] == "1";
	E("mihomo_router_proxy").checked = db_mihomo["mihomo_router_proxy"] == "1";
	E("mihomo_github_proxy").checked = db_mihomo["mihomo_github_proxy"] != "0";
	E("mihomo_store_fakeip").checked = db_mihomo["mihomo_store_fakeip"] != "0";
	E("mihomo_ai_enable").checked = db_mihomo["mihomo_ai_enable"] == "1";
	E("mihomo_ai_key").value = db_mihomo["mihomo_ai_key"] || "";
	E("mihomo_ai_model").value = /^claude-/.test(db_mihomo["mihomo_ai_model"] || "") ? db_mihomo["mihomo_ai_model"] : "claude-haiku-5-5";
	if (E("mihomo_ai_model").selectedIndex < 0) E("mihomo_ai_model").value = "claude-haiku-5-5";
	E("mihomo_ai_base").value = db_mihomo["mihomo_ai_base"] || "";
	ai_toggle();
	E("mihomo_webrtc").value = /^(proxy|block|off)$/.test(db_mihomo["mihomo_webrtc"] || "") ? db_mihomo["mihomo_webrtc"] : "proxy";
	E("mihomo_tun").checked = db_mihomo["mihomo_tun"] == "1";
	E("mihomo_geo_auto").checked = db_mihomo["mihomo_geo_auto"] != "0";
	E("mihomo_core_channel").value = db_mihomo["mihomo_core_channel"] == "alpha" ? "alpha" : "stable";
	E("mihomo_sub_ua").value = db_mihomo["mihomo_sub_ua"] || "clash.meta";
	E("mihomo_sub_interval").value = db_mihomo["mihomo_sub_interval"] || "0";
	E("mihomo_ui_port").value = db_mihomo["mihomo_ui_port"] || "9090";
	E("mihomo_secret").value = db_mihomo["mihomo_secret"] || "";
	E("mihomo_log_level").value = db_mihomo["mihomo_log_level"] || "warning";
	E("mihomo_bypass_ip").value = (db_mihomo["mihomo_bypass_ip"] || "").replace(/,/g, "\n");
	E("mihomo_rules").value = b64d(db_mihomo["mihomo_rules"]);
	E("mihomo_ad_allow").value = b64d(db_mihomo["mihomo_ad_allow"]);
	E("mihomo_version_show").innerHTML = "插件 v" + (db_mihomo["mihomo_version"] || "-");
	if (E("note_ui_port")) E("note_ui_port").innerHTML = db_mihomo["mihomo_ui_port"] || "9090";
	E("mihomo_sub_merge").checked = db_mihomo["mihomo_sub_merge"] == "1";
	var adr = "," + (db_mihomo["mihomo_adrules"] || "") + ",";
	E("adr_awavenue").checked = adr.indexOf(",awavenue,") > -1;
	E("adr_heidai").value = adr.indexOf(",heidai,") > -1 ? "heidai" : adr.indexOf(",heidai_lite,") > -1 ? "heidai_lite" : "";
	E("adr_adguard").checked = adr.indexOf(",adguard,") > -1;
	E("mihomo_adg_url").value = db_mihomo["mihomo_adg_url"] || "";
	adg_toggle();
	E("mihomo_overlay").value = b64d(db_mihomo["mihomo_overlay"]);
	E("mihomo_acl_mode").value = db_mihomo["mihomo_acl_mode"] || "all";
	E("mihomo_proxy_ip").value = (db_mihomo["mihomo_proxy_ip"] || "").replace(/,/g, "\n");
	E("mihomo_dev_rules").value = b64d(db_mihomo["mihomo_dev_rules"]);
	E("mihomo_ipv6_block").checked = db_mihomo["mihomo_ipv6_block"] != "0";
	E("mihomo_boot_delay").value = db_mihomo["mihomo_boot_delay"] || "0";
	var rh = E("mihomo_restart_hour"); if (rh.options.length < 2) for (var h = 0; h < 24; h++){ var o = document.createElement("option"); o.value = h; o.text = "每天 " + h + ":35"; rh.appendChild(o); }
	rh.value = db_mihomo["mihomo_restart_hour"] || "";
	E("mihomo_update_url").value = db_mihomo["mihomo_update_url"] || "";
	E("mihomo_auto_update").checked = db_mihomo["mihomo_auto_update"] != "0";
	load_autoupd_status();
	load_storage();
	E("upd_plugin_cur").innerHTML = "v" + (db_mihomo["mihomo_version"] || "-");
	E("upd_plugin_new").innerHTML = db_mihomo["mihomo_plugin_latest"] ? "v" + esc(db_mihomo["mihomo_plugin_latest"]) : "未检查";
	E("upd_core_cur").innerHTML = esc(db_mihomo["mihomo_core_version"] || "-");
	E("upd_core_new").innerHTML = esc(db_mihomo["mihomo_core_latest"] || "未检查");
	load_subs(); render_subs();
	update_visibility();
	if (E("mihomo_cfg_mode").value == "custom") load_custom();
}

function update_visibility(){
	var m = E("mihomo_cfg_mode").value;
	E("tr_sub_summary").style.display = (m == "custom") ? "none" : "";
	E("tr_sub_interval").style.display = (m == "sub") ? "" : "none";
	E("tr_sub_merge").style.display = (m == "provider") ? "" : "none";
	E("tr_proxy_ip").style.display = (E("mihomo_acl_mode").value == "only") ? "" : "none";
	E("tr_custom").style.display = (m == "custom") ? "" : "none";
	if (E("btn_update_sub")) E("btn_update_sub").style.display = (m == "custom") ? "none" : "";
	var tip = {
		"sub": "下载机场的 Clash/Mihomo 完整配置（含其分组与规则）。端口/DNS/面板等由插件接管。",
		"provider": "仅从订阅获取节点（支持 Clash YAML、base64、ss/vmess/vless/trojan/hy2 链接），使用插件内置的国内直连 + 国外代理规则。",
		"custom": "粘贴您自己编写的完整 Mihomo 配置。端口/DNS/面板等仍由插件接管。"
	};
	E("mode_tip").innerHTML = tip[m] || "";
}

var custom_loaded = false;
function load_custom(){
	if (custom_loaded) return;
	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "mihomo_config.sh", "params": ["dump_custom"], "fields": {}};
	$.ajax({
		type: "POST", url: "/_api/", data: JSON.stringify(postData), dataType: "json",
		success: function(){
			$.ajax({ url: "/_temp/mihomo_custom.txt", dataType: "text", cache: false,
				success: function(t){ E("mihomo_custom").value = t; custom_loaded = true; } });
		}
	});
}

function switch_tab(n){
	if (n == 6 && E("mihomo_cfg_view") && !E("mihomo_cfg_view").value) setTimeout(load_config, 0);
	if (n == 5) setTimeout(load_autoupd_status, 0);
	for (var i = 1; i <= TAB_N; i++){
		E("tab" + i).className = (i == n) ? "active" : "";
		E("panel" + i).style.display = (i == n) ? "" : "none";
	}
}

function collect(){
	var d = {};
	d["mihomo_tg_enable"] = E("mihomo_tg_enable").checked ? "1" : "0";
	d["mihomo_tg_token"] = E("mihomo_tg_token").value.trim();
	d["mihomo_tg_chat"] = E("mihomo_tg_chat").value.trim();
	d["mihomo_tg_api"] = E("mihomo_tg_api").value.trim();
	var ev = []; [].forEach.call(document.querySelectorAll("#tg_evs input"), function(c){ if (c.checked) ev.push(c.getAttribute("data-ev")); });
	d["mihomo_tg_ev"] = ev.join(",") || "none";
	d["mihomo_enable"] = E("mihomo_enable").checked ? "1" : "0";
	d["mihomo_cfg_mode"] = E("mihomo_cfg_mode").value;
	d["mihomo_dns_mode"] = E("mihomo_dns_mode").value;
	d["mihomo_udp"] = E("mihomo_udp").checked ? "1" : "0";
	d["mihomo_adblock"] = E("mihomo_adblock").checked ? "1" : "0";
	d["mihomo_router_proxy"] = E("mihomo_router_proxy").checked ? "1" : "0";
	d["mihomo_github_proxy"] = E("mihomo_github_proxy").checked ? "1" : "0";
	d["mihomo_store_fakeip"] = E("mihomo_store_fakeip").checked ? "1" : "0";
	d["mihomo_ai_enable"] = E("mihomo_ai_enable").checked ? "1" : "0";
	d["mihomo_ai_key"] = E("mihomo_ai_key").value.trim();
	d["mihomo_ai_model"] = E("mihomo_ai_model").value;
	d["mihomo_ai_base"] = E("mihomo_ai_base").value.trim().replace(/\/+$/, "");
	d["mihomo_webrtc"] = E("mihomo_webrtc").value;
	d["mihomo_tun"] = E("mihomo_tun").checked ? "1" : "0";
	d["mihomo_geo_auto"] = E("mihomo_geo_auto").checked ? "1" : "0";
	d["mihomo_core_channel"] = E("mihomo_core_channel").value;
	d["mihomo_subs"] = b64e(SUBS.map(function(x){ return x.name + "\t" + x.url; }).join("\n"));
	d["mihomo_sub_active"] = SUB_ACTIVE;
	d["mihomo_sub_merge"] = E("mihomo_sub_merge").checked ? "1" : "0";
	d["mihomo_adrules"] = [E("adr_awavenue").checked ? "awavenue" : "", E("adr_heidai").value, E("adr_adguard").checked ? "adguard" : ""].filter(function(x){ return x; }).join(",");
	d["mihomo_adg_url"] = E("mihomo_adg_url").value.trim();
	d["mihomo_overlay"] = b64e(E("mihomo_overlay").value.replace(/\t/g, "  "));
	d["mihomo_acl_mode"] = E("mihomo_acl_mode").value;
	d["mihomo_proxy_ip"] = E("mihomo_proxy_ip").value.split(/[\s,;]+/).filter(function(x){ return x; }).join(",");
	d["mihomo_dev_rules"] = b64e(E("mihomo_dev_rules").value);
	d["mihomo_ipv6_block"] = E("mihomo_ipv6_block").checked ? "1" : "0";
	d["mihomo_boot_delay"] = String(Math.max(0, Math.min(600, parseInt(E("mihomo_boot_delay").value) || 0)));
	d["mihomo_restart_hour"] = E("mihomo_restart_hour").value;
	d["mihomo_data_dir"] = STORAGE_OK ? E("mihomo_data_dir").value : (db_mihomo["mihomo_data_dir"] || "");
	d["mihomo_update_url"] = E("mihomo_update_url").value.trim();
	d["mihomo_auto_update"] = E("mihomo_auto_update").checked ? "1" : "0";
	d["mihomo_sub_ua"] = E("mihomo_sub_ua").value.replace(/^\s+|\s+$/g, "") || "clash.meta";
	d["mihomo_sub_interval"] = E("mihomo_sub_interval").value;
	d["mihomo_ui_port"] = E("mihomo_ui_port").value;
	d["mihomo_secret"] = E("mihomo_secret").value.replace(/["\\\s]/g, "");
	d["mihomo_log_level"] = E("mihomo_log_level").value;
	d["mihomo_bypass_ip"] = E("mihomo_bypass_ip").value.split(/[\s,;]+/).filter(function(x){ return x; }).join(",");
	d["mihomo_rules"] = b64e(E("mihomo_rules").value);
	d["mihomo_ad_allow"] = b64e(E("mihomo_ad_allow").value);
	if (d["mihomo_cfg_mode"] == "custom" && custom_loaded) d["mihomo_custom_b64"] = b64e(E("mihomo_custom").value);
	return d;
}

function validate(d){
	if (d["mihomo_enable"] == "1" && d["mihomo_cfg_mode"] != "custom" && !SUBS.length){
		alert("还没有订阅：请到「订阅」页添加至少一个订阅地址！"); switch_tab(2); return false;
	}
	if (d["mihomo_acl_mode"] == "only" && !d["mihomo_proxy_ip"]){
		alert("选了「只代理指定设备」，但还没有填设备 IP！"); switch_tab(4); return false;
	}
	if (d["mihomo_enable"] == "1" && d["mihomo_cfg_mode"] == "custom" && !E("mihomo_custom").value.match(/(^|\n)(proxies|proxy-providers):/)){
		alert("自定义配置中没有 proxies 或 proxy-providers！"); return false;
	}
	var p = parseInt(d["mihomo_ui_port"]);
	if (!(p > 1024 && p < 65535) || [7890, 7892, 7893, 23453].indexOf(p) >= 0){
		alert("面板端口无效（1025-65534，且不能与 7890/7892/7893/23453 冲突）"); return false;
	}
	return true;
}

function api_call(action, fields){
	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "mihomo_config.sh", "params": [action], "fields": fields || {}};
	E("mihomo_log").value = "";
	_responseLen = 0; noChange = 0;
	showLoadingBar();
	$.ajax({
		type: "POST", url: "/_api/", data: JSON.stringify(postData), dataType: "json",
		success: function(resp){ setTimeout(get_log, 500); },
		error: function(){ hideLoadingBar(); alert("提交失败，请刷新页面重试"); }
	});
}

function save(){
	var d = collect();
	if (!validate(d)) return;
	api_call("restart", d);
}

function update_sub(){
	if (subs_dirty){ alert("订阅列表有改动还没保存，请先点「保存并应用」"); return; }
	var d = collect();
	if (!validate(d)) return;
	api_call("update_sub", d);
}

function update_geo(){ api_call("update_geo", {}); }
function ad_allow_has(d){
	return E("mihomo_ad_allow").value.split(/\r?\n/).some(function(l){ l = l.trim().replace(/^[*+]?\./, "").toLowerCase(); return l && (d == l || d.slice(-(l.length + 1)) == "." + l); });
}
function ad_allow_add(d){
	if (ad_allow_has(d)) return;
	var t = E("mihomo_ad_allow"), v = t.value.replace(/\s+$/, "");
	t.value = (v ? v + "\n" : "") + d;
	t.dispatchEvent(new Event("input", {bubbles: true})); t.dispatchEvent(new Event("change", {bubbles: true}));
	ad_trace_render();
}
function ad_parent(h){
	var p = h.split("."), n = 2;
	if (p.length > 2 && /^(com|net|org|gov|edu|co|ac)$/.test(p[p.length - 2]) && p[p.length - 1].length == 2) n = 3;
	return p.length > n ? p.slice(-n).join(".") : "";
}
var AD_TRACE = null;
function ad_trace_start(){
	if (!MH_RUN) { alert("Mihomo 没有运行，先启动再记录"); return; }
	api_call("ad_trace", {});
}
function ad_trace_load(){
	$.ajax({type: "GET", url: "/_temp/mihomo_adtrace.txt?_=" + Date.now(), dataType: "text", cache: false,
		success: function(t){ AD_TRACE = (t || "").split(/\r?\n/).filter(function(l){ return l.indexOf("|") > 0; }).map(function(l){ var a = l.split("|"); return {h: a[0], s: a[1] || "", n: a[2] || "1"}; }); ad_trace_render(); },
		error: function(){ AD_TRACE = null; ad_trace_render(); }});
}
function ad_trace_render(){
	var b = E("adtrace_box"); if (!b) return;
	if (!AD_TRACE) { b.innerHTML = ""; return; }
	if (!AD_TRACE.length) { b.innerHTML = '<div class="adt-empty">上次记录期间没有域名被拦截</div>'; return; }
	b.innerHTML = '<div class="adt-head">上次记录到的拦截（次数多的在前）</div>' + AD_TRACE.map(function(x){
		var h = esc(x.h), p = ad_parent(x.h), btn;
		if (!/^[a-z0-9.-]+$/i.test(x.h)) btn = "";
		else if (x.s == "订阅自带规则") btn = '<span class="adt-note">订阅规则拦的，需在自定义规则放行</span>';
		else if (ad_allow_has(x.h)) btn = '<span class="adt-ok">已放行</span>';
		else btn = '<button type="button" class="mh-btn sm" onclick="ad_allow_add(\'' + h + '\')">放行</button>' + (p && p != x.h ? '<button type="button" class="mh-btn sm ghost" onclick="ad_allow_add(\'' + esc(p) + '\')" title="放行 ' + esc(p) + ' 及其所有子域名">整个 ' + esc(p) + '</button>' : "");
		var adl = /(^|[.-])(ads?|adserver|adsrv|adtng|track(ing|er)?|traffic\w*|pop(under|up)?|analytics|stats?|banner|doubleclick|syndication)([.-]|\d|$)/i.test(x.h);
		return '<div class="adt"><div class="adt-d"><code>' + h + '</code><small>' + esc(x.s) + ' · ' + esc(x.n) + ' 次' + (adl ? ' · <b class="adt-ad">像广告，建议别放行</b>' : "") + '</small></div><div class="adt-b">' + btn + '</div></div>';
	}).join("");
}
function adg_toggle(){ var m = E("adg_more"); if (m) m.style.display = E("adr_adguard").checked ? "" : "none"; }
function update_adguard(){
	if (!E("adr_adguard").checked) { alert("请先勾选「AdGuard DNS 过滤」并保存"); return; }
	var u = E("mihomo_adg_url").value.trim();
	if (u && !/^https?:\/\/\S+$/.test(u)) { alert("规则地址格式不对，需要以 http:// 或 https:// 开头"); return; }
	api_call("update_adguard", {mihomo_adg_url: u});
}

function showLoadingBar(){
	[].forEach.call(document.querySelectorAll("#mh .mh-btn"), function(b){ b.disabled = true; });
	E("log_status").innerHTML = "<span class='mh-badge warn'><i></i>正在执行，请稍候…</span>";
	switch_tab(LOG_TAB);
}

function hideLoadingBar(){
	[].forEach.call(document.querySelectorAll("#mh .mh-btn"), function(b){ b.disabled = false; });
	E("log_status").innerHTML = "";
}

function get_log(){
	$.ajax({
		url: "/_temp/mihomo_log.txt", type: "GET", dataType: "text", cache: false,
		success: function(response){
			var done = response.search("MIHOMO_DONE") != -1;
			var text = response.replace("MIHOMO_DONE", "");
			var shown = text.replace(/^SUB_GUARD \w+\n?/mg, "");
			if (text.length != _responseLen){ noChange = 0; _responseLen = text.length; } else { noChange++; }
			E("mihomo_log").value = shown;
			E("mihomo_log").scrollTop = E("mihomo_log").scrollHeight;
			if (done || noChange > 180){
				hideLoadingBar();
				E("log_status").innerHTML = done ? "<span class='mh-badge ok'><i></i>执行完成</span>" : "<span class='mh-badge err'><i></i>等待超时</span>";
				get_status();
				get_dbus_data();
				qt_reset();
				var g = text.match(/SUB_GUARD (\w+)/);
				if (g && confirm("新下载的订阅节点数量异常，插件保留了旧订阅（详见日志）。\n\n如果你确认机场的节点就是变少了，点「确定」强制使用新订阅。")) setTimeout(function(){ api_call("update_sub", {"mihomo_sub_target": g[1], "mihomo_sub_force": "1"}); }, 300);
				return;
			}
			setTimeout(get_log, 800);
		},
		error: function(){ setTimeout(get_log, 1000); }
	});
}

function fmt_uptime(s){
	s = parseInt(s) || 0;
	var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
	return (d ? d + "天" : "") + (h ? h + "小时" : "") + m + "分钟";
}

var MH_RUN = false, MH_TUN = false;
/* ---------- 值勤机器人：每 30 秒巡检一次（只读检查），结合连通性结果给出结论 ---------- */
var BOT = {items: [], time: "", sel: "", busy: false, last: 0, all: false, cheer: 0};
/* ---------- Claude 助手 ---------- */
function ai_toggle(){ var on = E("mihomo_ai_enable") && E("mihomo_ai_enable").checked; [].forEach.call(document.querySelectorAll("#mh .ai-row"), function(r){ r.style.display = on ? "" : "none"; }); }
function ai_on(){ return db_mihomo["mihomo_ai_enable"] == "1" && !!db_mihomo["mihomo_ai_key"]; }
function ai_b64(str){ return btoa(unescape(encodeURIComponent(str))); }
function ai_clean(t){ return String(t || "").replace(/https?:\/\/\S+/g, "[链接]").replace(/(secret|token|key|password|passwd)\s*[:=]\s*\S+/gi, "$1=***"); }
function ai_context(cb){
	var S = bot_state(), lines = [];
	lines.push("插件版本：" + (db_mihomo["mihomo_version"] || "") + "；" + (E("core_version").textContent || ""));
	lines.push("运行状态：" + (MH_RUN ? "运行中" : "未运行") + (MH_TUN ? "（TUN 模式）" : ""));
	lines.push("主要设置：配置模式=" + (db_mihomo["mihomo_cfg_mode"] || "") + "，DNS=" + (db_mihomo["mihomo_dns_mode"] || "") + "，UDP 代理=" + (db_mihomo["mihomo_udp"] == "1" ? "开" : "关") + "，去广告=" + (db_mihomo["mihomo_adblock"] == "1" ? "开" : "关") + (db_mihomo["mihomo_adrules"] ? "（规则集 " + db_mihomo["mihomo_adrules"] + "）" : "") + "，WebRTC 防泄漏=" + (db_mihomo["mihomo_webrtc"] || "proxy") + "，代理路由器自身=" + (db_mihomo["mihomo_router_proxy"] == "1" ? "开" : "关") + "，GitHub 走代理=" + (db_mihomo["mihomo_github_proxy"] != "0" ? "开" : "关"));
	lines.push("巡检结果（" + BOT.time + "）：");
	S.all.forEach(function(x){ lines.push("- [" + x[1] + "] " + x[2] + "：" + x[3]); });
	$.ajax({type: "GET", url: "/_temp/mihomo_log.txt?_=" + Date.now(), dataType: "text", cache: false, timeout: 5000,
		success: function(t){ var l = String(t || "").replace(/MIHOMO_DONE/g, "").trim().split(/\r?\n/).slice(-40); if (l.join("").trim()) { lines.push("最近一次操作的运行日志（最后 " + l.length + " 行）："); lines = lines.concat(l); } cb(ai_clean(lines.join("\n"))); },
		error: function(){ cb(ai_clean(lines.join("\n"))); }});
}
var AI_SYS = "你是华硕 RT-AX86U 梅林固件上 Mihomo（Clash.Meta）透明代理插件的值勤助手，名字叫「值勤机器人」。用简体中文回答，口语、简短、分点，先给结论再给原因和建议，一般不超过 8 行。只根据下面提供的路由器实时信息和常识判断，信息不够时直说并告诉用户去哪里看（插件里的卡片：订阅、配置与 DNS、网络、去广告、设备、自定义规则、覆写、控制面板、定时、存储、Telegram 通知、内核、插件更新、规则库、生成的配置、运行日志）。你不能直接操作路由器，不要假装已经执行了什么；需要操作时告诉用户点哪个按钮或卡片。不要编造节点名、域名或日志内容。\n\n";
function ai_call(messages, sys, done){
	var rid = String(Date.now()) + Math.floor(Math.random() * 1000);
	var body = JSON.stringify({model: db_mihomo["mihomo_ai_model"] || "claude-haiku-5-5", max_tokens: 900, system: sys, messages: messages});
	$.ajax({type: "POST", url: "/_api/", dataType: "json", cache: false, timeout: 15000,
		data: JSON.stringify({"id": parseInt(Math.random() * 100000000), "method": "mihomo_config.sh", "params": ["ai_ask"], "fields": {"mihomo_ai_rid": rid, "mihomo_ai_req": ai_b64(body)}}),
		success: function(){ ai_poll(rid, 0, done); },
		error: function(){ done(null, "提交到路由器失败，刷新页面再试"); }});
}
function ai_poll(rid, n, done){
	if (n > 100) { done(null, "等待超时（超过 100 秒没有结果）"); return; }
	setTimeout(function(){
		$.ajax({type: "GET", url: "/_temp/mihomo_ai.st?_=" + Date.now(), dataType: "text", cache: false, timeout: 5000,
			success: function(t){
				var a = String(t || "").trim().split("|");
				if (a[0] != rid || a[1] != "done") { ai_poll(rid, n + 1, done); return; }
				$.ajax({type: "GET", url: "/_temp/mihomo_ai.json?_=" + Date.now(), dataType: "text", cache: false, timeout: 5000,
					success: function(j){
						var o = null; try { o = JSON.parse(j); } catch (e) {}
						if (o && o.content) { done((o.content || []).filter(function(c){ return c.type == "text"; }).map(function(c){ return c.text; }).join("\n").trim()); return; }
						var m = o && o.error ? (o.error.message || o.error.type) : String(j || "").slice(0, 120);
						var code = a[2] || "";
						if (code == "401") m = "API Key 无效（401），检查一下有没有填错";
						else if (code == "403") m = "没有权限（403）：" + m;
						else if (code == "429") m = "请求太频繁或额度用完（429）";
						else if (code == "529" || code == "503") m = "Claude 服务繁忙，过一会儿再试";
						done(null, m || "未知错误");
					}, error: function(){ done(null, "读取结果失败"); }});
			}, error: function(){ ai_poll(rid, n + 1, done); }});
	}, n < 5 ? 800 : 1500);
}
function ai_test(){
	var r = E("ai_test_res"), key = E("mihomo_ai_key").value.trim();
	if (!key) { r.className = "ai-res err"; r.textContent = "先填写 API Key"; return; }
	if (key != (db_mihomo["mihomo_ai_key"] || "") || E("mihomo_ai_model").value != (db_mihomo["mihomo_ai_model"] || "claude-haiku-5-5") || E("mihomo_ai_base").value.trim().replace(/\/+$/, "") != (db_mihomo["mihomo_ai_base"] || "")) {
		r.className = "ai-res err"; r.textContent = "改动还没保存，先点「保存并应用」再测试"; return;
	}
	r.className = "ai-res"; r.textContent = "正在连接 Claude…";
	ai_call([{role: "user", content: "请只回复：连接成功"}], "你是连通性测试，严格按要求简短回复。", function(t, err){
		if (t) { r.className = "ai-res ok"; r.textContent = "✓ " + t.slice(0, 40); } else { r.className = "ai-res err"; r.textContent = "✗ " + err; }
	});
}
function bot_open(){ mh_sheet_open("bot"); bot_check(true); }
var BOT_FX = {
	ok: '<b class="fx ok">✓</b><i class="sp s1">✦</i><i class="sp s2">✦</i><i class="sp s3">✦</i>',
	scan: '',
	warn: '<b class="fx warn">!</b><i class="think"><em></em><em></em><em></em></i>',
	err: '<b class="fx err">!</b>',
	sleep: '<i class="zz z1">z</i><i class="zz z2">z</i><i class="zz z3">Z</i>'
};
/* 姿势：正常/巡检 = 站着，需要留意 = 抱膝坐着想事情，发现问题 = 站着发抖，休息 = 趴着睡；手动巡检全部正常时欢呼一下 */
var BOT_POSE = {ok: "stand", scan: "stand", warn: "sit", err: "stand", sleep: "sleep"};
function bot_face(st){
	var b = E("bot"); if (!b) return;
	var pose = (BOT.cheer > Date.now() && st == "ok") ? "cheer" : BOT_POSE[st];
	b.setAttribute("data-pose", pose);
	if (b.getAttribute("data-st") == st && E("bot_fx").getAttribute("data-st") == st) return;
	b.setAttribute("data-st", st);
	E("bot_fx").setAttribute("data-st", st);
	E("bot_fx").innerHTML = BOT_FX[st];
}
function bot_cheer(){
	BOT.cheer = Date.now() + 3200; bot_render();
	setTimeout(function(){ if (BOT.cheer <= Date.now()) bot_render(); }, 3300);
}
function bot_net_items(){
	var r = [], pill = function(s){ return document.querySelector('#mh_ping .mh-pill[data-site="' + s + '"]'); };
	var g = pill("github"), y = pill("youtube"), d = pill("baidu");
	var bad = function(p){ return p && /\bbad\b/.test(p.className); }, has = function(p){ return p && /\b(good|mid|bad)\b/.test(p.className); };
	if (has(d)) r.push(bad(d) ? ["netcn", "err", "国内网络", "百度连不上，检查路由器的宽带或 DNS"] : ["netcn", "ok", "国内网络", "百度 " + d.querySelector("b").textContent]);
	if (MH_RUN && (has(g) || has(y))) {
		if (bad(g) && bad(y)) r.push(["netgl", "err", "外网连通", "GitHub 和 YouTube 都连不上，节点可能失效了，到控制面板换个节点或更新订阅"]);
		else if (bad(g) || bad(y)) r.push(["netgl", "warn", "外网连通", (bad(g) ? "GitHub" : "YouTube") + " 连不上，另一个正常，可能是该网站走的分组选了直连或节点不通"]);
		else r.push(["netgl", "ok", "外网连通", "GitHub " + g.querySelector("b").textContent + " · YouTube " + y.querySelector("b").textContent]);
	}
	return r;
}
function bot_check(manual){
	if (BOT.busy) return;
	BOT.busy = true; BOT.last = Date.now();
	if (manual) { BOT.sel = ""; bot_face("scan"); E("bot_msg").innerHTML = "收到，马上巡检一遍…"; }
	else if (!BOT.items.length) bot_face("scan");
	var done = function(){ BOT.busy = false; };
	$.ajax({type: "POST", url: "/_api/", cache: false, dataType: "json", timeout: 15000,
		data: JSON.stringify({"id": parseInt(Math.random() * 100000000), "method": "mihomo_config.sh", "params": ["health"], "fields": {}}),
		success: function(){
			$.ajax({type: "GET", url: "/_temp/mihomo_health.txt?_=" + Date.now(), dataType: "text", cache: false, timeout: 8000,
				success: function(t){
					var items = [], tm = "";
					String(t || "").split(/\r?\n/).forEach(function(l){
						var a = l.split("|"); if (a.length < 2) return;
						if (a[0] == "@time") tm = a[1]; else if (a.length >= 4) items.push([a[0], a[1], a[2], a.slice(3).join("|")]);
					});
					BOT.items = items; BOT.time = tm;
					setTimeout(function(){ bot_render(); done(); if (manual && bot_state().st == "ok") bot_cheer(); }, manual ? 700 : 0);
				}, error: function(){ bot_fail(); done(); }});
		}, error: function(){ bot_fail(); done(); }});
}
function bot_fail(){
	bot_face("warn");
	E("bot_msg").innerHTML = "巡检请求没有响应";
	E("bot_sub").innerHTML = "可能是路由器太忙或页面登录过期，过一会儿会自动再试";
}
function bot_all(){ return BOT.items.concat(bot_net_items()); }
function bot_state(){
	var all = bot_all(), on = all.filter(function(x){ return x[1] != "off"; });
	var errs = on.filter(function(x){ return x[1] == "err"; }), warns = on.filter(function(x){ return x[1] == "warn"; });
	var core = all.filter(function(x){ return x[0] == "core"; })[0];
	var st = (core && core[1] == "off") ? "sleep" : errs.length ? "err" : warns.length ? "warn" : "ok";
	return {all: all, on: on, errs: errs, warns: warns, st: st};
}
function bot_render(){
	if (!E("bot") || !BOT.items.length) return;
	var S = bot_state(), msg;
	bot_face(S.st);
	if (S.st == "sleep") msg = "Mihomo 没有启用，我先打个盹。";
	else if (S.st == "err") msg = "发现 " + S.errs.length + " 个问题，点我看看";
	else if (S.st == "warn") msg = "有 " + S.warns.length + " 项需要留意，点我看看";
	else msg = "一切正常，放心冲浪吧！";
	E("bot_msg").innerHTML = msg;
	E("bot_sub").innerHTML = "巡检于 " + esc(BOT.time) + " · 点我查看状态、和我聊天";
	if (MH_CUR_SHEET == "bot") bot_pane_render();
}
function bot_pane_render(){
	if (!E("bp_list")) return;
	if (!BOT.items.length) { E("bp_sum").innerHTML = "正在巡检…"; E("bp_list").innerHTML = ""; }
	else {
		var S = bot_state(), lv = {err: 0, warn: 1, ok: 2, off: 3};
		E("bp_sum").innerHTML = '<span class="bp-face ' + S.st + '"></span>' + (S.st == "sleep" ? "Mihomo 没有启用" : S.st == "err" ? "发现 " + S.errs.length + " 个问题" + (S.warns.length ? "，" + S.warns.length + " 项需要留意" : "") : S.st == "warn" ? S.warns.length + " 项需要留意，其它正常" : S.on.length + " 项全部正常") + '<small>巡检于 ' + esc(BOT.time) + '</small>';
		var bad = S.all.filter(function(x){ return x[1] == "err" || x[1] == "warn"; });
		var show = BOT.all ? S.all : bad;
		E("bp_more").textContent = BOT.all ? "收起" : (bad.length ? "查看全部 " + S.all.length + " 项检查" : "全部 " + S.all.length + " 项检查都正常，点开看看");
		E("bp_list").innerHTML = show.slice().sort(function(a, b){ return lv[a[1]] - lv[b[1]]; }).map(function(x){
			return '<div class="bp-it ' + x[1] + '"><i></i><div><b>' + esc(x[2]) + '</b><span>' + esc(x[3]) + '</span></div></div>';
		}).join("");
	}
	E("bp_mode").innerHTML = ai_on() ? '<span class="on">Claude 已接入</span>' : '<span>本地问答 · 可在「配置与 DNS」接入 Claude</span>';
	if (!E("bp_msgs").childNodes.length) bot_say("你好，我是值勤机器人。上面是我刚巡检的结果，有什么想问的直接问我，也可以点下面的快捷问题。");
	bot_sugs();
}
/* ---------- 聊天：在页面里按关键词理解问题，结合巡检结果回答；需要动手的给按钮，点了才执行 ---------- */
var BOT_ACT = {};
var BOT_CAP = null;
function bot_say(html, acts){
	if (BOT_CAP) { BOT_CAP.html = html; BOT_CAP.acts = acts || []; return; }
	var box = E("bp_msgs"), d = document.createElement("div"), id;
	d.className = "bp-m ai";
	var b = "";
	(acts || []).forEach(function(a){ id = "a" + Math.random().toString(36).slice(2, 8); BOT_ACT[id] = a[1]; b += '<button type="button" class="mh-btn sm" onclick="bot_act(\'' + id + '\')">' + esc(a[0]) + '</button>'; });
	d.innerHTML = '<div class="bp-b">' + html + (b ? '<div class="bp-acts">' + b + '</div>' : "") + '</div>';
	box.appendChild(d); box.scrollTop = box.scrollHeight;
}
function bot_me(t){
	var box = E("bp_msgs"), d = document.createElement("div");
	d.className = "bp-m me"; d.innerHTML = '<div class="bp-b">' + esc(t) + '</div>';
	box.appendChild(d); box.scrollTop = box.scrollHeight;
}
function bot_act(id){ var f = BOT_ACT[id]; if (f) f(); }
var BOT_SUGS = ["现在状态怎么样？", "为什么网页打不开？", "节点是不是挂了？", "帮我更新订阅", "广告没拦住 / 拦错了", "看看运行日志"];
function bot_sugs(){ E("bp_sugs").innerHTML = BOT_SUGS.map(function(q){ return '<button type="button" class="bp-sug" onclick="bot_send(this.textContent)">' + esc(q) + '</button>'; }).join(""); }
function bot_send(q){
	q = (q != null ? q : E("bp_q").value).trim(); if (!q) return;
	E("bp_q").value = ""; bot_me(q);
	var thinking = document.createElement("div"); thinking.className = "bp-m ai"; thinking.innerHTML = '<div class="bp-b bp-dots"><i></i><i></i><i></i></div>';
	E("bp_msgs").appendChild(thinking); E("bp_msgs").scrollTop = E("bp_msgs").scrollHeight;
	if (!ai_on()) { setTimeout(function(){ thinking.parentNode && thinking.parentNode.removeChild(thinking); bot_answer(q); }, 450); return; }
	/* 交给 Claude：本地规则只用来挑选回答下面的操作按钮；Claude 出错时退回本地回答 */
	BOT_CAP = {}; bot_answer(q); var local = BOT_CAP; BOT_CAP = null;
	BOT.hist = (BOT.hist || []).concat([{role: "user", content: q}]).slice(-10);
	ai_context(function(ctx){
		ai_call(BOT.hist, AI_SYS + "【路由器实时信息】\n" + ctx, function(t, err){
			thinking.parentNode && thinking.parentNode.removeChild(thinking);
			if (t) {
				BOT.hist.push({role: "assistant", content: t});
				bot_say(esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>") + '<div class="bp-by">Claude · ' + esc((db_mihomo["mihomo_ai_model"] || "").replace("claude-", "")) + '</div>', local.acts);
			} else {
				BOT.hist.pop();
				bot_say((local.html || "") + '<div class="bp-by err">Claude 暂时不可用：' + esc(err) + '，以上是本地回答</div>', local.acts);
			}
		});
	});
}
function bot_item(k){ return bot_all().filter(function(x){ return x[0] == k; })[0]; }
function bot_line(x){ return x ? '<b>' + esc(x[2]) + '</b>：' + esc(x[3]) : ""; }
function bot_go(k){ return function(){ mh_sheet_open(k); }; }
function bot_answer(q){
	var S = bot_state(), t = q.toLowerCase(), has = function(re){ return re.test(t); };
	var A = {
		upd_sub: ["立即更新订阅", function(){ mh_sheet_close(); update_sub(); }],
		upd_geo: ["更新规则库", function(){ mh_sheet_close(); update_geo(); }],
		chk_core: ["检查内核更新", function(){ mh_sheet_close(); api_call("check_core", {}); }],
		restart: ["重启 Mihomo", function(){ if (confirm("确定重启 Mihomo？会断网几秒钟。")) { mh_sheet_close(); api_call("restart", {}); } }],
		start: ["启动 Mihomo", function(){ mh_sheet_close(); mh_power_toggle(); }],
		log: ["打开运行日志", bot_go("log")],
		ad: ["打开去广告设置", bot_go("ad")],
		trace: ["找出被拦截的域名", function(){ mh_sheet_open("ad"); ad_trace_start(); }],
		gh: ["诊断 GitHub 连接", function(){ mh_sheet_close(); api_call("diag_github", {}); }],
		panel: ["打开控制面板", function(){ var a = document.querySelector("#ui_link a"); if (a) window.open(a.href, "_blank"); else alert("Mihomo 运行后才能打开控制面板"); }],
		recheck: ["重新巡检", function(){ bot_check(true); setTimeout(function(){ bot_answer("状态"); }, 1600); }]
	};
	if (!BOT.items.length) { bot_say("我还在做第一次巡检，稍等几秒再问我。", [A.recheck]); return; }
	if (S.st == "sleep" && !has(/你好|hi|hello|你是谁|干什么/)) { bot_say("Mihomo 现在没有启用，代理、去广告这些都不在工作。要我帮你启动吗？", [A.start]); return; }
	if (has(/你好|hi|hello|在吗|你是谁|干什么|能做什么/)) {
		bot_say("我是值勤机器人：每 30 秒把插件的关键功能检查一遍（进程、端口、防火墙、DNS、订阅、规则库、去广告、防泄漏、存储、国内外连通），出问题第一时间告诉你。你可以问我状态、网页打不开怎么办、订阅/规则库/内核要不要更新、广告问题等，需要动手的地方我会给按钮，点了才执行。"); return;
	}
	if (has(/打不开|上不了|连不上|访问不了|进不去|不能上|没网|断网|慢|卡/)) {
		var r = [], acts = [], cn = bot_item("netcn"), gl = bot_item("netgl");
		S.errs.concat(S.warns).forEach(function(x){ if (x[0] != "netgl" && x[0] != "netcn") r.push("· " + bot_line(x)); });
		if (cn && cn[1] == "err") { r.unshift("· 国内网站（百度）都连不上，问题多半在宽带或路由器本身，和代理无关；可以先重启光猫/路由器。"); }
		else if (gl && gl[1] != "ok") { r.push("· " + bot_line(gl)); r.push("· 一般是当前节点不通：到控制面板换个节点、测一下延迟，或者更新订阅。"); acts.push(A.panel, A.upd_sub); }
		if (!r.length) {
			bot_say("我这边检查都正常，国内外测试网站也都通。如果只是某个网站打不开，常见原因有两个：<br>1. 被去广告规则误拦了 —— 点「找出被拦截的域名」，60 秒内去打开那个网站，我会列出被拦的域名，放行就好；<br>2. 这个网站走的分组选了直连或者节点不通 —— 到控制面板看看它命中了哪条规则、走了哪个节点。", [A.trace, A.panel]);
		} else bot_say("我看了一下，可能和这些有关：<br>" + r.join("<br>"), acts.concat([A.log]));
		return;
	}
	if (has(/节点|机场|挂了|代理.*(不行|不通|坏)|翻墙|外网|youtube|github|google|谷歌/)) {
		var g = bot_item("netgl");
		if (!g) bot_say("Mihomo 没在运行，没法测外网。", [A.start]);
		else if (g[1] == "ok") bot_say("节点正常：" + esc(g[3]) + "。如果个别网站慢，可以到控制面板测速换个延迟低的节点。" + (/github/.test(t) ? "<br>GitHub 在你设备上还是打不开的话，点「诊断 GitHub 连接」从路由器上查一遍。" : ""), /github/.test(t) ? [A.gh, A.panel] : [A.panel]);
		else bot_say(bot_line(g) + "<br>建议：到控制面板换个节点或测速；如果所有节点都不行，更新一下订阅，或者看看机场是不是到期/流量用完了。" + (/github/.test(t) || /GitHub/.test(g[3]) ? "<br>GitHub 单独连不上的话，点「诊断 GitHub 连接」，我把它走的规则、分组、节点一项项查给你看。" : ""), /github/.test(t) || /GitHub/.test(g[3]) ? [A.gh, A.panel] : [A.panel, A.upd_sub]);
		return;
	}
	if (has(/订阅|流量|到期/)) {
		var sb = bot_item("sub"), extra = E("wgs_sub") ? E("wgs_sub").textContent : "";
		bot_say((sb ? bot_line(sb) : "当前使用自定义配置，没有订阅。") + (extra && extra != "—" ? "<br>订阅信息：" + esc(extra) : ""), sb && sb[1] != "off" ? [A.upd_sub] : []);
		return;
	}
	if (has(/规则库|geo|geosite|geoip/)) { bot_say(bot_line(bot_item("geo")), [A.upd_geo]); return; }
	if (has(/内核|版本|升级|更新/)) {
		bot_say("当前内核：" + esc(E("core_version").textContent || "未知") + "，插件：" + esc(db_mihomo["mihomo_version"] || "") + "。要检查有没有新内核吗？订阅和规则库也可以单独更新。", [A.chk_core, A.upd_sub, A.upd_geo]);
		return;
	}
	if (has(/广告|拦截|拦错|误拦|放行|adguard|白名单/)) {
		var ag = bot_item("adg");
		bot_say("去广告：" + esc(E("wgv_ad") ? E("wgv_ad").textContent : "") + "，" + esc(E("wgs_ad") ? E("wgs_ad").textContent : "") + (ag ? "<br>" + bot_line(ag) : "") +
			"<br>· 有网页/视频被误拦：点「找出被拦截的域名」，然后去打开那个页面，结束后把视频相关的域名放行；<br>· 广告没拦住：可以多开一个规则集（比如 AdGuard），App 内嵌广告路由器端拦不了。", [A.trace, A.ad]);
		return;
	}
	if (has(/webrtc|泄漏|泄露|真实ip|真实 ip|ipv6/)) { bot_say([bot_item("rtc"), bot_item("ipv6")].filter(Boolean).map(bot_line).join("<br>") || "防泄漏功能没有开启。", [["打开网络设置", bot_go("net")]]); return; }
	if (has(/dns|解析/)) { bot_say(bot_line(bot_item("dns")) || "Mihomo 没运行，DNS 不归我管。"); return; }
	if (has(/防火墙|iptables|端口|规则丢/)) { bot_say([bot_item("fw"), bot_item("ports")].filter(Boolean).map(bot_line).join("<br>") + "<br>规则或端口出问题时，守护进程会在一分钟内自动修复；着急的话可以手动重启。", [A.restart]); return; }
	if (has(/内存|cpu|存储|空间|jffs|u盘|u 盘/)) { bot_say([bot_item("core"), bot_item("disk")].filter(Boolean).map(bot_line).join("<br>"), [["打开存储设置", bot_go("store")]]); return; }
	if (has(/日志|log|报错|错误/)) { bot_say("运行日志里有每次启动、更新的详细过程，出错时最有用。", [A.log]); return; }
	if (has(/重启|restart/)) { bot_say("重启会断网几秒钟。一般不需要手动重启，守护进程会自动处理异常。确定要重启吗？", [A.restart]); return; }
	if (has(/tun/)) { var tn = bot_item("tun"); bot_say(tn ? bot_line(tn) : "TUN 模式没有开启（在「网络」里，实验功能）。", [["打开网络设置", bot_go("net")]]); return; }
	if (has(/状态|正常吗|有问题|有没有问题|检查|巡检|体检|(现在|插件|路由器|代理|mihomo).{0,4}(怎么样|好不好|如何)/)) {
		var bad = S.errs.concat(S.warns);
		if (!bad.length) bot_say("刚巡检过（" + esc(BOT.time) + "），" + S.on.length + " 项全部正常 ✓", [A.recheck]);
		else bot_say("刚巡检过（" + esc(BOT.time) + "），需要你看一下的：<br>" + bad.map(function(x){ return "· " + bot_line(x); }).join("<br>"), [A.recheck, A.log]);
		return;
	}
	bot_say("这个问题我暂时不会回答 😅 我目前只懂这个插件自己的事，比如：状态怎么样、网页打不开、节点挂了没、订阅/规则库/内核更新、去广告误拦、防泄漏、日志。换个说法试试，或者点下面的快捷问题。");
}
setInterval(function(){ if (!document.hidden && Date.now() - BOT.last > 29000) bot_check(false); }, 3000);
function get_status(){
	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "mihomo_status.sh", "params": [], "fields": {}};
	$.ajax({
		type: "POST", url: "/_api/", data: JSON.stringify(postData), dataType: "json", cache: false,
		success: function(resp){
			var a = String(resp.result || "").split("@@");
			var s = E("mihomo_status"), on = false;
			MH_RUN = a[0] == "1"; MH_TUN = a[6] == "1";
			if (a[0] == "1"){
				on = true;
				s.innerHTML = "<span class='mh-badge ok'><i></i>运行中</span>";
				E("st_pid").innerHTML = a[1] || "—";
				E("st_mem").innerHTML = Math.round((parseInt(a[4]) || 0) / 1024) + "<small>MB</small>";
				E("st_up").innerHTML = fmt_uptime(a[5]);
				E("st_hint").innerHTML = MH_TUN ? "局域网的 TCP、UDP 由 TUN 网卡交给 Mihomo（实验），DNS 由 Mihomo 接管。" : "局域网的 TCP 流量与 DNS 正由 Mihomo 接管" + (E("mihomo_udp").checked ? "，UDP 走 TPROXY" : "") + "。";
				var port = E("mihomo_ui_port").value || "9090";
				var host = location.hostname;
				var secret = encodeURIComponent(db_mihomo["mihomo_secret"] || "");
				E("ui_link").innerHTML = "<a href='http://" + host + ":" + port + "/ui/?v=" + encodeURIComponent(db_mihomo["mihomo_version"] || "") + "#secret=" + secret + "' target='_blank'>打开控制面板 <svg class='i' viewBox='0 0 24 24'><path d='M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5'/></svg></a>";
			} else if (a[0] == "2"){
				s.innerHTML = "<span class='mh-badge warn'><i></i>启动中…</span>";
				E("st_hint").innerHTML = "正在启动，端口还没全部就绪。";
			} else {
				s.innerHTML = "<span class='mh-badge err'><i></i>未运行</span>";
				E("st_pid").innerHTML = E("st_mem").innerHTML = E("st_up").innerHTML = "—";
				E("st_hint").innerHTML = "点右边的按钮启动（等于勾选「启用 Mihomo」并保存）。";
				E("ui_link").innerHTML = "<span class='off'>Mihomo 运行后可打开控制面板</span>";
			}
			mh_power_ui(on);
			if (!BOT.last) setTimeout(function(){ bot_check(false); }, 1500); else bot_render();
			E("core_version").innerHTML = a[2] ? ("内核 " + a[2]) : "";
		}
	});
}
var MH_PAUSE = '<svg viewBox="0 0 24 24"><rect x="6" y="5" width="4" height="14" rx="1.6"/><rect x="14" y="5" width="4" height="14" rx="1.6"/></svg>';
var MH_PLAY = '<svg viewBox="0 0 24 24"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
function mh_power_ui(on){
	var b = E("mh_power"); if (!b) return;
	b.className = "mh-power" + (on ? "" : " off");
	b.title = on ? "停止 Mihomo（取消启用并保存）" : "启动 Mihomo（启用并保存）";
	E("mh_power_icon").innerHTML = on ? MH_PAUSE : MH_PLAY;
}
function mh_power_toggle(){
	var c = E("mihomo_enable");
	var to = !(E("mh_power").className.indexOf("off") < 0);
	if (!to && !confirm("停止 Mihomo？局域网会恢复直连。")) return;
	c.checked = to;
	save();
}
/* 主题：跟随系统，点按钮在浅色 / 深色之间切换并记住 */
var MH_SUN = '<svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>', MH_MOON = '<svg class="i" viewBox="0 0 24 24"><path d="M20.5 13.5A8.5 8.5 0 1 1 10.5 3.5a6.5 6.5 0 0 0 10 10z"/></svg>';
function mh_apply_theme(){
	var t = "auto"; try { t = localStorage.getItem("mh_asp_theme") || "auto"; } catch(e){}
	var dark = t == "dark" || (t == "auto" && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches);
	var m = E("mh"); if (!m) return;
	m.setAttribute("data-theme", dark ? "dark" : "light");
	var b = E("mh_theme_btn"); if (b) b.innerHTML = dark ? MH_SUN : MH_MOON;
}
function mh_cycle_theme(){
	var dark = E("mh").getAttribute("data-theme") == "dark";
	try { localStorage.setItem("mh_asp_theme", dark ? "light" : "dark"); } catch(e){}
	mh_apply_theme();
}
</script>
</head>
<body onload="init();">
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="POST" name="form" action="" target="hidden_frame" onsubmit="return false;">
<input type="hidden" name="current_page" value="Module_mihomo.asp"/>
<input type="hidden" name="next_page" value="Module_mihomo.asp"/>
<input type="hidden" name="group_id" value=""/>
<input type="hidden" name="modified" value="0"/>
<input type="hidden" name="action_mode" value=""/>
<input type="hidden" name="action_script" value=""/>
<input type="hidden" name="action_wait" value="5"/>
<input type="hidden" name="first_time" value=""/>
<input type="hidden" name="preferred_lang" id="preferred_lang" value="<% nvram_get("preferred_lang"); %>"/>
<input type="hidden" name="firmver" value="<% nvram_get("firmver"); %>"/>
<table class="content" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="17">&nbsp;</td>
<td valign="top" width="202">
	<div id="mainMenu"></div>
	<div id="subMenu"></div>
</td>
<td valign="top">
	<div id="tabMenu" class="submenuBlock"></div>
	<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
	<tr><td align="left" valign="top">
	<table width="760px" border="0" cellpadding="5" cellspacing="0" bordercolor="#6b8fa3" class="FormTitle" id="FormTitle">
	<tr><td bgcolor="#4D595D" colspan="3" valign="top">
		<div id="mh">
		<script>mh_apply_theme();</script>
		<div class="mh-head">
			<div class="mh-logo"><svg viewBox="0 0 24 24"><path d="M13 2 4.5 13.5H12L11 22l8.5-11.5H12L13 2z"/></svg></div>
			<div class="mh-htext">
				<div class="mh-title">Mihomo</div>
				<div class="mh-chips"><span class="mh-chip" id="mihomo_version_show"></span><span class="mh-chip" id="core_version"></span><span class="mh-chip">Clash.Meta 透明代理</span></div>
			</div>
			<button type="button" class="mh-btn primary mh-hsave" id="btn_save" onclick="save()" title="保存全部设置并重启 Mihomo"><svg class="i" viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></svg><span>保存并应用</span></button>
			<button type="button" class="mh-ibtn" id="mh_theme_btn" onclick="mh_cycle_theme()" title="切换浅色 / 深色"><svg class="i" viewBox="0 0 24 24"><path d="M20.5 13.5A8.5 8.5 0 1 1 10.5 3.5a6.5 6.5 0 0 0 10 10z"/></svg></button>
			<button type="button" class="mh-ibtn" id="return_btn" onclick="reload_Soft_Center();" title="返回软件中心"><svg class="i" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button>
		</div>
		<p class="mh-desc">局域网 (br0) 的 TCP 流量与 DNS 由 Mihomo 接管，可选 UDP 透明代理。</p>

		<div class="mh-hero">
			<div class="mh-scard mh-status">
				<svg class="blob" viewBox="0 0 100 100"><path d="M95.43 50.00 L95.47 50.79 L95.46 51.59 L95.41 52.38 L95.30 53.17 L95.15 53.95 L94.96 54.72 L94.72 55.49 L94.43 56.24 L94.11 56.99 L93.75 57.71 L93.36 58.43 L92.93 59.12 L92.47 59.80 L91.98 60.47 L91.47 61.11 L90.93 61.74 L90.38 62.35 L89.81 62.94 L89.23 63.51 L88.64 64.07 L88.05 64.61 L87.45 65.13 L86.85 65.64 L86.25 66.14 L85.65 66.63 L85.06 67.10 L84.48 67.57 L83.91 68.03 L83.35 68.49 L82.80 68.94 L82.27 69.39 L81.75 69.84 L81.25 70.29 L80.76 70.75 L80.28 71.20 L79.82 71.67 L79.38 72.14 L78.94 72.61 L78.52 73.10 L78.12 73.59 L77.72 74.10 L77.33 74.61 L76.95 75.13 L76.57 75.66 L76.20 76.20 L75.83 76.75 L75.47 77.31 L75.10 77.87 L74.72 78.44 L74.35 79.02 L73.97 79.60 L73.58 80.18 L73.18 80.76 L72.77 81.34 L72.34 81.91 L71.91 82.48 L71.46 83.05 L71.00 83.60 L70.52 84.15 L70.02 84.68 L69.51 85.19 L68.98 85.69 L68.43 86.17 L67.87 86.63 L67.29 87.07 L66.69 87.48 L66.08 87.87 L65.45 88.24 L64.81 88.57 L64.15 88.88 L63.48 89.15 L62.80 89.40 L62.11 89.61 L61.41 89.79 L60.70 89.94 L59.99 90.06 L59.27 90.15 L58.55 90.21 L57.82 90.24 L57.09 90.24 L56.37 90.21 L55.64 90.15 L54.92 90.07 L54.20 89.96 L53.48 89.83 L52.77 89.68 L52.07 89.52 L51.37 89.33 L50.68 89.13 L50.00 88.92 L49.32 88.70 L48.66 88.47 L48.00 88.23 L47.34 87.99 L46.70 87.75 L46.06 87.51 L45.42 87.27 L44.79 87.04 L44.17 86.81 L43.55 86.59 L42.93 86.38 L42.31 86.18 L41.69 85.99 L41.07 85.82 L40.45 85.65 L39.82 85.50 L39.19 85.37 L38.55 85.25 L37.90 85.14 L37.25 85.04 L36.58 84.96 L35.91 84.88 L35.22 84.82 L34.52 84.76 L33.81 84.71 L33.09 84.66 L32.36 84.62 L31.62 84.57 L30.86 84.53 L30.10 84.47 L29.32 84.42 L28.54 84.35 L27.75 84.27 L26.95 84.17 L26.15 84.06 L25.35 83.93 L24.55 83.77 L23.75 83.60 L22.96 83.39 L22.17 83.16 L21.40 82.90 L20.63 82.61 L19.89 82.29 L19.16 81.94 L18.45 81.55 L17.76 81.13 L17.10 80.68 L16.46 80.20 L15.86 79.68 L15.29 79.13 L14.75 78.54 L14.25 77.93 L13.79 77.29 L13.36 76.62 L12.98 75.92 L12.63 75.21 L12.32 74.47 L12.06 73.71 L11.83 72.93 L11.65 72.14 L11.51 71.34 L11.40 70.52 L11.33 69.70 L11.30 68.88 L11.30 68.05 L11.33 67.22 L11.39 66.39 L11.48 65.56 L11.60 64.74 L11.73 63.93 L11.89 63.12 L12.07 62.33 L12.26 61.54 L12.46 60.77 L12.66 60.00 L12.88 59.26 L13.10 58.52 L13.31 57.80 L13.53 57.09 L13.74 56.39 L13.94 55.71 L14.13 55.04 L14.31 54.38 L14.48 53.73 L14.63 53.09 L14.77 52.46 L14.89 51.84 L14.99 51.22 L15.07 50.61 L15.13 50.00 L15.17 49.39 L15.19 48.78 L15.20 48.18 L15.18 47.57 L15.15 46.95 L15.09 46.33 L15.03 45.71 L14.94 45.07 L14.85 44.43 L14.74 43.78 L14.62 43.12 L14.50 42.45 L14.37 41.77 L14.24 41.08 L14.11 40.38 L13.98 39.67 L13.85 38.95 L13.73 38.22 L13.62 37.47 L13.52 36.72 L13.44 35.96 L13.37 35.20 L13.32 34.43 L13.29 33.66 L13.29 32.88 L13.31 32.10 L13.35 31.33 L13.43 30.55 L13.53 29.79 L13.67 29.02 L13.84 28.27 L14.04 27.53 L14.27 26.80 L14.54 26.08 L14.84 25.38 L15.17 24.70 L15.54 24.04 L15.95 23.39 L16.38 22.77 L16.85 22.18 L17.34 21.61 L17.87 21.07 L18.42 20.55 L18.99 20.06 L19.60 19.60 L20.22 19.16 L20.86 18.75 L21.52 18.37 L22.20 18.02 L22.89 17.69 L23.59 17.39 L24.30 17.11 L25.02 16.85 L25.74 16.61 L26.47 16.40 L27.20 16.20 L27.93 16.01 L28.65 15.84 L29.38 15.68 L30.10 15.53 L30.81 15.38 L31.52 15.24 L32.22 15.10 L32.91 14.96 L33.60 14.82 L34.27 14.68 L34.94 14.53 L35.61 14.37 L36.26 14.21 L36.91 14.03 L37.55 13.85 L38.19 13.65 L38.82 13.45 L39.46 13.23 L40.09 13.00 L40.71 12.76 L41.34 12.50 L41.97 12.24 L42.61 11.97 L43.25 11.69 L43.89 11.41 L44.54 11.12 L45.19 10.83 L45.85 10.54 L46.52 10.25 L47.20 9.97 L47.89 9.69 L48.58 9.42 L49.29 9.16 L50.00 8.92 L50.72 8.69 L51.45 8.49 L52.19 8.30 L52.93 8.14 L53.67 8.01 L54.42 7.90 L55.18 7.83 L55.93 7.78 L56.69 7.77 L57.44 7.79 L58.19 7.85 L58.94 7.95 L59.68 8.08 L60.41 8.25 L61.13 8.45 L61.84 8.69 L62.54 8.97 L63.23 9.29 L63.90 9.64 L64.55 10.02 L65.19 10.43 L65.81 10.88 L66.40 11.36 L66.98 11.86 L67.54 12.38 L68.08 12.94 L68.59 13.51 L69.09 14.10 L69.57 14.70 L70.02 15.32 L70.46 15.95 L70.87 16.60 L71.27 17.24 L71.65 17.90 L72.02 18.55 L72.37 19.20 L72.71 19.86 L73.04 20.51 L73.36 21.15 L73.68 21.78 L73.98 22.41 L74.28 23.03 L74.59 23.63 L74.89 24.23 L75.19 24.81 L75.50 25.38 L75.81 25.93 L76.13 26.47 L76.46 27.00 L76.80 27.51 L77.16 28.01 L77.53 28.49 L77.91 28.97 L78.31 29.43 L78.73 29.89 L79.16 30.33 L79.61 30.77 L80.08 31.20 L80.57 31.63 L81.08 32.06 L81.60 32.48 L82.14 32.91 L82.70 33.34 L83.27 33.77 L83.86 34.21 L84.45 34.66 L85.06 35.12 L85.67 35.59 L86.29 36.07 L86.91 36.56 L87.53 37.08 L88.15 37.60 L88.76 38.15 L89.37 38.71 L89.96 39.29 L90.53 39.89 L91.09 40.51 L91.63 41.15 L92.14 41.81 L92.63 42.48 L93.08 43.18 L93.50 43.89 L93.89 44.61 L94.24 45.35 L94.55 46.10 L94.82 46.87 L95.04 47.64 L95.22 48.42 L95.35 49.21Z" fill="currentColor"/></svg>
				<div class="mh-ch"><svg class="i" viewBox="0 0 24 24"><path d="M3 12h4l3-7 4 14 3-7h4"/></svg>值勤机器人 <span id="mihomo_status"><span class="mh-badge warn"><i></i>获取中…</span></span></div>
				<div id="st_hint" style="display:none"></div>
				<div class="bot-wrap">
					<button type="button" class="bot" id="bot" data-st="scan" data-pose="stand" onclick="bot_open()" title="点我查看状态、和我聊天"><span class="bot-plat"></span><span class="bot-figw"><img class="bot-fig p-stand" src="/res/mihomo_bot02_full.png" alt=""/><img class="bot-fig p-sit" src="/res/mihomo_bot02_sit.png" alt=""/><img class="bot-fig p-sleep" src="/res/mihomo_bot02_sleep.png" alt=""/><img class="bot-fig p-cheer" src="/res/mihomo_bot02_cheer.png" alt=""/><span class="bot-beam"></span></span><span class="bot-fx" id="bot_fx"></span></button>
					<div class="bot-say" onclick="bot_open()"><div class="bot-bubble"><div class="bot-msg" id="bot_msg">上岗中，正在做第一次巡检…</div><div class="bot-sub" id="bot_sub">点我查看状态、和我聊天</div></div></div>
				</div>
				<div class="mh-metrics"><div><span>PID</span><b id="st_pid">—</b></div><div><span>内存</span><b id="st_mem">—</b></div><div><span>已运行</span><b id="st_up">—</b></div></div>
				<button type="button" class="mh-power off" id="mh_power" onclick="mh_power_toggle()" title="启动 / 停止 Mihomo"><svg class="cookie" viewBox="0 0 100 100"><path d="M96.86 50.00 L96.79 50.82 L96.58 51.63 L96.25 52.42 L95.80 53.20 L95.26 53.96 L94.64 54.69 L93.97 55.40 L93.28 56.08 L92.59 56.74 L91.92 57.39 L91.31 58.03 L90.78 58.67 L90.33 59.31 L89.98 59.97 L89.74 60.65 L89.61 61.36 L89.58 62.10 L89.65 62.88 L89.79 63.70 L90.00 64.56 L90.25 65.45 L90.52 66.37 L90.78 67.31 L91.00 68.26 L91.17 69.20 L91.27 70.13 L91.27 71.03 L91.16 71.88 L90.93 72.69 L90.58 73.43 L90.11 74.10 L89.53 74.70 L88.84 75.22 L88.06 75.67 L87.21 76.06 L86.31 76.38 L85.38 76.66 L84.44 76.91 L83.51 77.13 L82.61 77.36 L81.76 77.61 L80.98 77.89 L80.27 78.23 L79.64 78.62 L79.09 79.09 L78.62 79.64 L78.23 80.27 L77.89 80.98 L77.61 81.76 L77.36 82.61 L77.13 83.51 L76.91 84.44 L76.66 85.38 L76.38 86.31 L76.06 87.21 L75.67 88.06 L75.22 88.84 L74.70 89.53 L74.10 90.11 L73.43 90.58 L72.69 90.93 L71.88 91.16 L71.03 91.27 L70.13 91.27 L69.20 91.17 L68.26 91.00 L67.31 90.78 L66.37 90.52 L65.45 90.25 L64.56 90.00 L63.70 89.79 L62.88 89.65 L62.10 89.58 L61.36 89.61 L60.65 89.74 L59.97 89.98 L59.31 90.33 L58.67 90.78 L58.03 91.31 L57.39 91.92 L56.74 92.59 L56.08 93.28 L55.40 93.97 L54.69 94.64 L53.96 95.26 L53.20 95.80 L52.42 96.25 L51.63 96.58 L50.82 96.79 L50.00 96.86 L49.18 96.79 L48.37 96.58 L47.58 96.25 L46.80 95.80 L46.04 95.26 L45.31 94.64 L44.60 93.97 L43.92 93.28 L43.26 92.59 L42.61 91.92 L41.97 91.31 L41.33 90.78 L40.69 90.33 L40.03 89.98 L39.35 89.74 L38.64 89.61 L37.90 89.58 L37.12 89.65 L36.30 89.79 L35.44 90.00 L34.55 90.25 L33.63 90.52 L32.69 90.78 L31.74 91.00 L30.80 91.17 L29.87 91.27 L28.97 91.27 L28.12 91.16 L27.31 90.93 L26.57 90.58 L25.90 90.11 L25.30 89.53 L24.78 88.84 L24.33 88.06 L23.94 87.21 L23.62 86.31 L23.34 85.38 L23.09 84.44 L22.87 83.51 L22.64 82.61 L22.39 81.76 L22.11 80.98 L21.77 80.27 L21.38 79.64 L20.91 79.09 L20.36 78.62 L19.73 78.23 L19.02 77.89 L18.24 77.61 L17.39 77.36 L16.49 77.13 L15.56 76.91 L14.62 76.66 L13.69 76.38 L12.79 76.06 L11.94 75.67 L11.16 75.22 L10.47 74.70 L9.89 74.10 L9.42 73.43 L9.07 72.69 L8.84 71.88 L8.73 71.03 L8.73 70.13 L8.83 69.20 L9.00 68.26 L9.22 67.31 L9.48 66.37 L9.75 65.45 L10.00 64.56 L10.21 63.70 L10.35 62.88 L10.42 62.10 L10.39 61.36 L10.26 60.65 L10.02 59.97 L9.67 59.31 L9.22 58.67 L8.69 58.03 L8.08 57.39 L7.41 56.74 L6.72 56.08 L6.03 55.40 L5.36 54.69 L4.74 53.96 L4.20 53.20 L3.75 52.42 L3.42 51.63 L3.21 50.82 L3.14 50.00 L3.21 49.18 L3.42 48.37 L3.75 47.58 L4.20 46.80 L4.74 46.04 L5.36 45.31 L6.03 44.60 L6.72 43.92 L7.41 43.26 L8.08 42.61 L8.69 41.97 L9.22 41.33 L9.67 40.69 L10.02 40.03 L10.26 39.35 L10.39 38.64 L10.42 37.90 L10.35 37.12 L10.21 36.30 L10.00 35.44 L9.75 34.55 L9.48 33.63 L9.22 32.69 L9.00 31.74 L8.83 30.80 L8.73 29.87 L8.73 28.97 L8.84 28.12 L9.07 27.31 L9.42 26.57 L9.89 25.90 L10.47 25.30 L11.16 24.78 L11.94 24.33 L12.79 23.94 L13.69 23.62 L14.62 23.34 L15.56 23.09 L16.49 22.87 L17.39 22.64 L18.24 22.39 L19.02 22.11 L19.73 21.77 L20.36 21.38 L20.91 20.91 L21.38 20.36 L21.77 19.73 L22.11 19.02 L22.39 18.24 L22.64 17.39 L22.87 16.49 L23.09 15.56 L23.34 14.62 L23.62 13.69 L23.94 12.79 L24.33 11.94 L24.78 11.16 L25.30 10.47 L25.90 9.89 L26.57 9.42 L27.31 9.07 L28.12 8.84 L28.97 8.73 L29.87 8.73 L30.80 8.83 L31.74 9.00 L32.69 9.22 L33.63 9.48 L34.55 9.75 L35.44 10.00 L36.30 10.21 L37.12 10.35 L37.90 10.42 L38.64 10.39 L39.35 10.26 L40.03 10.02 L40.69 9.67 L41.33 9.22 L41.97 8.69 L42.61 8.08 L43.26 7.41 L43.92 6.72 L44.60 6.03 L45.31 5.36 L46.04 4.74 L46.80 4.20 L47.58 3.75 L48.37 3.42 L49.18 3.21 L50.00 3.14 L50.82 3.21 L51.63 3.42 L52.42 3.75 L53.20 4.20 L53.96 4.74 L54.69 5.36 L55.40 6.03 L56.08 6.72 L56.74 7.41 L57.39 8.08 L58.03 8.69 L58.67 9.22 L59.31 9.67 L59.97 10.02 L60.65 10.26 L61.36 10.39 L62.10 10.42 L62.88 10.35 L63.70 10.21 L64.56 10.00 L65.45 9.75 L66.37 9.48 L67.31 9.22 L68.26 9.00 L69.20 8.83 L70.13 8.73 L71.03 8.73 L71.88 8.84 L72.69 9.07 L73.43 9.42 L74.10 9.89 L74.70 10.47 L75.22 11.16 L75.67 11.94 L76.06 12.79 L76.38 13.69 L76.66 14.62 L76.91 15.56 L77.13 16.49 L77.36 17.39 L77.61 18.24 L77.89 19.02 L78.23 19.73 L78.62 20.36 L79.09 20.91 L79.64 21.38 L80.27 21.77 L80.98 22.11 L81.76 22.39 L82.61 22.64 L83.51 22.87 L84.44 23.09 L85.38 23.34 L86.31 23.62 L87.21 23.94 L88.06 24.33 L88.84 24.78 L89.53 25.30 L90.11 25.90 L90.58 26.57 L90.93 27.31 L91.16 28.12 L91.27 28.97 L91.27 29.87 L91.17 30.80 L91.00 31.74 L90.78 32.69 L90.52 33.63 L90.25 34.55 L90.00 35.44 L89.79 36.30 L89.65 37.12 L89.58 37.90 L89.61 38.64 L89.74 39.35 L89.98 40.03 L90.33 40.69 L90.78 41.33 L91.31 41.97 L91.92 42.61 L92.59 43.26 L93.28 43.92 L93.97 44.60 L94.64 45.31 L95.26 46.04 L95.80 46.80 L96.25 47.58 L96.58 48.37 L96.79 49.18Z" fill="currentColor"/></svg><span class="pi" id="mh_power_icon"></span></button>
			</div>
			<div class="mh-side">
				<div class="mh-scard">
					<div class="mh-ch"><svg class="i" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/></svg>连通性 <span style="flex:1"></span><span style="font-size:11px;color:var(--mut);font-weight:500">每 5 秒</span></div>
					<div class="mh-ping" id="mh_ping" title="每 5 秒检测一次，点一下立即重测">
						<span class="mh-pill" data-site="github"><i><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAMEUlEQVR42tVbe4xcVRn/vu+87mvm7p2d7mz32a67W0LYxbZQ2kWy0aAiIdgG+o8ESSACEf70Ef6xosQHoP8RU8BADKDZhKAEDA+l5SWVilJURB5SChQUKKW74O7M3Hv8g3PHs8PM3tlntzc56bS5c3q+3/kev+8xDJb+IQBg5rNO/xERgYhg27ZtucnJybU9PT3dcRx3O47T2dvbW0iSxNu0aVPy5ptvllvdcykeXGLBEQDiVOC+vr7OY8eOfbpSqZxRqVQ2xnG8HgAKSZK0IaLSWjMAACKKkySZIaKjAHCEMfYvIcRfiGhfe3v7gYMHD/5b65rczICQwCp5yCxARBgaGupua2u7Wkr5IGPsAyLS5sDzXoioGWNHpZQP5vP5q4aGhroR8RP/7/F6MFVLIoIoisaUUrdzzo8ioi1IDAAVAKiaz4m1tHWb6YrNuxXzuQYG5/yoUur2KIq2EZGtEbjSwqf2CF1dXds8z7uXMWYLXTUrWejt14GT7qcBQDPGtOd595ZKpTManWm5Hw4AMDo62iGlvMkSPFlCobPASAwQieM4N42OjnbYZ1tOlUcAgDAMtwshDhlVT+zbWcFVBYAEEbUQ4lAYhtuNf8DlMAkCANBao+u611u3XjkOgtevSmoWruter7VG+8xLZu+bN28OHcd5wNx6tYFjW2nB6x1mFRG14zgPDAwMhEvlFxgAQEdHR0kp9WcL8aSJSlZXSPWrTQCpAIBWSv2po6OjtFgQCACgVCp1MMaeqxeeMfaCEOIRzvkLjLGPrNCX2OFrqW0eADQRacbYFOf8eSnlI5zzl+pB4Jw/VyqVOhZqDggAtGHDhpyUcr8RLhU+YYwdGxgY6ENEmJiYYAMDA32e513sOM5Dln9odku26torbsAPZu1l7Pz+tra2iwYHB3smJiYYIkJ/f/86xtik9f0KAGghxNNjY2M5i6W2LDxHRFBK3WcOULYdjuu6t5p3xSyVIYIwDD8rpdxn+QqbCLV627PIEyJqpdTe3t7ez1gECOwzuK77izrHXAYA7TjOfSY68FZB4GbD6+qE1wBQJSLd3t6+PQUq1RZjawQAsGvXLu667g02DSYiTUQJY+xdIcQrUsr9APAYADwmpdzPOX+ZMfYfIort7zHGdD6f/04d82NWuOMAgGEYXmCBru2zK6W+1ypPYAAAhULhbKPKn3B4RBQXCoWT57At9nFagJDL5b4hpXxGKXV9GIbb29vbTxoZGYl2794t7JskIti1axc/9dRT24rF4nAURef6vv99KeUez/O+2iAjbOSrTiGiuAHFrjDGdKFQODvLKSIA0NjYWE5K+VoDZ5YYTj7tOE5vhnNJtQIaqGz9O03t00p8WJazjqKol4hm7LNa5pRIKV/L8gcMACAIghuakJwUgBnHcfpb9K5kqR6z/nOcg2mmN81bzPiyAKjJ4vv+j5sBSgCAw8PDJ3HOy3Nw+oSIdKFQ2LLUbGuxLDWKohEiSuYiTZzz8rp16zbYGlq7fUQEz/PuzKC4FUTUYRheuhLJx3ySsyAIdjRwgp/QAs/z7jSmxWYhWCwWhxlj5QxqWzX29IeTTz5ZrhINYCZk/9riF021gDFW7urqGq7531SIqampK+M4FuZFnCsjRMQojmNlNsbjDIA2DvM9RKQMfpPEcSyOHDly5SwTHh8fDzjnbzdxIPV29H53d/fQKvIBCAC0e/duoZTaPwcLrcnGOX97fHw8qO0QBMF2Qz7mYmtVItK5XO7iVWT/syJYT0/PCGNsJsuMiUgHQbC9FmuVUrfbHLoZF3dd9wkT1xmsvocDADiO87MsRw4AieM4tyEiwM6dO13O+asWaWjIzU34O3ul62/zLct3dXWlzjyZI8/QnPNXd+7c6UJnZ+dpRFTNSEy0EOIfExMTbBU4vTlBICKQUj6a4Qs0EVU7OztPA9/3r2olfrqu+8NVaPuNzAA9z/umlcI3NGlE1L7vX0WVSuV0q+vSEFVEBNd1H1mO1tQyhETt+/5Thuw0jVJaa6hWq6dTHMdDc7TJtAGgIoR46QQBAKSUBxFxxgCgm7UEkyQZIiLqzgAAAOC9Uqn0zokCAOf8Xa31u3OcN5W1G4jogzkIUOoxX9mzZw9fhobqcpAi2LNnD+ecvzxHZEtrix+AlLKSFQGI6K9WvX3VP1prJKK/ZYR2LYSoULVa5S3EluCKK644YTTg5ptv5kTkZ70cxzEHznlW80ET0Xv9/f1tJwoAfX19ERG9l5HbaM65JgCYbsFZRNPT090nCgCTk5NdABC14NynSWv9UcamVa01Tk9Pn96okrIa6XCSJFuMz6pm+IqPCBHfyghvqLWGmZmZHVb3Z9X6P0TU5XL5AkPuMKOG8BYR0eEWUNWVSuXs9evX9xmbolV6+0lnZ2dfuVz+XEriMpz7YULEA1ka8LHDjL3Dhw9/q5WNjyMA+v333/92HMduRmVLAwAwxg5AGIYXmmJInNWKJqJysVjcvFoLIp2dnaczxiottOxjU9y9MK2nT2WFDCstfmHLli35VVQXqM0vCCH+mUV+rNA+FUVRL2itUQixr4Uv1lJmIcTvtm7d6q4CTeBGeE8I8fusGkDdRe6rsVvXda+dx8hLOoTwxNDQULd1C7TC9s4AAAYHB3uUUk+2KLxd37i2tlt/f/9GxlgyR0JUtUZRakNRSqk329vbv1zXw1uuqhFa+wMiQqFQ2KGUOjwP4bWZb0j6+/s31tDUWqOU8ulmE1+IqBsMP1bTtrfjOHcXi8WNFhBQ19/DRdw0t30NIsLatWs3KaXuttro1flMmQghnrYLJmlr6bK60lhsVOW3hULh877vf8X3/ZuFEB/WjaykGWNVKXVPGIY7xsbGcnVgLO7qEWFsbCwXhuEOpdQ9jLHY7vzOZ8zGeP/LbB+CAIClUslnjNlt8dig9Vjq8BARhoeHT1JKPVoHVtUehOCcv+667i+DILi8UChsGRwczM83j9iwYUOuUChsCYLgcs/zfsU5f71u7ni+A1kxACSc89dGR0f9+i41BwDwff/qumJi2kl5o6OjY1v6hXPOOUcJIR6vO0hijcTUTEcIoXt6ekbm0Uki49w+JYQoNzG9hYzlVRBR5/P5qxtFLwQAGh8fdxhjL9YNR6Sh7521a9f2gZnJ6e/vXyeE+KiJ34gBYMZMZ/x9jiGJObQegTH2lLmMmUVOnqW3/+L4+LjTzC8xAIBisXieNR4za9ZGSvmQsW0BAFAoFC400aPR8OQMAFQ457+pb0fPs+Orl2D+sEJEOoqic7MIHENEkFLe0YAXVIhIt7W1nWfelQAAa9as+YJS6vk6Va0t13Xvt6a0WiY4phR/1xKM5Ka85c5WLgIBgEZGRiIhxKE6dlgFgEQp9bglEAMAuOSSS5wwDHe6rnuLEGKv53kHpJRPKqXuyOfzX1xAJzkF69ZFApCyvkMjIyNRqyGZmZGTMxlj9XP/VaNKX4L/z+iRHa4QETjnQESwiFCYAvDzRQCQAECVMVZZs2bNmfPNXTgAQBiGXzOhp2I5xoRzftiaERAW6eEWILOY2woDkKQmGwTBZQvNWTgiQhiG37VAsNXqdRMaZ02YmiUaALJSANSEz+fzuxbgfxo6o+vqBidj+HiKs6yU+sn69euHm4W6BZrBQgFIUjP1ff+6VoTPOh2a3mCcy+WumZqa+kGSJGBVW9C0ospE9EcieiZJkrd939eTk5PAOV8PAC9NT0//1JhCPA8AqgaAS83nrFuMAYAREXied82HH374I/OzvGQp6pjMMMWLGGNTdaPzDZMn6+93LcAG56sB6a9GpvL5/EXLVazhhihtlFI+2+BHTCkRStd/zZ+3LCMAtQglpXy2WCxuXO4iTa0C43nejRYLbDSflx761kUA0IwHVC0/lHied+PmzZu9lapQkVWQ2CqlfNjK0hLLNMomDt+2UADMd6tmL3tvTURaSvlwoVDYWvdr0pX91agZiz9fCLG3Ll2NEVEHQXDlQgHI5/NfN/4kttNtIcTeXC53fl0lCo9bKyoFoq2t7SzHcW4hojeIqKyUusPkDLSQ4cfBwUHluu5dRFQmojccx7mlWCyeZQm+alp1s24gCIJiFEWn1B10QY1ORIQoik4JgqDYSAMX+/wPXO2F8vdcztUAAAAASUVORK5CYII=" alt=""/></i><em>GitHub</em><b>—</b></span>
						<span class="mh-pill" data-site="youtube"><i><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAJkUlEQVR42u1bWYxcxRU991a9pfv1zPTM2Ey84ATbOB9AIALhhCWj5CdsjpIIR0iQTYqESMgPKPEP0DjJJ1IkFEWKIAQSIiWOAh9xEMKRHMCYxUZAFltKRDxexmPP2J6lu1+/7ldVNx+vezZ7LAzTM9YwR7rqt+lV3fvqLlV1GljGMpaxjGUsYxkfFgLQ9GMRyaR1XCqxlErculZqnc9xf8Y7Zsu0ttqvWKnE0t+vBdC7AS2AmuxgdqxavSEsZM+mQJnRedL4gNrR7JsALICS/n69Y+tWdb53zP6izICT6ReZM8mFgHVAkmTnYYhSuczbo8hBBL+KY+8WoDAC1P8CmFuB8NLaaDGInUuSpGYPHXJcHo6iiuXKv1+vBCs3+Nx1SRc6fFRGR8dVZBqSXyWydkVRrV2TVnvXJjnAChBaID4CVL8YRSbrebPraQrU64wockjTqeutZ+r1ydH5KEDbATenAZpf1aKzA0O/fmpztHNnPwYG1jlrI/LDboj0UHmiRsPD46J0hGJxNVvrUSMxttGAUl4nBX4XaklikyRVxDnJBV1krKAWJ2g0BFrnCMIUx1VR2qcwzDc7WoHAgAiiCOJ7ED/HILHihR5YEk5NBXEyYT0G5yLlfM+gnoxLb283W1d1STKC3p4AggbyeXLOjqiO/HvxV+96u+/e7+5BpQrJzCLn8mUFAAOvvHZnectte+ur14jkciLMIiARYJrMPv9o4ubxXTOESCTMS2PVGql85Y5XTr7+6k0IQ0h/v56p/NatClrj1M8f+068aVMigBjAWSA14ExImUmZOrdnCWvXOk5JOTOXgOe+dw5pvsueQ8y03xliwakBpTZzaalu3NAYevbZn00P0mgFiGO//+1dduNGMYDUlTIpK7HgpSGkJCVlBJDapz5ph57/wxYAme4C0KBIfvz6zYMCuFRpY8BiiJeOAZpiWBsBZPRzmwffESkKQGo7gG3l8vd6XnjpLmeMJSd6sdJa29OmCAvB5EbHunR57HC0Z+9+hlbw9r5xO+JyKw4u8cqNgGpV9Mt7boVS4EOpCfWZMxsBoVZRsbT1JwUIqdGxz/zTmA2cAB6besdchdFShUpNVwgQ54YOX8rG5j5ucxhKaiYAzrB/4gRAHLXf5GpmmbrYrpDEMvS354nV0ZMNShLbzsYcEaxNQWIzQ1wEYCvhqn8cCrl+9CiQpu35NEQgONgVvUgefgj1YhFi08wIzIs5hQdrnROtP8Eh2TWe1mEzQbTHENYieORRyNv7Uf3612BsCnIG0GrBwy41J0Oa2csHqsgyPJFTqZk5R2xHw6dGkFu/Abk/P4d0xx9R2Xg5rElBggV1CxEBADK1uph/vV9mVxnzxKStu+1rWWvAOeg0RbT1Gwj2vYXkwQdR1wqwKWiBgiS1XMA0SPV1XMbeof/WyLpp3tHOyMOAUhBj4BeLiB57DNizB7Wb+zO3EAsovRAxwGlm0LGTmiXf2QdxresLVIUoiHOg1CDcfD2Cv+9G/Re/RLzyEsA2QK0VqPb6AjA2Jkysuxfg258zQ0AriLHQEEQ/uA+8fx+q37oHDWeaQVK3zy2cQOJYWDVS3VzaXXAbZKOBIURAmiK3bh2iZ34H99edqF51BaxpgMS1YzQIAHDUuYKtbVBbg98FBEmxFmQMwttuh//GW6iVHkE98CDOZEaaVxM4cKNWYJGGlxngIihTm0ESxsDLhcg/uh1y4CCqt34ZDvM5Eihb2RwfT1grP98MghfRnFVAxFnKOjEEKpdBNN9OSuBcjhjWxiDGYoWAmYHJgURAnofkxBCq994LuvEm5PfsBQth/j5UtjjuPOW0A48vZl0+mZKsBTwPBkD9qd9AHnkY+cFBMKtsyLr5H6W2u7eg0+HhYTgHAXhRooC1WbpjRu3dd2C3bUPw0i5oAKR8iDXtGZ2KgSgSVmvX5qD1wqdB5wBrQVqjUalg4uGHIDfcgMJLu+ApDyDVVL5NFbETuKFj/9FuVV+w4AnAGMDzYAHUd+4EfrwN0cEDYBBEedmoaHO+cRBQd3edOfBPSRYDqO2GcA4QB/E81AcGEN99D3jLFuQOHoBSPkC8EMpna6NaAx1FaOcVRq3yRAOwIFC7PMEYgBnGCpLHHwf/5KfInz4FxRoCtHO4n12CC0C+D8l3GG1XFhieouaCSNsadSt6Eb/1JswDP0L42qvQAKA9iLFYaDAAwyzUV4y1u3R9J3yv7fPA+n3fh//004iMAWkPYh1oEZSXLNiTSU1sTiUDzJ73vzQ1Nc4YFjLf+V3A4NOnkX/ySQTGgNgDjM022Bez9Ah8Nlet87iysTBCRHFbJ3wgsPIgpLJN94uh2vZ9mN7VSuPymyFa2wUpeC4iEFHsrr46Zm9i4jrp7Ipm8G6w1IltAIwZK3d3n2bX2bnX+v5oa5KIjwmsF07kAcMbtB63of8yAAfn3FJXnLKFTzGXrTu+yffrDGvhbvnSTnR3c2uauKTVhwM6Oim96fPPIU0zXuARkZ6xG298RwAxrNOlRo2ZTZEZ+0L/+0dEcgIQpFRiADj64otXV6+4oi6ApKRSQ8otGcVJuZbytSuvlGO7dt3RYsNO0mJBhOPP/enblc9ec0aYxWVUOWNBU1S5ptgWTW4mhW46Ve0sOts0ytz56XPnpsJNf4+dTdmzNKtvk/Q4Sg1gWjzE6rXXlo8/88RtUGpK+RYm6XJSv6byzbt3xOvXJ9LZJaJ9EVJT0mbS5IcXEkGT1ElKRHlZ37u6pLZ+fXz6/vvfOz4wcCem8YvPpsqWSkzbtzv4Pkb27ft09MQT1zTGx69zp0Y1x1WrymWD0C86oi4mDqRSbaBSE8p7PRJ1XuImJsoUx0YVu9ZCxMfYmQmqG4fAK7DvF5xzCnGtKp7OEcgjY0WUIqgsAYtWTI3GBNXTquvsKMD3WZJ4jIPQWe0TCVIJlGPrJsj3nEvThtTTCekpklgbU6NRU319BTs+PuiUl9CaVaFa2fOefeCHbx5Yt2noBqLapI5zoZRR2WcMj34Rjc7OKaaH1pmo5haW5wGFCAgCwPOwVUSdFCm8IBIgCPCCSDAi0vG+SNcOEf+gSMdhke6WjIl0D4qsOCyyerdIiFyId0WiIyI9+0U8FCKgowDk85kEARD4WbutpXTmLIP5/vl2humC6PK7m3T5JhWdZYo2P1t42jN8Xjr6R9/ZnWxnVh/0tP41j/v17v5+3fo/wgeiy89lOSKSC/oTRXO2R0Qyo3Gi82/DU7YwJdOeuZC2l7GMZSxjGctYxgfG/wG+GtEK5LVFzwAAAABJRU5ErkJggg==" alt=""/></i><em>YouTube</em><b>—</b></span>
						<span class="mh-pill" data-site="baidu"><i><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAihUlEQVR42s17eZRdVZX3b59z7r1vrFeVqqQqNaUqqYRMhBmZU2GSj4C0jYl8are09ifQ4oAg2th0JaAoKmKrbYsjio1tpQGZbECgQhsIYMVg5rlS81yv3qs33eGc3X+8V6EIYRB7sb671lvvrXvvu/fsffbZ+7d/ex/gf/NgJmamo0/fddcL4e6+/H1dfd51ANDVlalhZlX8y2vvb2tjMX1t5vGb34zGOztH5jKzbGtjgf/fDmYW08IwT61i5tXM/Etm/rRtAczd56SSB65mZpqY9G4ZSRUWTf+3vz/XyMxqpmDMbDFzeelT5tgAM8uZ79y3b58zMJC+squrK/ROx03/S8ITEXFbW5v67M3rHu/uyr7n5S3JRDLJcISAV5h85gNXLXi5uSH0JBE9t4/3OYtokQswpVKYNZWdavddfWVzc8Xk9u25hqXLw5/buiNzyYsvDNcM9E4RyHiV1WUvXXBR/YETFoUe2rkztcO2R7LV1dWxdJb+w8sHH1iwYFZqehzvqgKKLwVSKbT4Erc9+sjQVT/5fg/6xhz2TEhLI6mi3JeNzQE+sLZm5KMfmH3leHb4fCsa/GsZ6pI9PamEsK1FDXOjL3V35xfEy0NPPfX0+Pxv/+thjIyUgUwUDINwTKNqzhhuuXE+Lm6tWO95ww/AtsmhWdv+kvHTXyo8ADp8eGROODJnx333DVR+7/sHg0h8obSUJIIGs4JhrQtuhiWNqHVtC4avWjPnrzZu3Ni5atWqYPpZHR2sTjoJTz/06NjKm2896CYqaixbBQRSABOMIZMvsLHUhPybq/T+L996+mI/MGBmQUTmncog/rKZF7x//KVYbdOsL/7mkanKf/l+fxCvWqBIERmTA3MBjCxAroxGQgqiNrjnR6nqx54YX7Xq/FVB3h+6cGzM++eeQ7mbWluxePtefd6dX98eVM1qdhwRE2QkkQaRAUkmGQuHLaK5+NX9uYX3/rr3WWaeT0SG+Z07xXf8RyLi9vZfy4WV78nt3ldY8tBDQ7BjsyiADzIGTAIaFgwkGAKBMZCOLfqHlHnuuQPXseF5BD9BzOeATf1Izqz9zSMDVHDnQEofbFyAFcASKMnHnIVjsfD9ejz91PiqgbHgv5i5bN2610eTd8UCdu7cyQAizz7dt7inp4Cw4xC0ABMDMACO8kdGCMEh3r83qNu0eXiho+ofY5r6u4b50bZ9O5PXbf79BEKhSmk4wLGsmiAAbRCJVIiOZ9Pujj8FiwBcvH49mY0bId9VBWzYALF+/XoD4LRdu2St68aNAAtiWXQtxK93MUyQwsZQf4JGRvSnAUSrqqr6ARw/MsRVQ0O2EVaMAH3swRoBwRosNJjrZcezoxqA+5f4sXekgPZ2lmvXkk5PeOcODOgHd+32yXaixCYPAQKDwMf0twGU5cuJMcfk3PDlGvjYI490RgDs3bZ9YLcKl1FAviEm0OuWNQNsgVhDi3FWoZDYuyfl9g5lugCgtRXmXVPA7NnFqVUhq94tyLJU2mUol5hUcZDgN/AbGkwuAhBNTvjQBuWDW4rS9XZnUkSKGHlmTFvP0c8xYAiANDFcA4QiY2P5CwBg48aN4l1dAgAgJTiXBcMYQBWgEYaBhGQNweJ1AhAYEAytfFgg2Az/6V2HAgC6sbbuRD+joaQrjNAwdHSUJrDwoMkCdBkUAYU8w7CcV1TAu7gERkeLkhHlB4l8tkWUSDsg+ICYKl48VmTiooUIYYhEELh507xgQSQKoEAUTFgWQEYBJvTGsIUCAASjBWzHRyJu15eWwDs61NuFuTPCjCieZgKwWahsV80cZ8HhHjZCQhhRAHOkGL4QHDWLAmwMhyJM0TKddmLivgsuOFEA4Ejc67MsWWuMZaSxJMh/QwUQHBhTQMUcn8tnhV8uXmvF0VB45tjfCCKLt0puihi/QxERlz6aiMzOnbCIyKutjX5n8VKwm08ZhfBRM8+v+U0EBEFgEhWSZ82JblNKPHPRRXUTANSJp1TU2k4BYI+KkYRnPGP6twRgQCRQcHO85MQwVZXJQWampiaoopDtcuXKDlWEKsTMrN4sPxBvAnQMEfGaNe1y/fpVATPbpczsgsODyebly8ljZlFWhq6VF1QQ0RQ4cIozT9MzbxW/uRgCAQnXd7lpfogWLU4E/f1/WtHZCUVEmebm2T9unh8znucbIg2QW/L8smRNDGYDFhpauxyPk3Xa6TUugH1ExM3NVChmi2v1c8+tChxHMDOHiCjo35OuGh3l+JFY/GZLgJlpIyDn9W1dFo22nF1eEf/kjbuT23/9yL6TgqyaU1cfL29ZGu9m5lVE1MXMHaedVrb1nNayk57bOK6js8qlNmkIYhADRB4AhjAKLKOcD3r4vRdX6KZa8bSiFdt37GALABY0yN+fe5YJtmyG4LkBmPMQvgNwuDhmkYeRGWiSxhR8nHu2nmiuD1/WtS2d5lGOmyrccnjAv+yH9x3oGh3KFRqbQ/UH+rNzmPn5iTGvO5kavY+ZASBD9CYK2LABYu1aCkaTBy+cTIc/eu/Pe5Y++8zk0uG+crg5H0bsCZYuT8z76w9WPMPMFxHRwXSBb7/u+gX3b9/xBzE5UYVovFZq1Q9mBkwYAgJkGYyO7PY++H/LnNUXNd6tiO5s6+hQy5YhYGbZm0yOXvH+Rvt3T23Drr1RE6toEEalwWKoaJFcBgQV2hsXZsmyMXXJ5frzcVVIc5X10CDQ+/SvBy/++b0DSCUbl8OrQyC7MXvOAfztR2oXrLwo9uGWljn7B/bx7NpFNPWGDq+trU0AwHBm8uLtu3ngQ1dt43nNncHC4/uDxSdN6KWnDJllp/Vz88J0sOKEw3zbV/fvZvYvTCZ3nTwyqe/ddYD5r9Zu46ZFL+qm4/b7LUtG9aLFWTOvadCva/6Dvub6vbx9+8RPmDnEzPJo/D4+5d34fGemcOllW7lx/l69YFkPz1/SGzQv7vHrF+4Plizv4us+0cs//fmBjzIz9ffl/rPgMd9y2wGuW/hk0HJCj1544mhw3KkH/eNOGglalo/puc0vu9d9ZltwuI8/z5yuam9vl8dMhzs72Xr0lHX66uGbT49GI5u/eOOf0PG0b+KV84THBYCygIkXrdGehJmq1mFnVN74xVjnR65suLP7cO7Lc+aGBvd2p8b/+PL4lVv/SOjrSyNwXSxYGMUJp8Vx4QVNd7fUyc95nqGSgzXd3ZMVwsJdDbWJjx/ue3l1VU3znMMHy2958uneBc9vmgxs1CipgJp5BTTUic4176+6u7Y6tuHedZBXr8Ol92+Y2vCFL+wJKmYvsH2tYCgPIcZBJgyWPgTH2Z206dLVfVPf+dYJH123Dg+vWweedoyvy6AKAX/+sd9mv37TjVv9slkLLNdnCOFCaQUyEWiZhZZZCMxGfipjjj8xJe776Qm5qcmpO+try26bGg/WqrD8XM5Hz0Qyc2LIptn1c6N3ANhMRJsAJuZiNlnyOU7PQGrlvLryp4aHU2cFrr002uA+YCN2/cRY8GnPy305HnOqq8oiLwAY8JBxD+5ODS1ZIs94fkvZ+++4bfTjXQcRyDApzQoMAaWLYCxQWQQiAuNF/PLYIfWxj8V+cd3HF129cmWHeu65IhehpgmF5CBfnRN79w+P+Jc89OAwC1UjTGBBwgMZWUJieQAGMqiEYSAWD4mtWya8TZuCyKUXxV9kZnu4pzDrYOfh95393paRUp4eIqLczByiqISi+e/fP+4sWlT1FAAEnlwZK7P+IdmtH89m8w8mEnLv/PpZ7TMnqKuLQ80L3A8B4aWPPzaw7HAfoEIhwRxAkFuMOELAGAtkohAIIK2kSqYqTGdn6EJmPnXdunV//OQni2MR01YQGL26ds5s3rE7E+7qYrIdBeY8CAaAgCGU4KkFkAsh8gAbEOLihU1jnM9j7kDv5GoNf/Ds97aM7NvHTn9/uqKnBw4zK2ZWa9aAOzp4JqbgWCTyra7u1Hd+9rOuUF1D7KtPJh5samqKDS5bFt9ZXx9pb29vlx0drIo+o102NcH1XfcRH5HeVEqfMZU1AYQUzBZgbIBtMCSMMGDyIRiQrIiNbcYmqG77vtSH169fb5LJLWI6CjAA5N3Cj4FZA309hxtSSYZUlsAxk5pX01xmhmVZOHAwTf39idXRaP6TrislM0sicgcGspdJyn1lfDxyelUVpaczGma2AEQBRIDgcceJPOS6k7MuXr1raR0t/ePg4fTNkPTyngOxTaOj4FWraAZ11qFWrVo19sIfBtzuQz5sNRtGBzj2WGn6hXAciL6eFB8+pE9nZnvt2g0aAFSJUiIiepKZI8lxdrV2IC1ivCXLYiCEhcmUh4LvOQtra0dnXq2tjT6QTPIzFRWUvu+3+8ouO29hi1T49L7DhTO6DqSre3pd+D4V7vjGzg8/8Jts5rzW+duYuQrA9zZtSjmtrWAioY/iIDUzVz7732NfGh0mCCUl4L910iMg0qmAxsb08QBCGzasTTMzHY0DHGmpal97UMIh1m8IlI9omIjgaom9B7O/Y2b64Q+3qGuuOdUvRpZOq6KCJvfunTh3/vyKB3ftzpU9sXHcfv73ozh8SCGXj8HARlksdmU07OOhh3px9jkCF10y9zvnnJO4kYh0B7NaRRRM+wwiYqUw/vDjw2W+r0DSK5IvbzpXomgM5CBXUAGAOID0TCBE/cxhANWVCYchp0q6oRJaFkdmHCAw2wAZAB7MdCCRrEt5A8+gy4MXdvTMqqqr+PGTT4xVfeMbe/jQQFyHwxUk7RBZMcDAQ15bOpd0MDjgYfOLg/KJJ91Pr15dbZj5ESLqmMn8dndPzm9sTFz+xNNj0nAACAYzg44KaEzFjJSgIeCB2IaERiRkUFJAUTXT8Xi8p8cBsD810v/v5eWK/MDRr3kkSzAAQwyGBIOhhYZmjYqowAknlP/10WkpM6wzlzW8b8OG3kWfvWlfMDLRjIqKOdK2bSE4IBEEpAJBirWyVE5FEkZFE3OxY1dc33tf/2f/87cjz2YD/gwRmcHB7OnMrISQTdmsf148bmWckA/W1jFTmiIjKUBMIGhAC0TsAHW1IQvA4SMKmE4Xq6zG+QAqz76wZnsi5mp2YwSOFB9FbinBKaW4chIQeUg4gM9UVZU3zbXRnxW5glZua2OxeXNvCIDzzW/v+9vvfHMyCIUXCxli0loXIXLRJl/zYcMwWlM0SnJ83ApuvXlAb34e33aZr/JdPm9sDOGGhvizsZh95ewq5w/zGkOs81LTq74cM2YWIA1NNgJUIONJ09AS5XnNsa2DuYPL29tZEh0h3jZKy0JtwR97/2knVVUuXmj6YSakkIL5CNWmS4RGFMQCwoQh/KhxlKb6Wu+QBH4FMK1ZA9PaCnHmmTUnbXoh2f7wg7lVsBLSqEAY7bwtksIYA0vVKM01+PLtnXr79uzXG5ti38xkCpWvvDIYBYC6utC+95wZI78wCCnEMVY9gWCKJJqykHf7zHnnl1FTjbM/M5LR08u09M9WrRT63Jx5GrDaP/7/5u1paBnhnDdkLGUDJlwiI3QpOycojsLLZ/XipUacv6r5USKgrQ1y505Yq1ZRkC7ISx5+ZOqSnr7ZPkKGgEmIt03dE9gECMV82d3t4Jf3DTWMTfEvhHSvragoS/T3p6uiIfzHua3Rrtr6JPm+b4jEDO5gOo1mSMsgmxnRK5alrPPPD2cLmWSyxgsXioAMRQUQEVdU0Nby8uqDRLT35BXlN1z/mUUEMcS5rGskykEUYqiAoXJMIF3IFwIWXdall8d2nXNO4r/She4l134KJ5d4grW/+MnItb95JOnHKiMq8KIQ7KAECIFiWoo3q2IKOQUOCPHEHPnwgxn/pRfxN40NidS8edGBiBM+d6Rnyjl9RcU/3XDjGTI5MeJrHbAUDoQIQZANQVEAtpmaGjd1NXl58w0nDJ+4KPR3k2Ppu+K06NARzuOoGAsAkoiC4ZT+0cF9+u+/dvsr2L0nzL60KKAcpFQos+JY3Cxx4UX+lk9cM7+ViDI7drBdEv4jv3s2d9+NN+9CoOexkHlitkHSBSECpQUU8sjDQUAF2KbkVF9H2jAgCiA48AtOUNXYTzf9Y83ja89vvGLz5qlGWRlOn9i0MTOebv32k89MfvKur73E4yO1milB5OSEDiyuSATilFNTuPKvGn952SU1nyGiibcsjra1sVi3Dnhl3ytzm+uX3ZaaEKtfeHGkesfunnwuXwgpGZ8Kh8ST/+eSeX8845SKp4moc3ycz6yspM3MfO4rO/m/r79mux5NR0g5CUHGBRkHeb8PWhvYgYDgHBCpAxwHljYlwujoKlIEEIUSmVLGBR7k2ob+zK1fXHHnBWfbz2WzqQWZ8ZoBj7JnxKoS5x3uyqzcsb1gd3UlMTQ2gvr6CjTNi3S+7/JGHVPiaiLaM+IXLlMKmEWhx9qZ5VoiTa9nhEBE4MGpA3PmxltGmEfjQNUyAAMAKgGMAhgExqNEVWlmpocffjh2xRVXnNr5J+/H//SlXc0HDpZxOBYTOpAQMgvoAq7++zDmNwFuHog7Br/YkEPnVokyuwya9TEUEAaEC5AHmBgEBPsiSQ2Ng953v37yL49roZNTyYkf9g3U/aRkeUsAHD+Vx5lK4jpp49s28KWNG0GrVhWB1CSClQSeKid7yzS2oGORoURk+vpyZ0qgfm59ZMPM693btlXMW7EiOZ3d7dy5U966bvGaLa/4965ft0ft2RMx0XIhjB+CMXGQNQahx/Dvv1qKFYsipUpWBDevewX3/4oxO1aPAB4Yx1gCpIvRB7KY5AjF+XyWzjiZceNNc24/ZYX5A1HiUWZ2iOhIiWzHjp6W5ctv7AI26JkyvS1anEplnVAot1PrUFfJN8yscqSYWeWRr40Q9UgJfcZ5w213f2NYHehKBNEEKfZVEZnJLBgKFCTgTmlonUfgMZQdwLgEwWEwFMB+qZY4cyC6VB9QAOUB8iCMoWgoxM91Jnn8ju5bv9a2rIeZJ4no98xM3aPZmqY5scHlyxsPdHCHakX7NHw2M2nyt6gLFG+oqqpKT+NlzKhWlrQZZP3BTzDz+B3fOrDoS/+4b14+W2visXLl+1MgYggU4akmA0MWBFmQMgQjJaQEBMIl4XyAPHCJ8gYkiEvVZTIgrWCkBJcSQoahsrJK2r0tGXzuMzsar7++7pfMfPeTm3f+4qSmlnVD3TnLD+3/rRgPaaqih0oUmJ62gjTzYgIm4kQjx0qGjlkUKf2WAGjjxo1gHl0EVLn33j/yrYcf9JEvLIUM+fAwCUgCUxGCgiRI+BCqABJ+KSmxiyYtirpmaBAsKFKYDo5MGmwkAA2WORCCYs1RBWBikBGoLCtTQ32Cb7t9d2M4dMrd55635OTU1O9vV96pN4Z5wTKts3e1tbFYs+YIkiMA8LU+T0r5DICRt6wMzayqENH0elo4MIRf/+AHXSvuvz9tVHieoVBGBQggoaB9C37BAZCBAYHJgvE12BcAwnht6ZshSCGfJXh+EtKEYIQLZYdh2zEAGkZlishTC+SyORhvNkhkQKKASLiJXL9O33DDDvPXH1AXXfMPJzzU0BS7du/WbN1xJ1VnAGD9+mm2u+jKJpPpM/2s+7u3LI3NEJyZ2Tp4eOqypqZ4+MUtmdv+7Vv5BRuf10FZdbnyTUYQafg5AbeQx+yqEdQtyiMStwBTAQgXSmcRK/MBaFCJlCcAJAQ838PCxS6WHJcFBx6k8rH/sI+9O32QnAWmKbAWiEgPK9/rI+IUAJGDZwI8v6kfrkvStmrEA+2oOXSo5992dY29d1FT5LpPfKLTuvCeU8xaIs3MtGHDBjCzODiS9OCE3ro2OKMeGHl8U499xvKGB3ftAm65ZQ8OHZxt4rOrVcDDsEggN1lAU3MWH/7wbLSeV4O5NWFYtgXDxfhOIAikYKBBZM0gKQTyuSwuviiET113YqmWqPDLXw3g9j/2IhStQcAOOADCZVnc9pXFmBV1ADA8aFzxvq2Y6J4LOJJUxOKtWxPV67/Uf81Xvxo++557TrmMiLqn135bWxuvXbvWHBqdFDD8dmqDQ9UAaEqP3njxOXP/Zd/+nHvtJ34f9PVUm9gcLTwxCMkVcDNjWL06jX+/fzk+9pF6zG+MIiwsCC+A9AyUyYN9FzARsLaPBBM+AjoU/IINrbPI5rLQWiPI2zCIAlQAsQKEBSYXuUwAoxlGeyhMBYCWEMYCGwKsAQpFHH7phdn+F77QtfxgHz4/5futP/zhFjkwkF5ydevV9nBf5kQw+0Sv1obEG7S+IYB1EnZCxaX6eTLF59551wF7aLxKRGO2CHwJSRbyUxmcfW6Ab37tJNRUKHh+AZ5rAGUgbAnpCEhhwbFsCOGWvPyR9xQ/IEAypLQBKwopJaB8FCgCEmlI1jDCwLCCIgUhNYS0QJYCwQLgQiCA8GfB6IASc2C92BnV3/vuyCcnUvjRJZe2fJ6ZTgo3ViUA+gehZT40gz1RxzJ9ALCo8onSQMe+950/le/aZigeS8DXAcjKg70EyssmcNMXl8G2FHyfQVLAsgQGRwP09k1Cl0gU0gaLF4WQKDNgI/4X2xhpxj1FywoCjYpZIflA+96gpaWxZc3a+pury1V5f3+uURkzNR1o3tIH3HNPp3Xttaf6T27s/+cXngslLFkVaK0Vw4MgQj7j4fL3h7G0WSLQGQBRSOHgVw/sxw++24tkqhyao2ByIf1J/OLnK3DSKQq+0ZB/bj8XH5mct3W71gFi8Wb56/sHzDln1RAz1wHo6++f+DYJ646ZmhVvEAHkwMCj2hi+fMc2c113j2RhszRMRUBiogCSOPMsVVyjPsGyCC93juP2dd0YGV8B4uNA1AC2ZgN2BYwyAArvVuc2pBOi/v4otr4y5gBoJCJTX1/Zawm5yTZy6k0VsHEjaP369aarv3DVnl2Ia7INyxwxGTAZcBBBKFxATR0DJMFBMaw8/bsDcPPzICICRgyDxARYJqGJYVi9gcHNYJhfc4ZnsHt/fjePQYFJxejFFwc0gMnpdtza2dF75s6Nj0wv92M6we9/fwNnMiNzh4b8qkOHPLZCTGQMFBMEbIACCCEhZSmeWkWYOjVZgKQAkl1IUJGQNDagbQBOiVPUpRDIIMGlhkgNQMEK3BIlJiARALDBMg8mA9IRCOi37TuklsQk9Oj4rPCO/ckFpanF0W214hizLzdsWKtdv+wbISd0wdhoTltSSfB0g5KGEAqeS0ilC6WWleLczV9UA99kQKhAQOUIRBkMKgBRwvwIjmkBfCRRkyVGhotNcmSDOAEiB6wCaPpz3EYAEJCdUuRmePHMzpe31SIjoGaFHEsaPZPB9UopqoLv2zh0wCsKRR4MfLzvink47vg0xiZ2I++PI+dm4OVz8N1xMAdv4tVL50sUpWNnUCgMw/cm4ec8eIVJFIKRP6sTkoghBAFsw7KshjdqpXvdomxthV6zpl1q4d42lUViVmX4zOEJrW1FEgDISLDQEFYEmzZO4WNX21DSB3EBNVVRfPd7Z+Len+3Enj3D0EEVBPmQxkc8NO0DvCM4oNg4JaEDUeQJRbEceda51bjkQhfZpAuLFbLEiMWisI+iv7nE3hy7qVLAsIGyA55MO7+drllM5wZvigM6OpiqEvTi1j2pnsrZsbP6R3Nsq1Cx0ZEVDHuIRKP4U2cBz3UM4KILaxH4GkL5aKlX+Mqtp8ENNLQhgAwEBJScgjEBxFEUNjFhfCRfrOQIQmByaKhn/ODHy8B+FkqH4UkC2MCRGseoAb2BF7RZqYLyOZU87T3V5YODg9G5c2tyf1abXGNdmb+gyYFxGRAaGhZADMEBwAytEvjyV/ux90AKypJgbRD4WXhuACUYjgU4imApAlGkyFYHVFSEFpABwwnZ2Nw5huGUD0sBHBgYzwIFBrYlIR2GowwcJQAy0JpgDMMYFwwJDVWi08SrvA15YDsHXTB88vFRFZbhipqauTnmt9km19oKvW7dOsyK4YYFLeM7y+J5FRhltNSlqkCxZU06AoMjVbjuuu146tlBQElYVhy2oyCFgiQBSRKSCJIsCCmgnGISJJSG0B5sO4ze3kp8/avbkM8DlhMrpsOKIBACkSw+QxCkkFCSIIRE1LFgM8HSssg9wJScNAC2AQ6Roqw595zqGICNg4O5xg0bXi+veuPNEO2CiMZfemX/TbWP5R7ef3CelLFxwKhX6+7GIBSyMTBSh09/pg9nnTGG1pVxtCwGKsoSkEda+KlEfhB8LRAKESZTFiAFfM2Ixhrx2KPbMNjzPC67fC7mL4kjEQ1DTfcYlpY4iwAwEkJIZPMB3MCFFJliiCW/FE4dCMSRm/CC95yl1MLF9kujQ/kTYUzLmjW4o9RfELwl2C7xAWBm52c/7xm6485MmR2PsAiUeG3/J8NIATIW3KwH0klEQ2lYoQgMStnftJOHhkAAlnlotxaBLoeRLrQowIYDP59H4CcRDhOkbb+62omLCiAGuCgsiwCeNw+GHUhKgig4Ur0GW4a8UfG1b7QEqy+JLR3oyfyjENYDcxtCj7/apvM2+ICOjg4FwPvQRxtv6x7quuvHPxozs2bVAyY4UuAUUCA/BK2ysCoKEGYWjLsAea8AlvlX6/bEIFYgAqANSChAGBAFUOQaDuJkhcNkR0PMXoQ8X4NFodR6SyUrkMUFWMIjEFMgpIsconFAZEEjHRR0j7r6w9Vj55yjfrJ/V38snigv8+ucZ3v6pq5qrKf/aGtjsX59EQ+8Kb5sbW3V69YBDvAvf/s385744JX1SCUnAu2DhYiAJSEQGUjKQBkC+SGw9mCsPgh7ElJqSBWwZTGUZDYccNb1gnTGDZLpZJBMjQTpdNLofJnIZYnSUymT96coz8lASN84UkLJAFIWIGQGUmZgUx42GDY7sLWAbRiQBiRs9nPQFqXVVR+cO/Kpz8//bL6w44lIInoiDP+nHAAJyPp3sG2Oac0aiPZ2yKEkfvZfT4596Aff2+ENDVUJqApYIYIlCoIIRJBghtHacKAd+AFDyYIKgpwOOSzLywnz6izMqUmgrNwgniBoncfw0MR+Yq7RfmX84IEpMFdhcCCH9JRvSCgjpA1IB5YCiAII2CASpI0HZgOtlRRI47iWHN57SUXH9dc1/yswvJWo5tCbEb1ve9/g9ObIF3p6Q6c3NFzVO4CfPvXEILa8FKC7BxieZLheAUCASDSEUMRCmV1AbXUY0koGxy2pVBWVeqqlqTxTM9u8OKc6EUSi2GxJ9JU812YUG31O3bhxz54tLwXHlddEv5LLqlMOHfIxNEhIJSXyno28AYw28LwClM2IRjWqE5y+9LKod9bKig2L6qM3ZLyhFm2EmwjNOTTtQmf0QvGfvXFymiXKjaPWDYJTjYKsrFTO8Jh5X1f3pBobEysIulrZjEIe2yLR6HBNjc8tzWEK29ZPAYQAdwXgbiFKPHb084cH83frgDbVNoQeGJnInTu7IlwJoA/Ae6Y8LJhMFhpHhlwzPGJocjJA4HlwwlwtLJE69dSy+kS52z0rXHkTER1YubJDPfxg68dZ4MmKCjo8U+ge5nAC6UiCEuPvZJstmJna+JgZ5JGNzlICzB2xo+85ePBgoqenJ9zezpKZVUepd3DHjh12z/DuT/UO7m9lZnmwe/KikWTuB7sODC5/s7FYFsDcs9J1e7/e3bdzbWdn94KB3uyVzOzwG+xiZ2bVwz3hv5hvKDUuqo4OVm1tHepon9HWxqqjo0OV7hMdHayO3ZxdVOZob/qa0b7UccdSeEdH8T3Fd7Fa2dahihsiuJQEsBjpc9dMdk9WdHVxCAB6+9Nf6O2dWjVdv3wzWf4HehGBmhXhLZIAAAAASUVORK5CYII=" alt=""/></i><em>百度</em><b>—</b></span>
					</div>
				</div>
				<div id="ui_link"><span class="off">Mihomo 运行后可打开控制面板</span></div>
			</div>
		</div>

		<div id="mh_dash"></div>
		<div class="mh-tabs">
			<a id="tab1" class="active" onclick="switch_tab(1)"><svg class="i" viewBox="0 0 24 24"><path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/></svg><span>基本设置</span></a><a id="tab2" onclick="switch_tab(2)"><svg class="i" viewBox="0 0 24 24"><path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg><span>订阅</span></a><a id="tab3" onclick="switch_tab(3)"><svg class="i" viewBox="0 0 24 24"><path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/></svg><span>覆写</span></a><a id="tab4" onclick="switch_tab(4)"><svg class="i" viewBox="0 0 24 24"><path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg><span>高级设置</span></a><a id="tab5" onclick="switch_tab(5)"><svg class="i" viewBox="0 0 24 24"><path d="M20 11a8 8 0 0 0-14.6-4.5M4 4v4h4M4 13a8 8 0 0 0 14.6 4.5M20 20v-4h-4"/></svg><span>更新</span></a><a id="tab6" onclick="switch_tab(6)"><svg class="i" viewBox="0 0 24 24"><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/></svg><span>配置</span></a><a id="tab8" onclick="switch_tab(8)"><svg class="i" viewBox="0 0 24 24"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg><span>通知</span></a><a id="tab7" onclick="switch_tab(7)"><svg class="i" viewBox="0 0 24 24"><path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01" stroke-width="3"/></svg><span>日志</span></a>
		</div>

		<!-- 基本设置 -->
		<div id="panel1" class="mh-card">
			<div class="qgrid" id="qgrid"><div class="qt" data-for="mihomo_enable" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><path d="M13 2 4.5 13.5H12L11 22l8.5-11.5H12L13 2z"/></svg></div><b>透明代理</b><span>局域网 TCP 和 DNS 交给 Mihomo</span></div><div class="qt" data-for="mihomo_udp" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="11" rx="4"/><path d="M7 11v3M5.5 12.5h3M16 12h.01M18 14h.01"/></svg></div><b>UDP 代理</b><span>游戏、语音通话、QUIC</span></div><div class="qt" data-for="mihomo_adblock" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9.5 9.5 5 5M14.5 9.5l-5 5"/></svg></div><b>屏蔽广告</b><span>第三方广告与追踪域名</span></div><div class="qt" data-for="mihomo_ipv6_block" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg></div><b>IPv6 防泄漏</b><span>拦截局域网 IPv6 DNS</span></div><div class="qt" data-for="mihomo_router_proxy" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 16.5h.01M11 16.5h.01M8 9a6 6 0 0 1 8 0M5.5 6.5a10 10 0 0 1 13 0"/></svg></div><b>代理路由器</b><span>路由器自身的流量也走规则</span></div><div class="qt" data-for="mihomo_auto_update" onclick="qt_toggle(this)"><span class="qs"></span><div class="qi"><svg class="i" viewBox="0 0 24 24"><path d="M20 11a8 8 0 0 0-14.6-4.5M4 4v4h4M4 13a8 8 0 0 0 14.6 4.5M20 20v-4h-4"/></svg></div><b>自动更新</b><span>每 5 分钟检查插件新版本</span></div></div>
			<div class="qnote" id="qnote">开关有改动，点下方「保存并应用」后生效。</div>
			<div class="mh-row sw" style="display:none"><div class="k">启用 Mihomo</div>
				<div class="v mh-enable-v"><label class="mh-switch"><input type="checkbox" id="mihomo_enable"/><span>开启</span></label></div></div>
			<div class="mh-row"><label class="k" for="mihomo_cfg_mode">配置模式</label>
				<div class="v"><select id="mihomo_cfg_mode" class="mh-sel" onchange="update_visibility(); if(this.value=='custom') load_custom();">
						<option value="sub">机场 Clash 订阅（完整配置）</option>
						<option value="provider">节点订阅 + 内置规则</option>
						<option value="custom">自定义配置</option>
					</select>
					<div id="mode_tip" class="mh-info"></div></div></div>
			<div class="mh-row" id="tr_sub_summary"><div class="k">当前订阅</div>
				<div class="v"><div id="sub_summary" class="mh-tip" style="margin-top:7px"></div>
					<a class="mh-btn sm" style="display:inline-block;margin-top:8px;text-decoration:none" onclick="switch_tab(2)">管理订阅 →</a></div></div>
			<div class="mh-row" id="tr_custom" style="display:none"><label class="k" for="mihomo_custom">自定义配置<small>YAML</small></label>
				<div class="v"><textarea id="mihomo_custom" class="mh-area" rows="20" spellcheck="false" placeholder="proxies:&#10;  - name: ...&#10;proxy-groups:&#10;  ...&#10;rules:&#10;  ..."></textarea></div></div>
			<div class="mh-row"><label class="k" for="mihomo_dns_mode">DNS 模式</label>
				<div class="v"><select id="mihomo_dns_mode" class="mh-sel">
						<option value="fake-ip">fake-ip（推荐，速度快）</option>
						<option value="redir-host">redir-host（返回真实 IP）</option>
					</select></div></div>
			<div class="mh-row sw"><div class="k">UDP 透明代理</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_udp"/><span>启用 TPROXY 代理 UDP（游戏 / QUIC 等）</span></label>
					<span class="mh-tip">推荐开启。关闭时，fake-ip 模式下发往代理网站的 UDP 会被直接拒绝，网页自动改用 TCP，但走 UDP 的游戏、语音通话可能连不上。</span></div></div>
			<div class="mh-row sw"><div class="k">屏蔽广告</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_adblock"/><span>屏蔽第三方广告 / 追踪域名<br/><small style="color:#8796a0">GEOSITE category-ads-all + 常见广告域名，策略 REJECT</small></span></label>
					<div class="mh-warnbox">路由器网络层拦截，只能拦第三方广告域名；和正文同域名的第一方广告、服务端注入的视频贴片拦不住。某个站被误杀时，在高级设置的自定义规则里加一条 DIRECT 放行，例如 <code>DOMAIN-SUFFIX,example.com,DIRECT</code>。</div></div></div>
		</div>

		<!-- 高级设置 -->
		<div id="panel4" class="mh-card" style="display:none">
			<div class="mh-row sw"><div class="k">代理路由器自身</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_router_proxy"/><span>路由器自身的 TCP 流量也走 Mihomo 规则</span></label></div></div>
			<div class="mh-row sw"><div class="k">GitHub 走代理</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_github_proxy"/><span>GitHub 强制走第一个策略组（机场的「节点选择」）</span></label>
					<span class="mh-tip">很多机场规则把 GitHub 分到「微软服务」之类的分组，这个分组选了直连时，国内基本打不开 GitHub。开启后不管机场规则怎么分，GitHub 都走代理。</span>
					<div class="row-btns"><input type="button" class="mh-btn sm" value="诊断 GitHub 连接" onclick="mh_sheet_close();api_call('diag_github', {})"/></div></div></div>
			<div class="mh-row"><label class="k" for="mihomo_webrtc">WebRTC 防泄漏</label>
				<div class="v"><select id="mihomo_webrtc" class="mh-sel">
						<option value="proxy">走代理（推荐）</option>
						<option value="block">直接拦截</option>
						<option value="off">不处理</option>
					</select>
					<span class="mh-tip">网页可以用 WebRTC（STUN 探测）绕过代理，拿到你的真实公网 IP。「走代理」：STUN 交给 Mihomo 按规则走，国外网站看到的是节点 IP，视频会议照常用；「直接拦截」：最严格，但网页视频通话可能连不上或变慢。IPv6 的 STUN 会一并拦截。</span></div></div>
			<div class="mh-row sw"><div class="k">保留 fake-ip 记录</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_store_fakeip"/><span>重启 Mihomo 后沿用原来的 fake-ip 地址</span></label>
					<span class="mh-tip">推荐开启。手机、电脑缓存的虚拟地址重启后仍然有效，不会出现重启后一段时间部分网站打不开。记录放在内存里，每小时备份一次到 JFFS，不磨损闪存。</span></div></div>
			<div class="mh-row sw"><div class="k">TUN 模式<small>实验功能</small></div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_tun"/><span>用虚拟网卡接管局域网流量（替代 REDIRECT / TPROXY）</span></label>
					<div class="mh-warnbox">还没有在真实路由器上充分测试。TCP 和 UDP 都由内核的 TUN 网卡处理，部分游戏 / 语音兼容性更好，但 CPU 占用会高一些。路由器没有 TUN 设备、或 TUN 启动失败时，插件会自动改用普通透明代理并在日志里说明。暂不支持「只代理指定设备」。</div></div></div>
			<div class="mh-row"><label class="k" for="mihomo_ui_port">面板端口</label>
				<div class="v"><input type="text" id="mihomo_ui_port" class="mh-input port" maxlength="5" value="9090"/></div></div>
			<div class="mh-row"><label class="k" for="mihomo_secret">面板密钥</label>
				<div class="v"><input type="text" id="mihomo_secret" class="mh-input short" autocomplete="off"/>
					<span class="mh-tip">留空则无密码（不推荐）</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_log_level">内核日志级别</label>
				<div class="v"><select id="mihomo_log_level" class="mh-sel">
						<option value="silent">silent</option>
						<option value="error">error</option>
						<option value="warning">warning</option>
						<option value="info">info</option>
						<option value="debug">debug</option>
					</select></div></div>
			<div class="mh-row sw"><div class="k">Claude 助手<small>值勤机器人的大脑</small></div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_ai_enable" onchange="ai_toggle()"/><span>聊天时由 Claude 模型回答（结合巡检结果和运行日志）</span></label>
					<span class="mh-tip">关闭时机器人只能按关键词回答插件相关的问题。开启后把问题、巡检结果、最近的运行日志和主要设置发给 Claude（订阅地址、密钥会先去掉），回答只给建议，要操作仍然点按钮。需要你自己的 Anthropic API Key，按用量计费；请确认你的账号和使用地区在 Anthropic 支持的范围内。</span></div></div>
			<div class="mh-row ai-row"><label class="k" for="mihomo_ai_key">API Key</label>
				<div class="v"><input type="password" id="mihomo_ai_key" class="mh-input" placeholder="sk-ant-...（在 console.anthropic.com 创建）" autocomplete="off" spellcheck="false"/>
					<span class="mh-tip">只保存在路由器上，由路由器发起请求（Mihomo 运行时走插件代理）。</span></div></div>
			<div class="mh-row ai-row"><label class="k" for="mihomo_ai_model">模型</label>
				<div class="v"><select id="mihomo_ai_model" class="mh-sel">
						<option value="claude-haiku-5-5">Claude Haiku 5.5（快、便宜，推荐）</option>
						<option value="claude-sonnet-5-5">Claude Sonnet 5.5（更聪明）</option>
						<option value="claude-opus-5-5">Claude Opus 5.5（最强，费用最高）</option>
					</select>
					<div class="row-btns"><input type="button" class="mh-btn sm" value="测试连接" onclick="ai_test()"/><span id="ai_test_res" class="ai-res"></span></div></div></div>
			<div class="mh-row ai-row"><label class="k" for="mihomo_ai_base">API 地址<small>一般不用改</small></label>
				<div class="v"><input type="text" id="mihomo_ai_base" class="mh-input" placeholder="https://api.anthropic.com" autocomplete="off" spellcheck="false"/></div></div>
			<div class="mh-row"><label class="k" for="mihomo_bypass_ip">不走代理的设备<small>每行一个 IP / 网段</small></label>
				<div class="v"><textarea id="mihomo_bypass_ip" class="mh-area" rows="4" spellcheck="false" placeholder="192.168.50.10&#10;192.168.50.128/28"></textarea></div></div>
			<div class="mh-row"><label class="k" for="mihomo_rules">自定义规则<small>插入到规则最前面</small></label>
				<div class="v"><textarea id="mihomo_rules" class="mh-area" rows="6" spellcheck="false" placeholder="DOMAIN-SUFFIX,example.com,DIRECT&#10;DOMAIN-KEYWORD,openai,节点选择&#10;IP-CIDR,1.2.3.4/32,REJECT,no-resolve"></textarea>
					<span class="mh-tip">策略名必须在当前配置中存在（内置规则模式可用：节点选择 / 自动选择 / 故障转移 / 国内网站 / 漏网之鱼 / DIRECT / REJECT）</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_acl_mode">访问控制</label>
				<div class="v"><select id="mihomo_acl_mode" class="mh-sel" onchange="update_visibility()">
						<option value="all">全部设备走代理（「不走代理的设备」除外）</option>
						<option value="only">只代理指定设备</option>
					</select>
					<div id="tr_proxy_ip" style="margin-top:8px"><textarea id="mihomo_proxy_ip" class="mh-area" rows="3" spellcheck="false" placeholder="每行一个 IP / 网段，例如&#10;192.168.52.20&#10;192.168.52.128/28"></textarea>
					<span class="mh-tip">只有这些设备的流量和 DNS 交给 Mihomo，其它设备完全直连、不受插件影响。</span></div></div></div>
			<div class="mh-row"><label class="k" for="mihomo_dev_rules">设备专用策略<small>每行「IP 策略组」</small></label>
				<div class="v"><textarea id="mihomo_dev_rules" class="mh-area" rows="3" spellcheck="false" placeholder="192.168.52.30 奈飞&#10;192.168.52.31 🇭🇰 香港节点"></textarea>
					<span class="mh-tip">指定设备的所有流量都走某个策略组（如让电视只走奈飞分组）。策略组名要和面板里显示的完全一致，包括表情和空格。排在去广告规则之后，所以广告仍会被拦。</span></div></div>
			<div class="mh-row sw"><div class="k">IPv6 防泄漏</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_ipv6_block"/><span>拒绝局域网的 IPv6 DNS 查询</span></label>
					<span class="mh-tip">路由器开了 IPv6 时，设备可能通过 IPv6 DNS 绕过插件。开启后它们会马上改用 IPv4 DNS，由插件正常分流。路由器没开 IPv6 时此项不起作用。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_boot_delay">开机启动延迟</label>
				<div class="v"><input type="text" id="mihomo_boot_delay" class="mh-input port" maxlength="3" value="0"/> <span style="color:var(--mut)">秒</span>
					<span class="mh-tip">开机时插件总会先等路由器时间同步（最多 60 秒）再启动；网络拨号慢可以再加一点延迟，最多 600 秒。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_restart_hour">定时重启</label>
				<div class="v"><select id="mihomo_restart_hour" class="mh-sel"><option value="">不定时重启</option></select>
					<span class="mh-tip">每天这个时间（整点后 35 分）重启一次 Mihomo，释放内存、重新拉取规则集。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_data_dir">数据存放位置<small>规则库 / 规则集 / 订阅缓存 / 在线内核</small></label>
				<div class="v"><select id="mihomo_data_dir" class="mh-sel"><option value="">路由器 JFFS（默认）</option></select> <input type="button" class="mh-btn sm" value="刷新" onclick="load_storage()"/>
					<div id="storage_info" class="mh-tip" style="color:var(--text)">读取中…</div>
					<span class="mh-tip">JFFS 只有几十 MB，插件的大文件放到 U 盘可以腾出空间（更新插件、内核时不再提示空间不足）。保存后自动搬移，JFFS 里只留链接；改回 JFFS 会自动搬回来。开机时插件会等 U 盘挂载（最多 2 分钟）。选了 U 盘后请不要直接拔掉，要拔先改回 JFFS。</span></div></div>
		</div>

		<!-- 订阅 -->
		<div id="panel2" class="mh-card" style="display:none">
			<div class="mh-row"><div class="k">订阅列表<small>点圆圈设为当前</small></div>
				<div class="v"><div id="sub_list" class="sub-list"></div>
					<div class="sub-add"><input type="text" id="sub_new_name" class="mh-input" placeholder="名称，如 主力机场"/><input type="text" id="sub_new_url" class="mh-input" placeholder="订阅地址 https://..." autocomplete="off"/><input type="button" class="mh-btn sm" value="添加" onclick="sub_add()"/></div>
					<div id="sub_dirty" class="dirty">订阅列表有改动，点下方「保存并应用」后生效。</div></div></div>
			<div class="mh-row" id="tr_sub_merge"><div class="k">合并订阅</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_sub_merge"/><span>把所有订阅的节点合在一起用</span></label>
					<span class="mh-tip">仅「节点订阅 + 内置规则」模式可用；关闭时只用当前订阅。「机场 Clash 订阅」模式每次只能用一个订阅（每个机场的分组和规则不同，无法合并）。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_sub_ua">订阅 User-Agent</label>
				<div class="v"><input type="text" id="mihomo_sub_ua" class="mh-input short" value="clash.meta"/>
					<span class="mh-tip">机场按 UA 返回格式，一般保持 clash.meta 即可</span></div></div>
			<div class="mh-row" id="tr_sub_interval"><label class="k" for="mihomo_sub_interval">订阅自动更新</label>
				<div class="v"><select id="mihomo_sub_interval" class="mh-sel">
						<option value="0">不自动更新</option>
						<option value="6">每 6 小时</option>
						<option value="12">每 12 小时</option>
						<option value="24">每 24 小时</option>
					</select>
					<span class="mh-tip">自动更新当前订阅。流量和到期信息在每次更新订阅时刷新（机场支持时）。</span></div></div>
		</div>

		<!-- 覆写 -->
		<div id="panel3" class="mh-card" style="display:none">
			<div class="mh-row"><div class="k">去广告规则集<small>Mihomo 每天自动更新</small></div>
				<div class="v chk"><label class="mh-switch"><input type="checkbox" id="adr_awavenue"/><span>秋风广告规则（国内 App 广告，误杀少）</span></label>
					<div><select id="adr_heidai" class="mh-sel"><option value="">不使用 217heidai 合并规则</option><option value="heidai_lite">217heidai 合并规则 Lite（只拦国内域名，体积小）</option><option value="heidai">217heidai 合并规则 完整版</option></select></div>
					<label class="mh-switch"><input type="checkbox" id="adr_adguard" onchange="adg_toggle()"/><span>AdGuard DNS 过滤（大而全，约 19 万个域名）</span></label>
					<div id="adg_more" style="display:none">
						<input type="text" id="mihomo_adg_url" class="mh-input" style="margin-top:6px" spellcheck="false" autocomplete="off" placeholder="规则地址，留空用默认（MagicRule 的 AdGuardSDNSFilter）"/>
						<div class="row-btns"><input type="button" class="mh-btn sm" value="立即更新 AdGuard 规则" onclick="mh_sheet_close();update_adguard()"/></div>
						<span class="mh-tip">插件下载后转成精简格式（约 2MB）再交给内核，不会拖慢路由器；每天自动更新一次，更新时不断网。首次开启保存后会在后台下载，几十秒后生效，进度看「运行日志」。和其它规则集有重复，一般选一个大的就够了。</span>
					</div>
					<span class="mh-tip">和「基本设置 → 屏蔽广告」可同时使用；某网站被误拦时，在「高级设置 → 自定义规则」里加一条 DIRECT 放行。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_ad_allow">放行名单<small>不受去广告规则拦截</small></label>
				<div class="v"><textarea id="mihomo_ad_allow" class="mh-area" rows="4" spellcheck="false" placeholder="每行一个域名（含子域名），例如&#10;phncdn.com"></textarea>
					<div class="row-btns"><input type="button" class="mh-btn sm" value="找出被拦截的域名（60 秒）" onclick="ad_trace_start()"/><input type="button" class="mh-btn sm" value="刷新结果" onclick="ad_trace_load()"/></div>
					<div id="adtrace_box" class="adt-box"></div>
					<span class="mh-tip">网页或视频打不开时：点「找出被拦截的域名」，60 秒内去手机 / 电脑上打开有问题的页面并播放；结束后这里会列出被拦的域名。只放行跟播放有关的（名字里常带 cdn、video、media、stream），广告类（ads、track、traffic、pop）不要放行，这样视频能看、广告照样没有。放行的域名照常按订阅规则走，该走节点的照样走节点。改完点「保存并应用」。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_overlay">覆写配置<small>YAML，混入订阅</small></label>
				<div class="v"><textarea id="mihomo_overlay" class="mh-area" rows="16" spellcheck="false" placeholder="rule-providers:&#10;  my_rule:&#10;    type: http&#10;    behavior: classical&#10;    url: &quot;https://example.com/rule.yaml&quot;&#10;    path: ./ruleset/my_rule.yaml&#10;    interval: 86400&#10;rules:&#10;  - RULE-SET,my_rule,节点选择"></textarea>
					<span class="mh-tip">合并方式：rule-providers / proxy-providers 按条目加入；proxies / proxy-groups 插到最前面；rules 插到订阅规则前面；其它字段整体替换。端口、DNS、面板等由插件管理的字段会被忽略。写错时插件会自动忽略覆写继续启动，并在日志里提示。</span></div></div>
		</div>

		<!-- 更新 -->
		<div id="panel5" class="mh-card" style="display:none">
			<div class="mh-row"><div class="k">Mihomo 内核</div>
				<div class="v"><div class="kv2"><span>当前</span><b id="upd_core_cur">-</b><span>最新</span><b id="upd_core_new">未检查</b></div>
					<div class="row-btns"><input type="button" class="mh-btn sm" value="检查更新" onclick="api_call('check_core',{})"/><input type="button" class="mh-btn sm" value="更新内核" onclick="if(confirm('从 MetaCubeX 官方下载最新内核并重启 Mihomo（期间断网约 10 秒），新内核起不来会自动回滚。继续？'))api_call('update_core',{})"/></div>
					<span class="mh-tip">从 GitHub MetaCubeX/mihomo 官方发布下载，打不开时自动走 gh-proxy 加速或 Mihomo 代理。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_core_channel">内核版本通道</label>
				<div class="v"><select id="mihomo_core_channel" class="mh-sel">
						<option value="stable">正式版（推荐）</option>
						<option value="alpha">Alpha 测试版（每天构建，尝鲜用）</option>
					</select>
					<span class="mh-tip">决定「检查更新 / 更新内核」下载哪个版本，保存后再点「更新内核」。Alpha 有最新修复也可能有新问题；想回到正式版，切回「正式版」保存后再更新一次即可。新内核起不来会自动回滚。</span></div></div>
			<div class="mh-row sw" id="tr_geo_auto"><div class="k">规则库自动更新</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_geo_auto"/><span>每周三凌晨自动更新 GeoSite / GeoIP</span></label>
					<span class="mh-tip">更新后热重载生效，不断网；下载失败继续用旧的规则库（开了 TG 通知会提醒）。</span></div></div>
			<div class="mh-row"><div class="k">插件</div>
				<div class="v"><div class="kv2"><span>当前</span><b id="upd_plugin_cur">-</b><span>最新</span><b id="upd_plugin_new">未检查</b></div>
					<input type="text" id="mihomo_update_url" class="mh-input" style="margin-top:8px" placeholder="插件发布地址，默认 https://raw.githubusercontent.com/yixiaa/mihomo-merlin/release" autocomplete="off"/>
					<div style="margin-top:10px"><label class="mh-switch"><input type="checkbox" id="mihomo_auto_update"/><span>自动更新插件（每 5 分钟检查一次，有新版本自动安装）</span></label></div>
					<div class="mh-tip" id="autoupd_status" style="margin-top:6px"></div>
					<div class="row-btns"><input type="button" class="mh-btn sm" value="检查更新" onclick="plugin_action('check_plugin')"/><input type="button" class="mh-btn sm" value="更新插件" onclick="if(confirm('下载新版插件并覆盖安装？设置会保留。'))plugin_action('update_plugin')"/></div>
					<span class="mh-tip">地址下面要有两个文件：version（只写版本号，如 1.7.0）和 mihomo.tar.gz（安装包）。默认是 yixiaa/mihomo-merlin 仓库的 release 分支；GitHub 直连打不开时会自动走 gh-proxy 加速或 Mihomo 代理。自动更新安装时 Mihomo 会重启，断网约 10 秒；同一版本连续安装失败 3 次后不再重试。改了地址或开关后要点「保存并应用」才生效。</span></div></div>
		</div>

		<!-- 配置 -->
		<div id="panel6" class="mh-card" style="display:none">
			<div class="mh-row"><div class="k">生成的配置<small>只读，面板密钥已打码</small></div>
				<div class="v"><div class="row-btns" style="margin:0 0 8px"><input type="button" class="mh-btn sm" value="刷新" onclick="load_config()"/><input type="button" class="mh-btn sm" value="下载" onclick="download_config()"/></div>
					<textarea id="mihomo_cfg_view" class="mh-cfg" readonly="readonly" wrap="off" spellcheck="false" placeholder="点「刷新」查看插件实际交给 Mihomo 的配置"></textarea></div></div>
		</div>

		<!-- 通知 -->
		<div id="panel8" class="mh-card" style="display:none">
			<div class="mh-row sw"><div class="k">Telegram 通知</div>
				<div class="v"><label class="mh-switch"><input type="checkbox" id="mihomo_tg_enable"/><span>插件有重要情况时发消息到你的 Telegram</span></label></div></div>
			<div class="mh-row"><label class="k" for="mihomo_tg_token">Bot Token</label>
				<div class="v"><input type="password" id="mihomo_tg_token" class="mh-input" placeholder="123456789:AAH...（找 @BotFather 创建机器人获得）" autocomplete="off"/>
					<span class="mh-tip">在 Telegram 搜索 <b>@BotFather</b> → 发送 /newbot → 按提示起名，最后它给你的一串就是 Token。</span></div></div>
			<div class="mh-row"><label class="k" for="mihomo_tg_chat">Chat ID</label>
				<div class="v"><input type="text" id="mihomo_tg_chat" class="mh-input short" placeholder="例如 123456789" autocomplete="off"/>
					<span class="mh-tip">搜索 <b>@userinfobot</b> 发任意消息，它回复的 Id 就是你的 Chat ID。<b>还要先给你自己的机器人发一句话</b>，否则机器人没法主动给你发消息。发到群里就填群的 ID（-100 开头）。</span></div></div>
			<div class="mh-row"><div class="k">通知哪些事</div>
				<div class="v"><div class="tg-evs" id="tg_evs"><label class="mh-switch tg-ev"><input type="checkbox" data-ev="fail" data-def="1"/><span><b>启动失败 / 守护自动重启</b><br><small>插件出问题、全家断网时第一时间知道</small></span></label><label class="mh-switch tg-ev"><input type="checkbox" data-ev="boot" data-def="1"/><span><b>路由器开机上线</b><br><small>停电或重启后插件恢复工作</small></span></label><label class="mh-switch tg-ev"><input type="checkbox" data-ev="sub" data-def="1"/><span><b>订阅更新</b><br><small>更新成功、下载失败、新订阅异常被拦下</small></span></label><label class="mh-switch tg-ev"><input type="checkbox" data-ev="traffic" data-def="1"/><span><b>流量与到期提醒</b><br><small>流量用到 80% / 90% / 100%，离到期 7 / 3 / 1 天</small></span></label><label class="mh-switch tg-ev"><input type="checkbox" data-ev="update" data-def="1"/><span><b>插件 / 内核更新</b><br><small>自动更新完成后告诉你新版本号</small></span></label><label class="mh-switch tg-ev"><input type="checkbox" data-ev="start"/><span><b>手动启动 / 停止</b><br><small>在设置页或大按钮启停时</small></span></label></div></div></div>
			<div class="mh-row"><label class="k" for="mihomo_tg_api">API 地址<small>可留空</small></label>
				<div class="v"><input type="text" id="mihomo_tg_api" class="mh-input" placeholder="默认 https://api.telegram.org" autocomplete="off"/>
					<span class="mh-tip">Mihomo 运行时消息自动走代理发出。Mihomo 没运行时（比如启动失败）发不出去的消息会先存着，恢复后补发。也可以填自建的 Telegram API 反代地址，代理没运行时也能直接发。</span></div></div>
			<div class="mh-row"><div class="k">测试</div>
				<div class="v"><input type="button" class="mh-btn sm" value="发送测试消息" onclick="tg_test()"/>
					<span class="mh-tip">会先保存上面的设置再发送，结果看「日志」页。</span></div></div>
		</div>

		<!-- 日志 -->
		<div id="panel7" style="display:none">
			<div class="mh-logbar"><span class="t">运行日志</span><span id="log_status"></span></div>
			<textarea id="mihomo_log" class="mh-log" readonly="readonly" wrap="off" placeholder="点「保存并应用」「更新订阅」「更新规则库」后，执行过程会显示在这里"></textarea>
		</div>

		</div>
	</td></tr>
	</table>
	</td></tr>
	</table>
</td>
<td width="10" align="center" valign="top"></td>
</tr>
</table>
</form>
<div id="footer"></div>
</body>
</html>
