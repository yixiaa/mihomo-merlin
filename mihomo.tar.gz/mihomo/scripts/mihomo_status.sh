#!/bin/sh
# 返回给页面的状态：state@@pid@@core_version@@sub_time@@mem_kb@@uptime
source /koolshare/scripts/base.sh
PIDFILE=/var/run/mihomo/mihomo.pid
pid=""
[ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null && pid=$(cat $PIDFILE)
[ -z "$pid" ] && pid=$(pidof mihomo | awk '{print $1}')
if [ -n "$pid" ]; then
	state=1
	mem=$(awk '/VmRSS/{print $2}' /proc/$pid/status 2>/dev/null)
	start=$(awk '{print $22}' /proc/$pid/stat 2>/dev/null)
	hz=100; up=$(awk '{print int($1)}' /proc/uptime)
	[ -n "$start" ] && uptime=$((up - start / hz)) || uptime=0
	netstat -ltn 2>/dev/null | grep -q ':7892 ' || state=2
	netstat -lun 2>/dev/null | grep -q ':23453 ' || state=2
else
	state=0; pid=0; mem=0; uptime=0
fi
http_response "${state}@@${pid}@@$(dbus get mihomo_core_version)@@$(dbus get mihomo_sub_time)@@${mem:-0}@@${uptime}"
