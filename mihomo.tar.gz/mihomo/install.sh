#!/bin/sh
# Mihomo 插件安装脚本（Koolcenter 软件中心 / HND 平台）
source /koolshare/scripts/base.sh
DIR=$(cd "$(dirname "$0")" && pwd)
MODULE=mihomo
TITLE="Mihomo"
DESCR="Mihomo (Clash.Meta) 内核透明代理，内置新控制面板与广告屏蔽"


exit_install() {
	echo_date "$1"
	echo_date "退出安装！"
	rm -rf /tmp/${MODULE} /tmp/${MODULE}.tar.gz >/dev/null 2>&1
	exit 1
}

# --- 平台检测 ---
ARCH=$(uname -m)
MODEL=$(nvram get odmpid); [ -z "$MODEL" ] && MODEL=$(nvram get productid)
echo_date "机型：$MODEL  架构：$ARCH  固件：$(nvram get buildno)_$(nvram get extendno)"
case "$ARCH" in
	aarch64|armv8*) CORE=mihomo-arm64 ;;
	armv7l)         CORE=mihomo-armv7 ;;
	*) exit_install "不支持的架构 $ARCH，本插件仅适用于 ARM 平台（RT-AX86U 等 HND 机型）" ;;
esac
# 升级包（mihomo_lite.tar.gz）不带内核和规则库，沿用路由器上已装的
LITE=0
if [ ! -f "$DIR/bin/$CORE" ]; then
	[ -x /koolshare/bin/mihomo ] || exit_install "安装包中没有适用于 $ARCH 的内核（需要 bin/$CORE）"
	LITE=1; echo_date "升级包：保留现有内核和规则库"
fi
[ -d /koolshare/scripts ] || exit_install "未检测到软件中心"

# --- 与其它透明代理插件冲突检测 ---
for p in ss_basic_enable merlinclash_enable clash_enable; do
	[ "$(dbus get $p)" = "1" ] && exit_install "检测到其它代理插件（$p）正在运行，请先关闭后再安装"
done

# --- JFFS 空间检测 ---
# 升级时同名文件是覆盖，只算新增的部分；已放到 U 盘的文件（软链接）不占 JFFS
kb() { [ -e "$1" ] && du -sk "$1" 2>/dev/null | awk '{print $1}' || echo 0; }
NEED=0; [ $LITE = 0 ] && NEED=$(( $(kb "$DIR/bin/$CORE") - $(kb /koolshare/bin/mihomo) ))
UI_KB=0; [ -f "$DIR/mihomo/ui.tar.gz" ] && UI_KB=$(( $(tar -xzOf "$DIR/mihomo/ui.tar.gz" 2>/dev/null | wc -c) / 1024 + 64 ))
NEED=$(( NEED + UI_KB - $(kb /koolshare/mihomo/ui) ))
for f in Country.mmdb GeoSite.dat; do
	[ -e /koolshare/mihomo/$f ] || [ -L /koolshare/mihomo/$f ] || NEED=$(( NEED + $(kb "$DIR/mihomo/$f") ))
done
NEED=$(( NEED + $(du -sk "$DIR/scripts" "$DIR/webs" "$DIR/res" 2>/dev/null | awk '{s+=$1}END{print s+0}') + 256 ))
[ $NEED -lt 256 ] && NEED=256
FREE=$(df -kP /jffs | awk 'NR==2{print $4}')
echo_date "JFFS 剩余：${FREE}KB，本次需要约：${NEED}KB"
[ -n "$FREE" ] && [ "$FREE" -lt "$NEED" ] && exit_install "JFFS 空间不足：可在插件「高级设置 → 数据存放位置」选 U 盘腾出空间后再装"

# --- 结束正在进行的插件操作（比如卡在下载的自动更新），否则下面的停止命令会一直等它 ---
for p in $(ps w 2>/dev/null | grep -E '[m]ihomo_config\.sh|[c]url .*/tmp/mihomo' | awk '{print $1}'); do
	[ "$p" != "$$" ] && kill "$p" 2>/dev/null
done
sleep 1

# --- 若正在运行则先停止 ---
if [ -x /koolshare/scripts/mihomo_config.sh ] && [ "$(dbus get mihomo_enable)" = "1" ]; then
	echo_date "停止旧版本..."
	sh /koolshare/scripts/mihomo_config.sh stop >/dev/null 2>&1
	WAS_ON=1
fi

# --- 复制文件 ---
echo_date "复制文件..."
mkdir -p /koolshare/mihomo /koolshare/init.d /koolshare/bin
[ $LITE = 0 ] && cp -f "$DIR/bin/$CORE" /koolshare/bin/mihomo
chmod 755 /koolshare/bin/mihomo
# 在线更新过的内核（mihomo.gz）：比安装包自带的新才保留，否则用安装包自带的
ver_num() { echo "$1" | sed 's/^v//; s/[^0-9.].*$//' | awk -F. '{printf "%05d%05d%05d", $1, $2, $3}'; }
if [ $LITE = 0 ] && [ -f /koolshare/bin/mihomo.gz ]; then
	NEW_V=$(/koolshare/bin/mihomo -v 2>/dev/null | awk 'NR==1{print $3}')
	OLD_V=$(gunzip -c /koolshare/bin/mihomo.gz > /tmp/mihomo_chk 2>/dev/null && chmod 755 /tmp/mihomo_chk && /tmp/mihomo_chk -v 2>/dev/null | awk 'NR==1{print $3}')
	rm -f /tmp/mihomo_chk
	if [ -n "$OLD_V" ] && [ "$(awk -v a="$(ver_num "$OLD_V")" -v b="$(ver_num "$NEW_V")" 'BEGIN{print (a"">b"")?1:0}')" = 1 ]; then
		echo_date "保留在线更新的内核 $OLD_V（安装包自带 $NEW_V）"
	else
		[ -L /koolshare/bin/mihomo.gz ] && rm -f "$(readlink /koolshare/bin/mihomo.gz)"
		rm -f /koolshare/bin/mihomo.gz
	fi
fi
[ $LITE = 0 ] && rm -f /var/run/mihomo/mihomo
cp -f "$DIR"/scripts/*.sh /koolshare/scripts/
cp -f "$DIR/uninstall.sh" /koolshare/scripts/uninstall_${MODULE}.sh
cp -f "$DIR"/webs/* /koolshare/webs/
cp -f "$DIR"/res/* /koolshare/res/
# 规则数据：不覆盖用户已更新过的文件
for f in Country.mmdb GeoSite.dat; do
	[ -e /koolshare/mihomo/$f ] || [ -L /koolshare/mihomo/$f ] || [ ! -f "$DIR/mihomo/$f" ] || cp -f "$DIR/mihomo/$f" /koolshare/mihomo/
done
# 面板
if [ -f "$DIR/mihomo/ui.tar.gz" ]; then
	rm -rf /koolshare/mihomo/ui && mkdir -p /koolshare/mihomo/ui
	tar -xzf "$DIR/mihomo/ui.tar.gz" -C /koolshare/mihomo/ui
fi
chmod 755 /koolshare/scripts/mihomo_*.sh /koolshare/scripts/uninstall_${MODULE}.sh
ln -sf /koolshare/scripts/mihomo_config.sh /koolshare/init.d/S99mihomo.sh
ln -sf /koolshare/scripts/mihomo_config.sh /koolshare/init.d/N99mihomo.sh

# --- 默认值 ---
[ -z "$(dbus get mihomo_cfg_mode)" ] && dbus set mihomo_cfg_mode=sub
[ -z "$(dbus get mihomo_dns_mode)" ] && dbus set mihomo_dns_mode=fake-ip
[ -z "$(dbus get mihomo_adblock)" ] && dbus set mihomo_adblock=0
[ -z "$(dbus get mihomo_udp)" ] && dbus set mihomo_udp=0
[ -z "$(dbus get mihomo_ui_port)" ] && dbus set mihomo_ui_port=9090
[ -z "$(dbus get mihomo_sub_ua)" ] && dbus set mihomo_sub_ua=clash.meta
[ -z "$(dbus get mihomo_sub_interval)" ] && dbus set mihomo_sub_interval=0
[ -z "$(dbus get mihomo_secret)" ] && dbus set mihomo_secret="$(head -c 12 /dev/urandom | md5sum | cut -c1-12)"
[ -z "$(dbus get mihomo_enable)" ] && dbus set mihomo_enable=0
[ -z "$(dbus get mihomo_acl_mode)" ] && dbus set mihomo_acl_mode=all
[ -z "$(dbus get mihomo_ipv6_block)" ] && dbus set mihomo_ipv6_block=1
[ -z "$(dbus get mihomo_boot_delay)" ] && dbus set mihomo_boot_delay=0
[ -z "$(dbus get mihomo_auto_update)" ] && dbus set mihomo_auto_update=1
[ -z "$(dbus get mihomo_github_proxy)" ] && dbus set mihomo_github_proxy=1
[ -z "$(dbus get mihomo_geo_auto)" ] && dbus set mihomo_geo_auto=1
[ -z "$(dbus get mihomo_store_fakeip)" ] && dbus set mihomo_store_fakeip=1
[ -z "$(dbus get mihomo_tun)" ] && dbus set mihomo_tun=0
[ -z "$(dbus get mihomo_core_channel)" ] && dbus set mihomo_core_channel=stable
[ -z "$(dbus get mihomo_webrtc)" ] && dbus set mihomo_webrtc=proxy
[ -z "$(dbus get mihomo_ai_enable)" ] && dbus set mihomo_ai_enable=0
[ -z "$(dbus get mihomo_ai_model)" ] && dbus set mihomo_ai_model=claude-haiku-5-5
# 默认发布地址：yixiaa/mihomo-merlin 仓库的 release 分支
[ -z "$(dbus get mihomo_update_url)" ] && dbus set mihomo_update_url="https://raw.githubusercontent.com/yixiaa/mihomo-merlin/release"
# 安装成功：清掉自动更新的失败计数
dbus remove mihomo_autoupd_failver; dbus remove mihomo_autoupd_failcnt

# --- 软件中心注册 ---
VER=$(cat "$DIR/version")
OLD_VER=$(dbus get mihomo_version)
# 开了 Telegram 通知时，升级后由新版本启动成功后发一条「已更新」
[ -n "$OLD_VER" ] && [ "$OLD_VER" != "$VER" ] && [ "$(dbus get mihomo_tg_enable)" = "1" ] && dbus set mihomo_tg_pending="插件已从 v$OLD_VER 更新到 v$VER"
dbus set mihomo_version="$VER"
dbus set softcenter_module_${MODULE}_version="$VER"
dbus set softcenter_module_${MODULE}_install="1"
dbus set softcenter_module_${MODULE}_name="$MODULE"
dbus set softcenter_module_${MODULE}_title="$TITLE"
dbus set softcenter_module_${MODULE}_description="$DESCR"

rm -rf /tmp/${MODULE} /tmp/${MODULE}.tar.gz >/dev/null 2>&1

# 重新登记自动更新的定时任务（插件关闭时也要检查更新）
if [ "$(dbus get mihomo_auto_update)" = "1" ] && [ -n "$(dbus get mihomo_update_url)" ]; then
	cru a mihomo_autoupd "*/5 * * * * /koolshare/scripts/mihomo_config.sh auto_update"
fi
mkdir -p /tmp/upload; echo "$(date '+%m-%d %H:%M') 已安装 v$VER" > /tmp/upload/mihomo_autoupd.txt
if [ "$WAS_ON" = "1" ]; then
	echo_date "重新启动 Mihomo..."
	sh /koolshare/scripts/mihomo_config.sh restart >/dev/null 2>&1
fi
echo_date "$TITLE v$VER 安装完成！"
exit 0
