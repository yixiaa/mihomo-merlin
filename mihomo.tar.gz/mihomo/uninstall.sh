#!/bin/sh
source /koolshare/scripts/base.sh
sh /koolshare/scripts/mihomo_config.sh stop >/dev/null 2>&1
cru d mihomo_autoupd 2>/dev/null
rm -f /koolshare/init.d/S99mihomo.sh /koolshare/init.d/N99mihomo.sh
rm -f /koolshare/scripts/mihomo_config.sh /koolshare/scripts/mihomo_status.sh
rm -f /koolshare/webs/Module_mihomo.asp /koolshare/res/icon-mihomo.png /koolshare/res/mihomo_bot*.jpg
rm -f /koolshare/bin/mihomo /koolshare/bin/mihomo.gz
rm -rf /koolshare/mihomo /var/run/mihomo /tmp/upload/mihomo_*
for k in $(dbus list mihomo_ | cut -d "=" -f 1); do dbus remove "$k"; done
for k in $(dbus list softcenter_module_mihomo_ | cut -d "=" -f 1); do dbus remove "$k"; done
rm -f /koolshare/scripts/uninstall_mihomo.sh
